package com.example.speedtimeplayer

import android.content.Context
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.common.util.UnstableApi

/**
 * Alvi's audio-aware renderer factory. Media3 1.5.1 exposes the silence processor
 * through DefaultAudioSink's processor chain, allowing Mild/Strong silence modes
 * without a separate native audio library.
 */
@UnstableApi
class AlviRenderersFactory(
    context: Context,
    decoderMode: Int,
    private val silenceMode: Int
) : DefaultRenderersFactory(context) {

    init {
        setEnableDecoderFallback(decoderMode == 1)
        setExtensionRendererMode(
            when (decoderMode) {
                2 -> EXTENSION_RENDERER_MODE_PREFER
                1 -> EXTENSION_RENDERER_MODE_ON
                else -> EXTENSION_RENDERER_MODE_OFF
            }
        )
        // Useful on API 23–30 and harmless on newer Android versions.
        forceEnableMediaCodecAsynchronousQueueing()
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioOutputPlaybackParams: Boolean
    ): AudioSink {
        val silence = when (silenceMode) {
            1 -> SilenceSkippingAudioProcessor(
                700_000L,
                0.25f,
                2_000_000L,
                10,
                MILD_THRESHOLD
            )
            2 -> SilenceSkippingAudioProcessor(
                350_000L,
                0.10f,
                900_000L,
                10,
                STRONG_THRESHOLD
            )
            else -> SilenceSkippingAudioProcessor()
        }
        val chain = DefaultAudioSink.DefaultAudioProcessorChain(
            arrayOf<androidx.media3.common.audio.AudioProcessor>(AudioProbe()),
            silence,
            SonicAudioProcessor()
        )
        return DefaultAudioSink.Builder(context)
            .setAudioProcessorChain(chain)
            .setEnableFloatOutput(enableFloatOutput)
            .setEnableAudioTrackPlaybackParams(enableAudioOutputPlaybackParams)
            .build()
    }

    companion object {
        // 16-bit PCM amplitude (0..32767). Media3's default is 1024 (~ -30 dBFS), which may be
        // below the noise floor of many lectures/phone recordings, so pauses may never count
        // as silence. Raise these if pauses are still not skipped; lower them if speech is clipped.
        private const val MILD_THRESHOLD: Short = 2048
        private const val STRONG_THRESHOLD: Short = 4096
    }
}
