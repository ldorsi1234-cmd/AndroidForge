package com.example.speedtimeplayer

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * DEBUG ONLY. Passes audio through unchanged and records how loud it is just before the
 * silence-skipping step, so we can see whether pauses are really quieter than the thresholds.
 */
@UnstableApi
class AudioProbe : BaseAudioProcessor() {

    private var windowSamples = 0
    private var windowCount = 0
    private var windowPeak = 0
    private var quietRun2k = 0
    private var quietRun4k = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        configuredCount++
        encoding = inputAudioFormat.encoding
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        windowSamples = (inputAudioFormat.sampleRate / 10) * inputAudioFormat.channelCount // ~100 ms
        windowCount = 0; windowPeak = 0; quietRun2k = 0; quietRun4k = 0
        totalWindows = 0; below1k = 0; below2k = 0; below4k = 0; below8k = 0
        longestQuiet2kMs = 0; longestQuiet4kMs = 0; minWindowPeak = Int.MAX_VALUE
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        if (encoding == C.ENCODING_PCM_16BIT && windowSamples > 0) {
            val b = inputBuffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            while (b.remaining() >= 2) {
                val v = Math.abs(b.short.toInt())
                if (v > windowPeak) windowPeak = v
                if (++windowCount >= windowSamples) { closeWindow(); windowCount = 0; windowPeak = 0 }
            }
        }
        val out = replaceOutputBuffer(size)
        out.put(inputBuffer)
        out.flip()
    }

    private fun closeWindow() {
        val p = windowPeak
        totalWindows++
        lastWindowPeak = p
        if (p < minWindowPeak) minWindowPeak = p
        if (p < 1024) below1k++
        if (p < 2048) below2k++
        if (p < 4096) below4k++
        if (p < 8192) below8k++
        if (p < 2048) { quietRun2k++; if (quietRun2k * 100 > longestQuiet2kMs) longestQuiet2kMs = quietRun2k * 100 } else quietRun2k = 0
        if (p < 4096) { quietRun4k++; if (quietRun4k * 100 > longestQuiet4kMs) longestQuiet4kMs = quietRun4k * 100 } else quietRun4k = 0
    }

    companion object {
        @Volatile var configuredCount = 0
        @Volatile var encoding = -1
        @Volatile var sampleRate = 0
        @Volatile var channels = 0
        @Volatile var totalWindows = 0
        @Volatile var lastWindowPeak = 0
        @Volatile var minWindowPeak = Int.MAX_VALUE
        @Volatile var below1k = 0
        @Volatile var below2k = 0
        @Volatile var below4k = 0
        @Volatile var below8k = 0
        @Volatile var longestQuiet2kMs = 0
        @Volatile var longestQuiet4kMs = 0

        fun report(): String {
            if (configuredCount == 0) return "Probe: audio sink never configured (custom sink not in use?)"
            val enc = if (encoding == C.ENCODING_PCM_16BIT) "PCM 16-bit" else "encoding code $encoding (NOT 16-bit PCM)"
            val n = totalWindows.coerceAtLeast(1)
            val min = if (minWindowPeak == Int.MAX_VALUE) 0 else minWindowPeak
            return "Probe: $enc, $sampleRate Hz, $channels ch\n" +
                "Windows (100 ms) measured: $totalWindows\n" +
                "Quietest window peak: $min / 32767\n" +
                "Windows under 1024: ${below1k * 100 / n}%  2048: ${below2k * 100 / n}%  4096: ${below4k * 100 / n}%  8192: ${below8k * 100 / n}%\n" +
                "Longest run under 2048: $longestQuiet2kMs ms\n" +
                "Longest run under 4096: $longestQuiet4kMs ms"
        }
    }
}
