package com.example.speedtimeplayer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.common.util.UnstableApi

@UnstableApi
class BackgroundPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private val prefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val decoderMode = prefs.getInt("decoder_mode", 1).coerceIn(0, 2)
        val silenceMode = prefs.getInt("auto_skip_mode", if (prefs.getBoolean("auto_skip_silence", false)) 1 else 0).coerceIn(0, 2)
        val factory = AlviRenderersFactory(this, decoderMode, silenceMode)
        player = ExoPlayer.Builder(this, factory)
            .setSkipSilenceEnabled(silenceMode > 0)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .also { it.repeatMode = Player.REPEAT_MODE_OFF }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 1201, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        sessionPendingIntent = pendingIntent
        mediaSession = MediaSession.Builder(this, player!!)
            .setSessionActivity(pendingIntent)
            .build()
        // No MediaController ever connects to this session, so register it ourselves; otherwise
        // Media3 never posts its notification or moves the service to the foreground.
        try { addSession(mediaSession!!) } catch (_: Exception) {}
    }

    private var sessionPendingIntent: PendingIntent? = null

    /**
     * Android requires a service started with startForegroundService() to call startForeground()
     * within ~5 seconds or the app crashes. Do it immediately with the same id/channel Media3 uses,
     * so Media3's media notification simply replaces this one once playback starts.
     */
    private fun ensureForeground(title: String) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Background playback", NotificationManager.IMPORTANCE_LOW))
                }
            }
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText("Playing in background")
                .setOngoing(true)
                .setContentIntent(sessionPendingIntent)
                .build()
            ServiceCompat.startForeground(
                this, NOTIFICATION_ID, notification,
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            )
        } catch (_: Exception) {
            // If this is refused the service still runs; the activity keeps its own player in that case.
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action != ACTION_STOP) {
            ensureForeground(intent?.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: "Alvi Player")
        }
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        val uriString = intent?.getStringExtra(EXTRA_URI)
        if (!uriString.isNullOrBlank()) {
            val uri = Uri.parse(uriString)
            val position = intent.getLongExtra(EXTRA_POSITION, 0L).coerceAtLeast(0L)
            val speed = intent.getFloatExtra(EXTRA_SPEED, 1f).coerceIn(0.25f, 3f)
            val title = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "Alvi Player"
            val repeat = intent.getIntExtra(EXTRA_REPEAT, Player.REPEAT_MODE_OFF).coerceIn(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL)
            val playlist = intent.getStringArrayListExtra(EXTRA_PLAYLIST)?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }.orEmpty().ifEmpty { listOf(uri) }
            val startIndex = intent.getIntExtra(EXTRA_START_INDEX, playlist.indexOf(uri).takeIf { it >= 0 } ?: 0).coerceIn(0, playlist.lastIndex)
            val items = playlist.map { itemUri ->
                MediaItem.Builder().setUri(itemUri).setMediaMetadata(
                    MediaMetadata.Builder().setTitle(itemUri.lastPathSegment ?: title).build()
                ).build()
            }
            player?.apply {
                repeatMode = repeat
                setPlaybackSpeed(speed)
                setMediaItems(items, startIndex, position)
                prepare()
                playWhenReady = true
            }
            prefs.edit()
                .putBoolean(KEY_ACTIVE, true)
                .putString("last_uri", uri.toString())
                .putLong("pos_${uri}", position)
                .apply()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (player?.isPlaying == true) return
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        player?.let {
            val uri = it.currentMediaItem?.localConfiguration?.uri
            if (uri != null) {
                prefs.edit()
                    .putLong("pos_${uri}", it.currentPosition.coerceAtLeast(0L))
                    .putString("last_uri", uri.toString())
                    .putBoolean(KEY_ACTIVE, false)
                    .apply()
            }
            it.release()
        }
        player = null
        if (instance === this) instance = null
        mediaSession?.release()
        mediaSession = null
        prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
        super.onDestroy()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    companion object {
        @Volatile private var instance: BackgroundPlaybackService? = null

        data class Snapshot(val uri: String, val positionMs: Long, val playing: Boolean)

        /** Current service playback state; call from the main thread. Null if the service is not running. */
        fun snapshot(): Snapshot? {
            val p = instance?.player ?: return null
            val uri = p.currentMediaItem?.localConfiguration?.uri?.toString() ?: return null
            return Snapshot(uri, p.currentPosition.coerceAtLeast(0L), p.playWhenReady)
        }

        const val EXTRA_URI = "extra_uri"
        const val EXTRA_POSITION = "extra_position"
        const val EXTRA_SPEED = "extra_speed"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_REPEAT = "extra_repeat"
        const val EXTRA_PLAYLIST = "extra_playlist"
        const val EXTRA_START_INDEX = "extra_start_index"
        const val ACTION_STOP = "com.example.speedtimeplayer.action.STOP_BACKGROUND"
        const val KEY_ACTIVE = "background_playback_active"
        private const val CHANNEL_ID = "default_channel_id"
        private const val NOTIFICATION_ID = 1001
    }
}
