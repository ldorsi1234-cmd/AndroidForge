package com.example.speedtimeplayer

import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

@UnstableApi
class MainActivity : ComponentActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var speedSpinner: Spinner
    private lateinit var timeLeftText: TextView
    private lateinit var playPauseButton: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var selectButton: TextView
    private lateinit var lockButton: TextView
    private lateinit var gestureHint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var controlsVisible = false
    private var locked = false
    private var userSeeking = false
    private var brightnessBeforeGesture = -1f
    private val speeds = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 4f)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartPosition = 0L
    private var gestureMode = 0 // 0 unknown, 1 seek, 2 brightness, 3 volume

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = true
            selectButton.visibility = View.GONE
            setControlsVisible(false)
            updateUi()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        playerView.useController = false
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { updateUi() }
            override fun onPlaybackStateChanged(playbackState: Int) { updateUi() }
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@MainActivity, "Cannot play this video format", Toast.LENGTH_LONG).show()
            }
        })
        playPauseButton.setOnClickListener { if (player.isPlaying) player.pause() else player.play(); updateUi(); showControlsTemporarily() }
        selectButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        lockButton.setOnClickListener {
            locked = !locked
            lockButton.text = if (locked) "Unlock" else "Lock"
            setControlsVisible(!locked)
            Toast.makeText(this, if (locked) "Screen locked" else "Screen unlocked", Toast.LENGTH_SHORT).show()
        }
        speedSpinner.setSelection(speeds.indexOf(1f))
        speedSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (::player.isInitialized) {
                    player.setPlaybackSpeed(speeds[position])
                    updateUi()
                }
            }
        }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true; cancelAutoHide() }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && player.duration > 0 && player.duration != C.TIME_UNSET) {
                    positionText.text = formatMs(player.duration * progress / 1000L)
                }
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (player.duration > 0 && player.duration != C.TIME_UNSET) player.seekTo(player.duration * (seekBar?.progress ?: 0) / 1000L)
                userSeeking = false
                showControlsTemporarily()
            }
        })
        installGestures()
        handler.post(updateRunnable)
        setControlsVisible(false)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(0xD91A1A1A.toInt())
        }
        selectButton = button("Select video")
        topBar.addView(selectButton)
        val speedLabel = label("Speed")
        topBar.addView(speedLabel)
        speedSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                speeds.map { if (it % 1f == 0f) "${it.toInt()}×" else "${it}×" })
            setBackgroundColor(0xFF303030.toInt())
        }
        topBar.addView(speedSpinner, LinearLayout.LayoutParams(dp(82), dp(44)))
        lockButton = button("Lock")
        val lockParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) }
        topBar.addView(lockButton, lockParams)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(8))
            setBackgroundColor(0xD91A1A1A.toInt())
        }
        val seekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        positionText = label("0:00")
        durationText = label("0:00")
        seekBar = SeekBar(this).apply { max = 1000; progress = 0 }
        seekRow.addView(positionText, LinearLayout.LayoutParams(dp(56), -2))
        seekRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(34), 1f))
        seekRow.addView(durationText, LinearLayout.LayoutParams(dp(56), -2))
        bottomBar.addView(seekRow)
        val controlsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        playPauseButton = button("Ⅱ")
        controlsRow.addView(playPauseButton)
        timeLeftText = label("ACTUAL TIME LEFT  —")
        timeLeftText.textSize = 15f
        timeLeftText.gravity = Gravity.CENTER
        controlsRow.addView(timeLeftText, LinearLayout.LayoutParams(0, dp(42), 1f))
        bottomBar.addView(controlsRow)
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        gestureHint = TextView(this).apply {
            text = ""
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setBackgroundColor(0xB8000000.toInt())
            visibility = View.GONE
        }
        root.addView(gestureHint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(root)
    }

    private fun installGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    lockButton.visibility = View.VISIBLE
                    handler.postDelayed({ if (locked) lockButton.visibility = View.GONE }, 1600)
                } else toggleControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (e.x < root.width * 0.35f) player.seekTo(max(0L, player.currentPosition - 10_000L))
                else if (e.x > root.width * 0.65f) player.seekTo(player.currentPosition + 10_000L)
                else if (player.isPlaying) player.pause() else player.play()
                showControlsTemporarily()
                return true
            }
        })
        playerView.setOnTouchListener { _, event ->
            detector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureStartX = event.x; gestureStartY = event.y
                    gestureStartPosition = player.currentPosition
                    gestureMode = 0
                    brightnessBeforeGesture = window.attributes.screenBrightness
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (locked) return@setOnTouchListener true
                    val dx = event.x - gestureStartX
                    val dy = event.y - gestureStartY
                    if (gestureMode == 0 && (abs(dx) > dp(18) || abs(dy) > dp(18))) {
                        gestureMode = if (abs(dx) > abs(dy)) 1 else if (gestureStartX < root.width / 2f) 2 else 3
                        cancelAutoHide()
                    }
                    when (gestureMode) {
                        1 -> {
                            val delta = (dx / root.width * 120_000L).toLong()
                            val target = max(0L, gestureStartPosition + delta)
                            player.seekTo(if (player.duration > 0 && player.duration != C.TIME_UNSET) target.coerceAtMost(player.duration) else target)
                            showGestureHint("${if (delta >= 0) "+" else "−"}${formatMs(abs(delta))}")
                        }
                        2 -> {
                            val value = (0.75f - dy / root.height).coerceIn(0.05f, 1f)
                            val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                            showGestureHint("Brightness ${(value * 100).roundToInt()}%")
                        }
                        3 -> {
                            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                            val maxVol = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                            val current = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                            val change = (-dy / root.height * maxVol * 2).roundToInt()
                            audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (current + change).coerceIn(0, maxVol), 0)
                            showGestureHint("Volume ${(audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / maxVol)}%")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (gestureMode != 0) {
                        gestureHint.visibility = View.GONE
                        showControlsTemporarily()
                    }
                    gestureMode = 0
                    true
                }
                else -> true
            }
        }
    }

    private fun showGestureHint(text: String) {
        gestureHint.text = text
        gestureHint.visibility = View.VISIBLE
    }

    private fun toggleControls() = setControlsVisible(!controlsVisible)

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible && !locked
        topBar.visibility = if (controlsVisible) View.VISIBLE else View.GONE
        bottomBar.visibility = if (controlsVisible) View.VISIBLE else View.GONE
        if (player.mediaItemCount == 0) {
            topBar.visibility = View.VISIBLE
            selectButton.visibility = View.VISIBLE
            speedSpinner.visibility = View.GONE
            lockButton.visibility = View.GONE
            bottomBar.visibility = View.GONE
        } else {
            selectButton.visibility = View.GONE
            speedSpinner.visibility = if (controlsVisible) View.VISIBLE else View.GONE
            lockButton.visibility = if (controlsVisible || locked) View.VISIBLE else View.GONE
        }
        if (controlsVisible) scheduleAutoHide() else cancelAutoHide()
    }

    private fun showControlsTemporarily() { setControlsVisible(true) }
    private fun scheduleAutoHide() {
        cancelAutoHide()
        handler.postDelayed(autoHideRunnable, 3500)
    }
    private fun cancelAutoHide() { handler.removeCallbacks(autoHideRunnable) }
    private val autoHideRunnable = Runnable { if (!userSeeking && !locked && player.mediaItemCount > 0) setControlsVisible(false) }

    private fun updateUi() {
        if (!::player.isInitialized) return
        val duration = player.duration
        val current = max(0L, player.currentPosition)
        val validDuration = duration > 0 && duration != C.TIME_UNSET
        val remaining = if (validDuration) max(0L, duration - current) else C.TIME_UNSET
        val actualRemaining = if (remaining != C.TIME_UNSET) (remaining / player.playbackParameters.speed).toLong() else C.TIME_UNSET
        timeLeftText.text = "ACTUAL TIME LEFT  ${formatMs(actualRemaining)}"
        positionText.text = formatMs(current)
        val effectiveDuration = if (validDuration) (duration / player.playbackParameters.speed).toLong() else C.TIME_UNSET
        durationText.text = formatMs(effectiveDuration)
        if (!userSeeking) seekBar.progress = if (validDuration) (current * 1000L / duration).toInt().coerceIn(0, 1000) else 0
        playPauseButton.text = if (player.isPlaying) "Ⅱ" else "▶"
        if (validDuration) {
            val finish = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(System.currentTimeMillis() + actualRemaining))
            timeLeftText.contentDescription = "Actual time left ${formatMs(actualRemaining)}, finish time $finish"
        }
    }

    private val updateRunnable = object : Runnable {
        override fun run() { updateUi(); handler.postDelayed(this, 500) }
    }

    private fun button(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 14f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(0xFF303030.toInt()); isClickable = true
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 12f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
    }
    private fun formatMs(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0L) return "—"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(updateRunnable)
        cancelAutoHide()
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
