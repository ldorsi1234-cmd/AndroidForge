# Alvi Player — MX Player-inspired build

A landscape Android video player built with AndroidX Media3/ExoPlayer.

## Features implemented in source
- Local video selection through Android's document picker.
- Fullscreen landscape playback with system bars hidden.
- MX Player-inspired dark controls, hidden by default during playback and shown by tapping the video; auto-hide after 3.5 seconds.
- Playback speed options from 0.25× to 4×.
- Actual Time Left indicator calculated using current playback speed.
- Play/pause, seek bar, and elapsed/duration display.
- Double-tap left/right to seek backward/forward 10 seconds; double-tap center to play/pause.
- Horizontal swipe to seek; vertical swipe on the left adjusts brightness and on the right adjusts volume.
- Screen lock toggle.

## Build
Upload this ZIP to the `input/` folder in your AndroidForge fork. In GitHub Actions, run **Build Android APK** and set `zip_path` to this exact filename if multiple ZIP files are present. Select `debug` for the build variant.

This source ZIP has not been compiled in this environment. If the GitHub build fails, open the failed `Build project` step and share the first compiler error.
