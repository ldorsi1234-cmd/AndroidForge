package com.example.speedtimeplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

/**
 * Thin vertical level bar for the brightness / volume gestures, in MX Player colours: dark grey track,
 * blue fill from the bottom, and (for volume above 100%) the part past the [splitAt] mark fading to amber.
 */
class LevelBarView(context: Context) : View(context) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5A5A5A.toInt() }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = BLUE }
    private var fraction = 0f
    private var split = 1f

    fun setLevel(level: Float, splitAt: Float = 1f) {
        fraction = level.coerceIn(0f, 1f)
        split = splitAt.coerceIn(0.01f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = w / 2f
        canvas.drawRoundRect(0f, 0f, w, h, r, r, trackPaint)
        if (fraction <= 0f) return
        val top = h * (1f - fraction)
        fillPaint.shader = if (fraction > split) {
            // Past the split mark (volume above 100%): amber at the top, blending into blue at the mark.
            LinearGradient(0f, top, 0f, h * (1f - split), AMBER, BLUE, Shader.TileMode.CLAMP)
        } else null
        fillPaint.color = BLUE
        canvas.drawRoundRect(0f, top, w, h, r, r, fillPaint)
    }

    private companion object {
        const val BLUE = 0xFF3B7CEB.toInt()
        const val AMBER = 0xFFE2C26A.toInt()
    }
}
