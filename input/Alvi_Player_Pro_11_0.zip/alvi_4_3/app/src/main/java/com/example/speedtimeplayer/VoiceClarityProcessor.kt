package com.example.speedtimeplayer

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Voice Clarity level shared by the player and the background service: 0 = off, 1 = light, 2 = balanced, 3 = strong. */
object VoiceClarityState {
    @Volatile var level = 0
}

/**
 * Voice Clarity done inside the audio pipeline (so it works on every phone, unlike system equalizer effects):
 *  1. high-pass filter: removes rumble and hum that eat loudness,
 *  2. presence boost around 2.8 kHz plus a gentle high shelf: makes consonants stand out, which is what
 *     gets lost when a lecture is played at 2x,
 *  3. compressor with make-up gain: raises quiet syllables and the end of sentences, so speech is loud
 *     and even without touching the volume,
 *  4. downward expander: keeps the make-up gain from also lifting room noise and hiss in the pauses,
 *  5. look-ahead peak limiter (1.5 ms): the gain is already down when a peak arrives, so loud speech stays
 *     loud right up to -1 dBFS without the crackle a sample-by-sample soft clipper produces.
 * 16-bit PCM only (what the decoders produce here); anything else passes through untouched.
 */
@UnstableApi
class VoiceClarityProcessor : BaseAudioProcessor() {

    private class Biquad {
        var b0 = 1f; var b1 = 0f; var b2 = 0f; var a1 = 0f; var a2 = 0f
        var z1 = 0f; var z2 = 0f
        fun set(nb0: Double, nb1: Double, nb2: Double, na0: Double, na1: Double, na2: Double) {
            b0 = (nb0 / na0).toFloat(); b1 = (nb1 / na0).toFloat(); b2 = (nb2 / na0).toFloat()
            a1 = (na1 / na0).toFloat(); a2 = (na2 / na0).toFloat()
            z1 = 0f; z2 = 0f
        }
        fun process(x: Float): Float {
            val y = b0 * x + z1
            z1 = b1 * x - a1 * y + z2
            z2 = b2 * x - a2 * y
            return y
        }
    }

    private class Params(
        val highPassHz: Double, val presenceDb: Double, val shelfDb: Double,
        val thresholdDb: Float, val ratio: Float, val makeupDb: Float
    )

    private var sampleRate = 44100
    private var channels = 0
    private var supported = false
    private var appliedLevel = -1

    private var highPass: Array<Biquad> = emptyArray()
    private var presence: Array<Biquad> = emptyArray()
    private var shelf: Array<Biquad> = emptyArray()
    private val frame = FloatArray(MAX_CHANNELS)

    private var attack = 0f
    private var release = 0f
    private var gainSmooth = 0f
    private var threshold = -22f
    private var ratio = 3f
    private var makeupDb = 9f
    private var envelope = 0f
    private var gain = 1f
    private var targetGain = 1f
    private var counter = 0

    // Look-ahead limiter state: the audio is delayed by [lookahead] frames while the peak window is scanned.
    private var lookahead = 64
    private var peakRing = FloatArray(0)
    private var delayLine: Array<FloatArray> = emptyArray()
    private var ringIdx = 0
    private var windowMax = 0f
    private var limGain = 1f
    private var limAttack = 0.1f
    private var limRelease = 0.001f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        supported = inputAudioFormat.encoding == C.ENCODING_PCM_16BIT &&
            inputAudioFormat.channelCount in 1..MAX_CHANNELS && inputAudioFormat.sampleRate > 0
        if (!supported) return AudioProcessor.AudioFormat.NOT_SET // inactive: audio passes untouched
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        highPass = Array(channels) { Biquad() }
        presence = Array(channels) { Biquad() }
        shelf = Array(channels) { Biquad() }
        val fs = sampleRate.toDouble()
        attack = (1.0 - exp(-1.0 / (fs * 0.002))).toFloat()
        release = (1.0 - exp(-1.0 / (fs * 0.100))).toFloat()
        gainSmooth = (1.0 - exp(-1.0 / (fs * 0.003))).toFloat()
        lookahead = (fs * 0.0015).toInt().coerceIn(16, 256)
        peakRing = FloatArray(lookahead)
        delayLine = Array(channels) { FloatArray(lookahead) }
        limAttack = (1.0 - exp(-3.0 / lookahead)).toFloat()
        limRelease = (1.0 - exp(-1.0 / (fs * 0.080))).toFloat()
        resetLimiter()
        appliedLevel = -1
        envelope = 0f
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val level = VoiceClarityState.level
        if (!supported || level <= 0) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        if (level != appliedLevel) configureForLevel(level)

        val ch = channels
        val frames = size / (2 * ch)
        val look = lookahead
        for (i in 0 until frames) {
            var peak = 0f
            for (c in 0 until ch) {
                var v = inputBuffer.short / 32768f
                v = highPass[c].process(v)
                v = presence[c].process(v)
                v = shelf[c].process(v)
                frame[c] = v
                val a = abs(v)
                if (a > peak) peak = a
            }
            // Level follower: fast up, slow down.
            envelope += (peak - envelope) * (if (peak > envelope) attack else release)
            if (++counter >= 16) {
                counter = 0
                val levelDb = 20f * log10(max(envelope, 1e-5f))
                val over = levelDb - threshold
                var gainDb = (if (over > 0f) -over * (1f - 1f / ratio) else 0f) + makeupDb
                // Downward expansion: below about -48 dBFS (room noise, hiss) give back part of the make-up gain.
                if (levelDb < EXPAND_BELOW_DB) gainDb -= min((EXPAND_BELOW_DB - levelDb) * 0.6f, 15f)
                targetGain = 10f.pow(gainDb / 20f)
            }
            gain += (targetGain - gain) * gainSmooth
            var pk = 0f
            for (c in 0 until ch) {
                val y = frame[c] * gain
                frame[c] = y
                val a = abs(y)
                if (a > pk) pk = a
            }
            // Sliding maximum of the last [lookahead] frame peaks (rescanned only when the old maximum leaves).
            val old = peakRing[ringIdx]
            peakRing[ringIdx] = pk
            if (pk >= windowMax) {
                windowMax = pk
            } else if (old >= windowMax) {
                var m = 0f
                for (k in 0 until look) if (peakRing[k] > m) m = peakRing[k]
                windowMax = m
            }
            val limTarget = if (windowMax > CEILING) CEILING / windowMax else 1f
            limGain += (limTarget - limGain) * (if (limTarget < limGain) limAttack else limRelease)
            for (c in 0 until ch) {
                val buf = delayLine[c]
                val delayed = buf[ringIdx]
                buf[ringIdx] = frame[c]
                var s = (delayed * limGain * 32767f).toInt()
                if (s > 32767) s = 32767 else if (s < -32768) s = -32768
                out.putShort(s.toShort())
            }
            if (++ringIdx >= look) ringIdx = 0
        }
        // Any bytes that do not form a whole frame are passed through unchanged.
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }

    private fun configureForLevel(level: Int) {
        val p = when (level) {
            1 -> Params(100.0, 3.0, 1.0, -20f, 2.0f, 7f)
            2 -> Params(120.0, 5.5, 2.5, -24f, 3.0f, 12f)
            else -> Params(140.0, 8.0, 4.0, -28f, 4.0f, 16f)
        }
        val fs = sampleRate.toDouble()
        for (c in 0 until channels) {
            // High-pass, 2nd order, Q = 0.707
            run {
                val w0 = 2 * Math.PI * p.highPassHz / fs; val cs = cos(w0); val al = sin(w0) / (2 * 0.707)
                highPass[c].set((1 + cs) / 2, -(1 + cs), (1 + cs) / 2, 1 + al, -2 * cs, 1 - al)
            }
            // Presence peak at 2.8 kHz, Q = 0.9
            run {
                val a = 10.0.pow(p.presenceDb / 40); val w0 = 2 * Math.PI * 2800.0 / fs
                val cs = cos(w0); val al = sin(w0) / (2 * 0.9)
                presence[c].set(1 + al * a, -2 * cs, 1 - al * a, 1 + al / a, -2 * cs, 1 - al / a)
            }
            // High shelf at 5 kHz
            run {
                val a = 10.0.pow(p.shelfDb / 40); val w0 = 2 * Math.PI * 5000.0 / fs
                val cs = cos(w0); val al = sin(w0) / 2 * sqrt(2.0); val sq = 2 * sqrt(a) * al
                shelf[c].set(
                    a * ((a + 1) + (a - 1) * cs + sq), -2 * a * ((a - 1) + (a + 1) * cs), a * ((a + 1) + (a - 1) * cs - sq),
                    (a + 1) - (a - 1) * cs + sq, 2 * ((a - 1) - (a + 1) * cs), (a + 1) - (a - 1) * cs - sq
                )
            }
        }
        threshold = p.thresholdDb; ratio = p.ratio; makeupDb = p.makeupDb
        gain = 10f.pow(makeupDb / 20f); targetGain = gain
        envelope = 0f; counter = 0
        resetLimiter()
        appliedLevel = level
    }

    private fun resetLimiter() {
        peakRing.fill(0f)
        for (b in delayLine) b.fill(0f)
        ringIdx = 0; windowMax = 0f; limGain = 1f
    }

    private companion object {
        const val MAX_CHANNELS = 8
        const val CEILING = 0.89f          // about -1 dBFS
        const val EXPAND_BELOW_DB = -48f
    }
}
