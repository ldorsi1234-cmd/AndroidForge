# Alvi Player Android project

Built for Android Forge / GitHub Actions. Use Java/Kotlin 17.

## Included
- Alvi Player app label and launcher icon
- Local video picker and Android `ACTION_VIEW` / `ACTION_SEND` video intents for file-manager “Open with” flows
- Resume position saved per URI and a basic playback-history list
- Subtitle file loading (SRT/VTT/SSA/ASS MIME hints where supported)
- Audio/subtitle track selection for tracks exposed by the current media item; subtitle disable option
- Screen-fit cycle: Fit, Stretch, Crop/Zoom
- Saved regular playback speed and selectable hold-to-boost speed; release restores prior speed
- Actual time left calculated using remaining media duration and current playback speed
- Single tap controls; double-tap left/right seek ±10 seconds and center pause/resume without opening full controls
- Brightness and volume gestures
- Voice clarity loudness boost when supported by the device
- Folder picker and a basic list of video files directly inside the selected folder

## Limitations
- Background playback is not implemented as a foreground MediaSessionService in this project; leaving the activity may interrupt video/audio playback.
- Audio delay currently exposes a delay selection UI only. It does not alter decoder audio timing; true audio/video synchronization requires a custom playback pipeline and must be tested against supported formats/devices.
- Folder browsing lists video files directly inside the selected folder, not nested subfolders.
- Subtitle and alternate-track support depends on the media format and what Android Media3 can decode/expose.

## Build
Upload this project ZIP to the repository `input/` directory and run the Android Forge workflow, selecting this exact ZIP. Install the generated APK only after the workflow succeeds.
