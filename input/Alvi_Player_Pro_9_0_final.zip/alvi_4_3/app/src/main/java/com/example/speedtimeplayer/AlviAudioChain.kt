package com.example.speedtimeplayer

import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.audio.AudioProcessorChain
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor

/**
 * Same job as Media3's DefaultAudioProcessorChain (silence skipper, then speed), If [forceSkip] is true the skipper is switched on here
 * regardless of what ExoPlayer signals.
 */
@UnstableApi
class AlviAudioChain(
    private val silence: SilenceSkippingAudioProcessor,
    private val forceSkip: Boolean
) : AudioProcessorChain {

    private val sonic = SonicAudioProcessor()
    private val processors: Array<AudioProcessor> = arrayOf(silence, sonic)

    init {
        silence.setEnabled(forceSkip)
    }

    override fun getAudioProcessors(): Array<AudioProcessor> = processors

    override fun applyPlaybackParameters(playbackParameters: PlaybackParameters): PlaybackParameters {
        sonic.setSpeed(playbackParameters.speed)
        sonic.setPitch(playbackParameters.pitch)
        return playbackParameters
    }

    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean): Boolean {
        val on = forceSkip || skipSilenceEnabled
        silence.setEnabled(on)
        return on
    }

    override fun getMediaDuration(playoutDuration: Long): Long =
        if (sonic.isActive) sonic.getMediaDuration(playoutDuration) else playoutDuration

    override fun getSkippedOutputFrameCount(): Long = silence.skippedFrames
}
