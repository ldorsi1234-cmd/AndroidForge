# Alvi Player Pro 2.6

A fast, study-focused Android video player built on AndroidX Media3 1.5.1.

## UI / playback changes in 2.5
- MX-style compact top control bar and large center play/previous/next controls.
- Bottom control surface reduced to a thin seek bar only; no bottom +/- seek buttons.
- Playback speed is a clock-style top button (◷).
- Voice Clarity has its own top control (CL).
- Auto Skip Silence has its own top control (AS) with Off / Mild / Strong modes.
- Horizontal seeking also changes speed in 0.5x steps: left slows down, right speeds up, with an on-screen hint.
- Folder playlists expose previous/next playback in-app and through the Android media notification.
- Background playback uses Media3 MediaSessionService. The system media controls automatically expose pause and next/previous when a playlist is available.

## Auto Skip Silence
Media3's PCM silence processor is configured directly in the audio sink for two practical modes:
- Mild: trims only longer quiet gaps while preserving more natural pauses.
- Strong: trims shorter/larger silent gaps for tighter lecture/podcast playback.

This detects low-level audio silence, not semantic human speech. It does not use cloud/AI processing.

## Notification controls
Background playback uses a MediaSessionService. When playing a folder playlist, Android's media controls can expose pause and next/previous actions from the active playlist. This follows Media3's recommended background playback architecture.

## Build
- compileSdk / targetSdk: 35
- minSdk: 23
- Java/Kotlin target: 17
- Media3: 1.5.1
- No FFmpeg Maven dependency is included.

This package is source code. APK/device validation must be performed in an Android build environment.


## MX-style long-press speed
Press and hold the video surface to temporarily play at 2× speed. Release immediately restores the user-selected speed. Horizontal swipe remains seek-only. This mirrors the familiar MX Player long-press fast-forward interaction.



## 3.3 MX-style control placement
- Playback OSD follows the supplied MX Player reference layout rather than using a generic control arrangement.
- Top bar: back/title on the left; audio tracks, subtitles, decoder and More on the right.
- Left-side playback cluster: Voice Clarity, Landscape/Portrait, playback speed and Auto Skip Silence.
- Speed button remains tap-to-select and hold + left/right drag for temporary speed, releasing back to the previously selected speed.
- Bottom: elapsed time at left, thin seekbar, remaining time at right; centered previous/play-pause/next controls; lock at lower left; aspect-ratio and fullscreen controls at lower right.
- Horizontal flip remains available; vertical flip remains excluded.
- Lock and playback icons use plain monochrome glyphs.
- Auto Skip Silence remains icon-only with Off/Mild/Strong modes.
- Noise Reduction is not part of the playback OSD.


## 3.4 volume and OSD refinement
- Top and bottom playback OSD panels use a more transparent MX-style black overlay.
- App volume 0–100% maps directly to the Android media-volume range: app 100% equals phone media volume 100%.
- App volume 100–200% keeps the phone at maximum and applies LoudnessEnhancer only to the excess.
- Temporary hold speed uses horizontal left/right drag, matching the requested MX-style interaction.

## 3.7 UI and seek preview improvements
- Refined MX-style top/bottom OSD opacity and spacing.
- Rebuilt the playback seekbar with a cleaner thin track and circular thumb.
- Seek thumbnails use one-second cache buckets and a larger 64-frame cache.
- Preview extraction uses scaled frame decoding on Android 8.1+ and closest-sync extraction to reduce decode latency.
- Cached thumbnails appear immediately while a new frame is decoded in the background.


## 3.9 notification control
- Notification Play/Pause is a service action and does not launch MainActivity.
- A single tap toggles the active foreground player directly and refreshes the notification state.
- Tapping the notification body still opens Alvi Player.


## 4.0 — MX-style player UI/interaction refinement
- Playback overlay reorganized to closely mirror MX Player: top action bar, vertical left tool rail, bottom timeline/transport strip, bottom-corner lock/aspect/fullscreen controls.
- Transparent black gradient overlays replace flat bars for a closer MX-style presentation.
- Playback gestures retained: single tap show/hide controls, double-tap left/right seek, double-tap center play/pause, vertical brightness/volume, pinch zoom/pan, and temporary 2× speed.
- Notification Play/Pause remains a service action and does not open the player.
- This is an MX-style implementation; MX Player proprietary artwork/branding is not copied.


## 4.1 interaction refinements
- Temporary speed hold/drag uses 0.5× steps.
- PiP and Background Playback are visible top-bar buttons.
- Remaining time is estimated at playback speed: 2× /2, 2.5× /3, 3× /4.
- Active toggle buttons change to a white active state.
- Bottom-left has one lock control; resize/aspect remains one dedicated control.
- Status-bar clock/battery can remain visible over the video with transparent system bars.


### 4.2 behavior refinement
- Leaving Alvi Player automatically enters picture-in-picture while a video is playing, unless Background Play has been explicitly enabled.
- Background Play therefore takes priority over automatic PiP.
- Clock/battery status information is hidden during normal playback; a touch starting at the top edge temporarily reveals the Android status bar, then it hides again.


## 4.3 orientation behavior
- Playback remains landscape-only.
- The orientation sensor switches between landscape-left and landscape-right when the phone is rotated.
- Portrait is never selected automatically.


## 4.5 Pro refinement
- Added always-visible top-bar Picture-in-Picture and Background Play buttons.
- Background Play takes priority over automatic PiP when leaving the app.
- Landscape-only sensor rotation now uses a dead-zone to avoid accidental rapid flips through portrait.
- Speed hold/drag remains in 0.5× steps and the active speed is reflected in the control.
- Remaining wall-clock playback time is adjusted by the requested speed mapping (2×→÷2, 2.5×→÷3, 3×→÷4).
- Controls have a subtle pressed animation and active controls use a white selected state.
- Top-edge status-bar reveal remains temporary; clock/battery stay hidden during normal playback.


## 4.6 Landscape rotation direction fix
- Corrected the landscape sensor mapping so rotating the phone toward the user selects the expected landscape side instead of the opposite side.


## Version 4.9 — Automatic PiP fix
- Enabled PiP support on the MainActivity manifest entry (required by Android).
- Automatic PiP is enabled by default and uses Android 12+ auto-enter parameters, with onUserLeaveHint fallback.
- Background Play still takes priority over PiP.


## Version 5.1 — Orientation behavior correction
- Sensor-driven mapping: 90° selects the corrected landscape side; 270° selects the opposite landscape side.
- Orientation button toggles Portrait and sensor-driven Landscape.
- Landscape sensor listener is disabled in Portrait and re-enabled when returning to Landscape.


## Version 5.2 — Clear playback overlays
- Top and bottom playback bars use under 5% black opacity so the video remains clearly visible beneath them.


## Version 5.3 — Smoother Seeking
- Reduced seek-preview debounce for more responsive thumbnail scrubbing.
- Uses nearest decodable sync frame for fast seeking when Fast Seeking is enabled.
- Hides the blocking buffering spinner during playback; this improves visual continuity but cannot eliminate actual source/decoder buffering for every video.


## Version 5.4 — Reliable Auto PiP / Background Play Priority
- Synchronizes Android 12+ automatic PiP entry with actual playback state.
- Automatic PiP is suppressed while Background Play is enabled.
- Updates PiP parameters when playback starts/pauses and when either mode is toggled.
- Keeps the leave-app fallback for supported Android versions.
