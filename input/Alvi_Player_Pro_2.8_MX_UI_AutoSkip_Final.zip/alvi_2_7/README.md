# Alvi Player Pro 2.6

A fast, study-focused Android video player built on AndroidX Media3 1.5.1.

## UI / playback changes in 2.5
- MX-style compact top control bar and large center play/previous/next controls.
- Bottom control surface reduced to a thin seek bar only; no bottom +/- seek buttons.
- Playback speed is a clock-style top button (◷).
- Voice Clarity has its own top control (CL).
- Auto Skip Silence has its own top control (AS) with Off / Mild / Strong modes.
- Horizontal seeking also changes speed in 0.5x steps: left slows down, right speeds up, with an on-screen hint.
- Folder playlists expose previous/next playback in-app and through the Android media notification.
- Background playback uses Media3 MediaSessionService. The system media controls automatically expose pause and next/previous when a playlist is available.

## Auto Skip Silence
Media3's PCM silence processor is configured directly in the audio sink for two practical modes:
- Mild: trims only longer quiet gaps while preserving more natural pauses.
- Strong: trims shorter/larger silent gaps for tighter lecture/podcast playback.

This detects low-level audio silence, not semantic human speech. It does not use cloud/AI processing.

## Notification controls
Background playback uses a MediaSessionService. When playing a folder playlist, Android's media controls can expose pause and next/previous actions from the active playlist. This follows Media3's recommended background playback architecture.

## Build
- compileSdk / targetSdk: 35
- minSdk: 23
- Java/Kotlin target: 17
- Media3: 1.5.1
- No FFmpeg Maven dependency is included.

This package is source code. APK/device validation must be performed in an Android build environment.


## MX-style long-press speed
Press and hold the video surface to temporarily play at 2× speed. Release immediately restores the user-selected speed. Horizontal swipe remains seek-only. This mirrors the familiar MX Player long-press fast-forward interaction.


## 2.8 MX-style player UI and audio controls
- Dedicated icon-only Voice Clarity control (`✦`).
- Dedicated icon-only Noise Reduction control (`≋`) using Android `NoiseSuppressor` when the active audio output supports it.
- Both controls persist their enabled state.
- Accessibility content descriptions remain available even though the visible controls use icons.
