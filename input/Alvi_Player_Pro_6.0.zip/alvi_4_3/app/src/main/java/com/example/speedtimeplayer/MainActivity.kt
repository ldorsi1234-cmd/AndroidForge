package com.example.speedtimeplayer

import android.content.Intent
import android.content.Context
import android.content.pm.ActivityInfo
import android.view.OrientationEventListener
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Equalizer
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.Build
import android.app.PictureInPictureParams
import android.view.ViewConfiguration
import android.util.Rational
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ScaleGestureDetector
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.graphics.Typeface
import android.widget.Toast
import android.util.LruCache
import android.util.TypedValue
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.text.SimpleDateFormat
import java.util.Locale
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.log10

@UnstableApi
class MainActivity : ComponentActivity() {

    private var landscapeOrientationListener: OrientationEventListener? = null
    private var currentLandscapeOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

    private fun enableLandscapeAutoRotation() {
        currentLandscapeOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        requestedOrientation = currentLandscapeOrientation
        landscapeOrientationListener?.disable()
        landscapeOrientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                // Only react to clear landscape orientations. The portrait sectors
                // are deliberately ignored, so tilting through portrait never changes
                // the requested orientation. A small dead-zone prevents rapid flipping.
                // The device sensor direction is opposite to the visual side
                // we want on this landscape player, so map the two landscape
                // sectors explicitly in the corrected direction.
                val target = when {
                    orientation in 70..110 -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                    orientation in 250..290 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    else -> return
                }
                if (target != currentLandscapeOrientation) {
                    currentLandscapeOrientation = target
                    requestedOrientation = target
                }
            }
        }
        if (landscapeOrientationListener?.canDetectOrientation() == true) {
            landscapeOrientationListener?.enable()
        }
    }



    companion object {
        private const val KEY_BACKGROUND_ENABLED = "background_play_enabled"
        private const val SEEK_MAX = 10000L
        private var activeInstance: WeakReference<MainActivity>? = null
        fun toggleFromNotification() {
            activeInstance?.get()?.togglePlaybackFromNotification()
        }
    }
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var orientationButton: TextView
    private lateinit var audioBoostButton: TextView
    private lateinit var leftTools: LinearLayout
    private lateinit var fullscreenButton: TextView
    private lateinit var bottomBar: LinearLayout
    private lateinit var speedButton: TextView
    private lateinit var decoderButton: TextView
    private lateinit var subtitleButton: TextView
    private var volumeBoostEnhancer: LoudnessEnhancer? = null
    private var voiceClarityEqualizer: Equalizer? = null
    private var voiceClarityEnabled = false
    private var voiceClarityAppliedSessionId = 0
    private var selectedSpeed = 2f
    private lateinit var clarityButton: TextView
    private lateinit var autoSkipButton: TextView
    private var autoSkipMode = 0 // 0=off, 1=mild, 2=strong
    private var temporarySpeedActive = false
    private var temporarySpeedPrevious = 1f
    private var longPressSpeedMode = false
    private var longPressStartY = 0f
    private var longPressStartX = 0f
    private var longPressRunnable: Runnable? = null
    private var speedButtonLongPressRunnable: Runnable? = null
    private var speedButtonDownY = 0f
    private var speedButtonDownX = 0f
    private var speedButtonDownAt = 0L
    private val endTemporarySpeedRunnable = Runnable { endTemporarySpeed() }
    private lateinit var timeLeftText: TextView
    private lateinit var playPauseButton: TextView
    private lateinit var previousButton: TextView
    private lateinit var nextButton: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var previewImage: ImageView
    private val previewExecutor = Executors.newSingleThreadExecutor()
    private var previewRequestId = 0L
    private val previewLock = Any()
    private var pendingPreviewPositionMs = 0L
    private var previewFuture: Future<*>? = null
    private var previewRetriever: MediaMetadataRetriever? = null
    private val previewCache = object : LruCache<String, Bitmap>(96) { override fun sizeOf(key: String, value: Bitmap) = 1 }
    private var lastPreviewShownKey: String? = null
    private var previewRetrieverUri: Uri? = null
    private var volumePercent = 100
    private var gestureSensitivity = 1.0f
    private var seekSeconds = 10
    private var subtitleSize = 0.0533f
    private var subtitleBottom = 0.08f
    private var gestureStartVolumePercent = 100
    private var gestureStartSystemVolume = 0
    private var gestureStartSystemMax = 1
    private lateinit var selectButton: TextView
    private lateinit var lockButton: TextView
    private lateinit var pipButton: TextView
    private lateinit var backgroundButton: TextView
    private lateinit var fitButton: TextView
    private lateinit var gestureHint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val hideStatusBarRunnable = Runnable { hideStatusBarOnly() }
    private var controlsVisible = false
    private var locked = false
    private var userSeeking = false
    private var brightnessBeforeGesture = -1f
    private val speeds = listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 2.5f, 3f)
    private data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartPosition = 0L
    private var gestureMode = 0 // 0 unknown, 1 seek, 2 brightness, 3 volume
    private var fitMode = 0
    private val fitModes = listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FIT)
    private val fitModeNames = listOf("Fit", "Stretch", "Crop/Zoom", "Fit with black bars")
    private val historyPrefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }
    private var currentUri: Uri? = null
    private var resumePosition = 0L
    private var subtitleUri: Uri? = null
    private var audioDelayMs = 0
    private var subtitleSyncMs = 0
    private var decoderMode = 1 // 0=HW, 1=HW+, 2=SW
    private var orientationMode = 1 // 1=Landscape, 2=Portrait; playback defaults to landscape
    private var horizontalFlip = false
    private var zoomScale = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastVideoTitle = "Alvi Player"
    private var hapticsEnabled = true
    private var autoPictureInPicture = false
    private var autoSkipSilence = false
    private var fastSeekEnabled = true
    private var repeatMode = Player.REPEAT_MODE_OFF
    private var notificationStarted = false
    private var resumeAfterHandoff = false
    private var lastNotificationPlaying: Boolean? = null
    private var lastNotificationTitle: String? = null
    private var queuedFolderUris: List<Uri> = emptyList()
    private var externalSubtitleCues: List<SubtitleCue> = emptyList()
    private var subtitleExecutor = Executors.newSingleThreadExecutor()
    private lateinit var externalSubtitleView: TextView

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            openVideo(uri, true)
        }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            attachSubtitle(uri)
        }
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
            historyPrefs.edit().putString("folder_uri", uri.toString()).apply()
            Toast.makeText(this, "Folder access saved. Use Folder videos in More to browse files.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activeInstance = WeakReference(this)
        enableLandscapeAutoRotation()
        prepareSystemBars()
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        selectedSpeed = historyPrefs.getFloat("selected_speed", 2f)
        volumePercent = historyPrefs.getInt("volume_percent", 100).coerceIn(0, 200)
        gestureSensitivity = historyPrefs.getFloat("gesture_sensitivity", 1.0f).coerceIn(0.5f, 2.0f)
        seekSeconds = historyPrefs.getInt("seek_seconds", 10).coerceIn(5, 30)
        subtitleSize = historyPrefs.getFloat("subtitle_size", 0.0533f).coerceIn(0.03f, 0.10f)
        subtitleBottom = historyPrefs.getFloat("subtitle_bottom", 0.08f).coerceIn(0f, 0.30f)
        fitMode = historyPrefs.getInt("fit_mode", 0).coerceIn(0, fitModes.lastIndex)
        decoderMode = historyPrefs.getInt("decoder_mode", 1).coerceIn(0, 2)
        orientationMode = historyPrefs.getInt("orientation_mode", 1).coerceIn(1, 2)
        horizontalFlip = historyPrefs.getBoolean("horizontal_flip", false)
        hapticsEnabled = historyPrefs.getBoolean("haptics", true)
        autoPictureInPicture = historyPrefs.getBoolean("auto_pip", true)
        autoSkipMode = historyPrefs.getInt("auto_skip_mode", if (historyPrefs.getBoolean("auto_skip_silence", false)) 1 else 0).coerceIn(0, 2)
        autoSkipSilence = autoSkipMode > 0
        fastSeekEnabled = historyPrefs.getBoolean("fast_seek", true)
        repeatMode = historyPrefs.getInt("repeat_mode", Player.REPEAT_MODE_OFF).coerceIn(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL)
        voiceClarityEnabled = historyPrefs.getBoolean("voice_clarity", false)
        subtitleSyncMs = historyPrefs.getInt("subtitle_sync_ms", 0).coerceIn(-5000, 5000)
        applyOrientationMode()
        applySubtitleStyle()
        buildPlayer()
        player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
        handler.postDelayed({ if (::player.isInitialized) applyGestureVolume(volumePercent) }, 350L)
        playPauseButton.setOnClickListener { if (player.isPlaying) player.pause() else player.play(); updateUi(); showControlsTemporarily() }
        selectButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        lockButton.setOnClickListener {
            if (locked) unlockScreen() else lockScreen()
        }
        updateButtonStates()
                installSpeedButtonGesture()
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                userSeeking = true
                cancelAutoHide()
                val current = player.currentPosition.coerceAtLeast(0L)
                previewImage.visibility = View.VISIBLE
                showSeekPreview(current, true)
            }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && player.duration > 0 && player.duration != C.TIME_UNSET) {
                    val target = player.duration * progress / SEEK_MAX
                    positionText.text = formatMs(target)
                    showSeekPreview(target)
                }
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val duration = player.duration
                if (duration > 0 && duration != C.TIME_UNSET) {
                    val target = (duration * (seekBar?.progress ?: 0) / SEEK_MAX).coerceIn(0L, duration)
                    // Prefer the nearest decodable keyframe for a faster response after scrubbing.
                    player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                    player.seekTo(target)
                }
                userSeeking = false
                previewImage.visibility = View.GONE
                showControlsTemporarily()
            }
        })
        installGestures()
        speedButton.text = speedBtnLabel(selectedSpeed)
        playerView.resizeMode = fitModes[fitMode]
        fitButton.contentDescription = "Screen fit: ${fitModeNames[fitMode]}"
        applyZoom()
        val handledIncoming = handleIncomingIntent(intent)
        if (!handledIncoming && historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)) {
            stopService(Intent(this, BackgroundPlaybackService::class.java).apply { action = BackgroundPlaybackService.ACTION_STOP })
            historyPrefs.edit().putBoolean(BackgroundPlaybackService.KEY_ACTIVE, false).apply()
        }
        if (!handledIncoming) {
            val last = historyPrefs.getString("last_uri", null)
            if (!last.isNullOrBlank()) {
                try {
                    openVideo(Uri.parse(last), true)
                } catch (_: Exception) {
                    Toast.makeText(this, "The last video is no longer accessible", Toast.LENGTH_LONG).show()
                    showHomePanel()
                }
            } else {
                showHomePanel()
            }
        }
        handler.post(updateRunnable)
        setControlsVisible(false)
    }

    private fun showHomePanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(24), dp(28), dp(24)); background = roundedBackground(0xEE171717.toInt(), 24)
        }
        val title = TextView(this).apply { text = "ALVI PLAYER"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val sub = TextView(this).apply { text = "Fast, focused video playback"; textSize = 14f; setTextColor(0xFFBDBDBD.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(18)) }
        panel.addView(title); panel.addView(sub)
        val open = button("Open video")
        val folder = button("Open folder")
        panel.addView(open, LinearLayout.LayoutParams(dp(220), dp(50)).apply { bottomMargin = dp(8) })
        panel.addView(folder, LinearLayout.LayoutParams(dp(220), dp(50)).apply { bottomMargin = dp(16) })
        open.setOnClickListener { pickVideo.launch(arrayOf("video/*")); panel.visibility = View.GONE }
        folder.setOnClickListener { pickFolder.launch(null); panel.visibility = View.GONE }
        val recent = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }.distinctBy { it.toString() }.take(3)
        if (recent.isNotEmpty()) {
            val recentTitle = TextView(this).apply { text = "Recent"; textSize = 13f; setTextColor(0xFF8AB4F8.toInt()); gravity = Gravity.LEFT; setPadding(0, 0, 0, dp(8)) }
            panel.addView(recentTitle, LinearLayout.LayoutParams(-1, -2))
            recent.forEach { uri ->
                val item = TextView(this).apply { text = displayName(uri); textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(10), 0); background = roundedBackground(0xFF252525.toInt(), 12); isClickable = true }
                item.setOnClickListener { openVideo(uri, true); panel.visibility = View.GONE }
                panel.addView(item, LinearLayout.LayoutParams(dp(280), dp(44)).apply { bottomMargin = dp(6) })
            }
        }
        root.addView(panel, FrameLayout.LayoutParams(dp(330), -2, Gravity.CENTER))
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        externalSubtitleView = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.NORMAL); gravity = Gravity.CENTER
            setPadding(dp(18), dp(4), dp(18), dp(4)); setShadowLayer(dp(3).toFloat(), 0f, dp(2).toFloat(), Color.BLACK)
            visibility = View.GONE; maxLines = 4; includeFontPadding = true
        }
        root.addView(externalSubtitleView, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            leftMargin = dp(18); rightMargin = dp(18); bottomMargin = dp(118)
        })

        // MX-style playback OSD: top bar + a single tool row below it + bottom transport strip.
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(2))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x99000000.toInt(), 0x33000000, 0x00000000))
        }
        selectButton = iconBtn(R.drawable.ic_arrow_back, false, 0.5f)
        selectButton.contentDescription = "Back"
        topBar.addView(selectButton, LinearLayout.LayoutParams(dp(52), dp(56)))

        titleView = TextView(this).apply {
            text = lastVideoTitle
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xCC000000.toInt())
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(6), 0, dp(8), 0)
        }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, dp(56), 1f))

        val topAudio = iconBtn(R.drawable.ic_music_note, false, 0.5f)
        topAudio.contentDescription = "Audio tracks"
        topBar.addView(topAudio, LinearLayout.LayoutParams(dp(50), dp(56)))
        topAudio.setOnClickListener { showTrackDialog() }

        val topSubtitle = iconBtn(R.drawable.ic_subtitles, false, 0.5f)
        topSubtitle.contentDescription = "Subtitles"
        subtitleButton = topSubtitle
        topBar.addView(topSubtitle, LinearLayout.LayoutParams(dp(50), dp(56)))
        topSubtitle.setOnClickListener { showTrackDialog() }

        decoderButton = plainIconButton(decoderShortLabel(), 16f)
        decoderButton.contentDescription = "Decoder: ${decoderName()}"
        topBar.addView(decoderButton, LinearLayout.LayoutParams(dp(60), dp(56)))

        pipButton = iconBtn(R.drawable.ic_pip, false, 0.5f)
        pipButton.contentDescription = "Picture-in-picture"
        topBar.addView(pipButton, LinearLayout.LayoutParams(dp(50), dp(56)))
        pipButton.setOnClickListener { enterPip(); showControlsTemporarily() }

        backgroundButton = iconBtn(R.drawable.ic_headset, false, 0.5f)
        backgroundButton.contentDescription = "Background play"
        topBar.addView(backgroundButton, LinearLayout.LayoutParams(dp(50), dp(56)))
        backgroundButton.setOnClickListener { toggleBackgroundPlayback(); updateButtonStates(); showControlsTemporarily() }

        val moreButton = iconBtn(R.drawable.ic_more_vert, false, 0.5f)
        moreButton.contentDescription = "More options"
        topBar.addView(moreButton, LinearLayout.LayoutParams(dp(46), dp(56)))
        moreButton.setOnClickListener { showMoreDialog() }
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP))

        // MX-style tool row: rotate, speed, skip silence, voice clarity (blue when active).
        leftTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        orientationButton = iconBtn(R.drawable.ic_screen_rotation, true, 0.54f)
        orientationButton.contentDescription = "Change landscape or portrait"
        leftTools.addView(orientationButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) })
        orientationButton.setOnClickListener { toggleOrientation() }

        speedButton = iconBtn(0, true, 0.5f).apply { text = speedBtnLabel(selectedSpeed); textSize = 15f; setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD)) }
        speedButton.contentDescription = "Playback speed. Tap to select; press and drag left/right to temporarily change speed."
        leftTools.addView(speedButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) })

        autoSkipButton = iconBtn(R.drawable.ic_graphic_eq, true, 0.54f)
        autoSkipButton.contentDescription = "Auto Skip Silence"
        leftTools.addView(autoSkipButton, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(12) })

        audioBoostButton = iconBtn(R.drawable.ic_mic, true, 0.54f)
        audioBoostButton.contentDescription = "Voice clarity"
        clarityButton = audioBoostButton
        leftTools.addView(audioBoostButton, LinearLayout.LayoutParams(dp(46), dp(46)))
        audioBoostButton.setOnClickListener { showVoiceClarityDialog() }
        root.addView(leftTools, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply {
            leftMargin = dp(16); topMargin = dp(64)
        })

        selectButton.setOnClickListener {
            if (player.mediaItemCount > 0) onBackPressedDispatcher.onBackPressed()
            else pickVideo.launch(arrayOf("video/*"))
        }
        decoderButton.setOnClickListener { showDecoderDialog() }
        autoSkipButton.setOnClickListener { showAutoSkipSilenceDialog() }

        // Bottom MX-style timeline: elapsed | seekbar | remaining, then centered transport controls.
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), 0)
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0x99000000.toInt(), 0x33000000, 0x00000000))
        }
        val timelineRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        positionText = label("0:00").apply { textSize = 15f; gravity = Gravity.CENTER }
        durationText = label("0:00").apply { textSize = 15f; gravity = Gravity.CENTER }
        seekBar = SeekBar(this).apply {
            max = SEEK_MAX.toInt()
            progress = 0
            minHeight = dp(28)
            minimumHeight = dp(28)
            setPadding(dp(8), 0, dp(8), 0)
            thumbOffset = dp(8)
            progressDrawable = createProfessionalSeekTrack()
            thumb = createSeekThumb()
        }
        timelineRow.addView(positionText, LinearLayout.LayoutParams(dp(70), dp(36)))
        timelineRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(36), 1f))
        timelineRow.addView(durationText, LinearLayout.LayoutParams(dp(70), dp(36)))
        bottomBar.addView(timelineRow, LinearLayout.LayoutParams(-1, dp(38)))

        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        previousButton = iconBtn(R.drawable.ic_skip_previous, false, 0.5f); previousButton.contentDescription = "Previous"
        playPauseButton = iconBtn(R.drawable.ic_pause, false, 0.6f); playPauseButton.contentDescription = "Play or pause"
        nextButton = iconBtn(R.drawable.ic_skip_next, false, 0.5f); nextButton.contentDescription = "Next"
        transport.addView(previousButton, LinearLayout.LayoutParams(dp(72), dp(58)))
        transport.addView(playPauseButton, LinearLayout.LayoutParams(dp(92), dp(62)))
        transport.addView(nextButton, LinearLayout.LayoutParams(dp(72), dp(58)))
        bottomBar.addView(transport, LinearLayout.LayoutParams(-1, dp(64)))
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(112), Gravity.BOTTOM))

        lockButton = iconBtn(R.drawable.ic_lock_open, false, 0.5f)
        setLockIcon(false)
        root.addView(lockButton, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(10); bottomMargin = dp(6)
        })

        // The extra "↔" button stays removed (5.9). fitButton is only a detached view so older
        // state-update code keeps compiling; the far-right button opens Screen Fit.
        fitButton = plainIconButton("", 24f)
        fitButton.contentDescription = "Screen fit / aspect ratio"

        fullscreenButton = iconBtn(R.drawable.ic_fullscreen, false, 0.5f)
        fullscreenButton.contentDescription = "Screen fit / aspect ratio"
        root.addView(fullscreenButton, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(10); bottomMargin = dp(6)
        })
        fullscreenButton.setOnClickListener { showFitOptions() }

        gestureHint = TextView(this).apply {
            text = ""; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10)); background = roundedBackground(0xCC111111.toInt(), 20); visibility = View.GONE
        }
        root.addView(gestureHint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        previewImage = ImageView(this).apply {
            visibility = View.GONE
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xE6111111.toInt())
            setPadding(dp(1), dp(1), dp(1), dp(1))
            background = roundedBackground(0xE6111111.toInt(), 8)
            elevation = dp(6).toFloat()
        }
        root.addView(previewImage, FrameLayout.LayoutParams(dp(320), dp(180), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(122) })

        timeLeftText = label("").apply { visibility = View.GONE }
        setContentView(root)

        playPauseButton.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
            updateUi(); showControlsTemporarily()
        }
        previousButton.setOnClickListener {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else seekFast(max(0L, player.currentPosition - seekSeconds * 1000L))
            showControlsTemporarily()
        }
        nextButton.setOnClickListener {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem() else Toast.makeText(this, "No next video", Toast.LENGTH_SHORT).show()
            showControlsTemporarily()
        }
        lockButton.setOnClickListener { if (locked) unlockScreen() else lockScreen() }
    }


    /**
     * Fast ±10-second gesture seek. CLOSEST_SYNC lets Media3 land on a nearby
     * keyframe instead of waiting for an exact frame; this can reduce seek delay,
     * but exact zero-buffer seeking cannot be guaranteed for every file/source.
     */
    private fun seekFast(targetMs: Long) {
        val duration = player.duration
        val safeTarget = if (duration > 0 && duration != C.TIME_UNSET) targetMs.coerceAtMost(duration) else targetMs
        if (fastSeekEnabled) {
            player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
            player.seekTo(safeTarget)
            handler.removeCallbacks(restoreSeekParametersRunnable)
            handler.postDelayed(restoreSeekParametersRunnable, 700L)
        } else {
            player.setSeekParameters(SeekParameters.EXACT)
            player.seekTo(safeTarget)
        }
    }

    private val restoreSeekParametersRunnable = Runnable {
        if (::player.isInitialized) player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
    }

    private val hideLockRunnable = Runnable {
        if (locked) lockButton.animate().alpha(0f).setDuration(180L).withEndAction { if (locked) lockButton.visibility = View.GONE }.start()
    }

    /** Padlock icon: plain open padlock when unlocked, closed padlock on a red circle when locked. */
    private fun setLockIcon(isLocked: Boolean) {
        (lockButton.tag as? BtnState)?.let {
            it.res = if (isLocked) R.drawable.ic_lock else R.drawable.ic_lock_open
            it.circle = isLocked
            it.color = if (isLocked) 0xFFD32F2F.toInt() else 0
        }
        renderButton(lockButton)
        lockButton.contentDescription = if (isLocked) "Screen locked. Tap to unlock" else "Lock screen"
    }

    /** Briefly shows the red closed padlock so the locked state is obvious. */
    private fun flashLockButton() {
        setLockIcon(true)
        handler.removeCallbacks(hideLockRunnable)
        lockButton.animate().cancel()
        lockButton.alpha = 0f
        lockButton.visibility = View.VISIBLE
        lockButton.animate().alpha(1f).setDuration(160L).start()
        handler.postDelayed(hideLockRunnable, 1800L)
    }

    private fun lockScreen() {
        locked = true
        setControlsVisible(false)
        flashLockButton()
        Toast.makeText(this, "Screen locked", Toast.LENGTH_SHORT).show()
    }

    private fun unlockScreen() {
        locked = false
        handler.removeCallbacks(hideLockRunnable)
        lockButton.animate().cancel()
        setLockIcon(false)
        lockButton.alpha = 1f
        setControlsVisible(true)
        Toast.makeText(this, "Screen unlocked", Toast.LENGTH_SHORT).show()
    }

    /** MX-style hold-and-drag speed control. Hold the video, then move left/right. */
    private fun startTemporarySpeed(startX: Float) {
        if (temporarySpeedActive || !::player.isInitialized || player.mediaItemCount == 0) return
        temporarySpeedPrevious = selectedSpeed
        longPressStartX = startX
        temporarySpeedActive = true
        longPressSpeedMode = true
        // Hold keeps the current (default) speed; dragging right/left then raises/lowers it in 0.5× steps.
        showGestureHint(speedLabel(selectedSpeed))
        haptic()
    }

    private fun applyTemporarySpeedDrag(dx: Float, stepPx: Float) {
        if (!::player.isInitialized || stepPx <= 0f) return
        val steps = (dx / stepPx).toInt()
        val speed = (temporarySpeedPrevious + steps * 0.5f).coerceIn(0.25f, 3f)
        if (player.playbackParameters.speed == speed) return
        player.setPlaybackSpeed(speed)
        showGestureHint(speedLabel(speed))
        if (::speedButton.isInitialized) speedButton.text = speedBtnLabel(speed)
        haptic()
    }

    private fun endTemporarySpeed() {
        longPressRunnable?.let { handler.removeCallbacks(it) }
        longPressRunnable = null
        if (!temporarySpeedActive || !::player.isInitialized) return
        temporarySpeedActive = false
        longPressSpeedMode = false
        player.setPlaybackSpeed(temporarySpeedPrevious)
        if (::speedButton.isInitialized) speedButton.text = speedBtnLabel(temporarySpeedPrevious)
        gestureHint.visibility = View.GONE
    }

    /** MX-style speed button gesture: hold the 2×/speed control, then drag left/right.
     * Drag right increases temporary speed; drag left decreases it. Release restores the
     * previously selected speed. A short tap still opens the normal speed selector.
     */
    private fun installSpeedButtonGesture() {
        speedButton.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    speedButtonDownY = event.rawY
                    speedButtonDownAt = SystemClock.elapsedRealtime()
                    speedButtonDownX = event.rawX
                    speedButtonLongPressRunnable?.let { handler.removeCallbacks(it) }
                    speedButtonLongPressRunnable = Runnable {
                        if (::player.isInitialized && player.mediaItemCount > 0) {
                            startTemporarySpeed(speedButtonDownX)
                        }
                    }
                    handler.postDelayed(speedButtonLongPressRunnable!!, 220L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (temporarySpeedActive) {
                        // Stepped temporary speed: every horizontal step changes by exactly 0.5×.
                        applyTemporarySpeedDrag(event.rawX - speedButtonDownX, dp(70).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    speedButtonLongPressRunnable?.let { handler.removeCallbacks(it) }
                    speedButtonLongPressRunnable = null
                    if (temporarySpeedActive) {
                        endTemporarySpeed()
                    } else if (event.actionMasked == MotionEvent.ACTION_UP && SystemClock.elapsedRealtime() - speedButtonDownAt < 500L) {
                        showSpeedDialog()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun installGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) flashLockButton() else toggleControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (e.x < root.width * 0.35f) seekFast(max(0L, player.currentPosition - seekSeconds * 1000L))
                else if (e.x > root.width * 0.65f) seekFast(player.currentPosition + seekSeconds * 1000L)
                else if (zoomScale > 1.01f) resetZoom() else if (player.isPlaying) player.pause() else player.play()
                haptic(); return true
            }
        })
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (locked || player.mediaItemCount == 0) return true
                longPressRunnable?.let { handler.removeCallbacks(it) }
                zoomScale = (zoomScale * detector.scaleFactor).coerceIn(1f, 4f)
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; applyZoom(); return true
            }
        })
        playerView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event); detector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    // A touch/swipe starting at the very top temporarily reveals the
                    // system clock/battery without leaving a permanent status bar.
                    if (event.y <= dp(44)) showStatusBarTemporarily()
                    gestureStartX = event.x; gestureStartY = event.y; gestureStartPosition = player.currentPosition; gestureMode = 0
                    longPressStartY = event.y
                    longPressStartX = event.x
                    longPressRunnable?.let { handler.removeCallbacks(it) }
                    longPressRunnable = Runnable {
                        if (!locked && player.mediaItemCount > 0 && gestureMode == 0) startTemporarySpeed(gestureStartX)
                    }
                    handler.postDelayed(longPressRunnable!!, ViewConfiguration.getLongPressTimeout().toLong())
                    brightnessBeforeGesture = window.attributes.screenBrightness
                    if (brightnessBeforeGesture < 0f) brightnessBeforeGesture = 0.5f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (locked) return@setOnTouchListener true
                    if (longPressSpeedMode) {
                        // Every 10% of screen width dragged = one 0.5× step. Release restores the default speed.
                        applyTemporarySpeedDrag(event.x - longPressStartX, root.width * 0.10f)
                        return@setOnTouchListener true
                    }
                    if (event.pointerCount >= 2 && zoomScale > 1.01f) {
                        longPressRunnable?.let { handler.removeCallbacks(it) }
                        panX += event.x - gestureStartX; panY += event.y - gestureStartY; gestureStartX = event.x; gestureStartY = event.y; applyZoom()
                        return@setOnTouchListener true
                    }
                    val dx = event.x - gestureStartX; val dy = event.y - gestureStartY
                    if (gestureMode == 0 && (abs(dx) > dp(18) || abs(dy) > dp(18))) {
                        // Let a genuine long-press speed gesture win once the hold has matured.
                        if (!temporarySpeedActive) {
                            longPressRunnable?.let { handler.removeCallbacks(it) }
                            longPressRunnable = null
                            gestureMode = if (abs(dx) > abs(dy)) 1 else if (gestureStartX < root.width / 2f) 2 else 3
                        }
                        if (gestureMode == 3) {
                            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                            gestureStartSystemVolume = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                            gestureStartSystemMax = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                            gestureStartVolumePercent = volumePercent
                        }
                        cancelAutoHide()
                    }
                    when (gestureMode) {
                        1 -> {
                            val delta = (dx / root.width * 120_000L * gestureSensitivity).toLong(); val target = max(0L, gestureStartPosition + delta)
                            player.seekTo(if (player.duration > 0 && player.duration != C.TIME_UNSET) target.coerceAtMost(player.duration) else target)
                            showGestureHint("${if (delta >= 0) "+" else "−"}${formatMs(abs(delta))}")
                        }
                        2 -> {
                            val value = (brightnessBeforeGesture - (dy / root.height) * gestureSensitivity).coerceIn(0f, 1f)
                            val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                            showGestureHint("Brightness ${(value * 100).roundToInt()}%")
                        }
                        3 -> {
                            val deltaPercent = (-dy / root.height * 200f * gestureSensitivity).roundToInt()
                            applyGestureVolume((gestureStartVolumePercent + deltaPercent).coerceIn(0, 200)); showGestureHint("Volume $volumePercent%")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressRunnable?.let { handler.removeCallbacks(it) }; longPressRunnable = null
                    if (temporarySpeedActive) endTemporarySpeed()
                    if (gestureMode != 0) { gestureHint.visibility = View.GONE; showControlsTemporarily() }
                    gestureMode = 0; true
                }
                else -> true
            }
        }
    }

    private fun handleIncomingIntent(incoming: Intent?): Boolean {
        val uri = incoming?.data ?: if (android.os.Build.VERSION.SDK_INT >= 33) {
            incoming?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") incoming?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (uri == null) return false
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        openVideo(uri, true)
        return true
    }

    private fun openVideo(uri: Uri, resume: Boolean) {
        saveCurrentProgress()
        currentUri = uri
        lastVideoTitle = displayName(uri)
        val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
        subtitleUri = savedSubtitle
        externalSubtitleCues = emptyList()
        externalSubtitleView.text = ""
        externalSubtitleView.visibility = View.GONE
        val item = if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri)
        player.setMediaItem(item)
        player.prepare()
        if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
        val saved = if (resume) historyPrefs.getLong("pos_${uri}", 0L) else 0L
        player.seekTo(saved)
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        historyPrefs.edit().putString("last_uri", uri.toString())
            .putString("history_${System.currentTimeMillis()}", uri.toString())
            .putString("name_${uri}", displayName(uri)).apply()
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateUi()
    }

    private fun saveCurrentProgress() {
        if (!::player.isInitialized) return
        val uri = currentUri ?: return
        historyPrefs.edit().putLong("pos_${uri}", max(0L, player.currentPosition))
            .putString("name_${uri}", displayName(uri)).putString("last_uri", uri.toString()).apply()
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "Video"
        try { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (_: Exception) { }
        return name
    }

    private fun subtitleExtension(uri: Uri): String =
        uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase(Locale.ROOT) ?: ""

    private fun isCustomSubtitle(uri: Uri): Boolean =
        subtitleExtension(uri) == "srt" || subtitleExtension(uri) == "vtt"

    private fun buildVideoItem(video: Uri, subtitle: Uri): MediaItem {
        if (isCustomSubtitle(subtitle)) return MediaItem.fromUri(video)
        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(subtitle)
            .setMimeType(when (subtitleExtension(subtitle)) {
                "srt" -> MimeTypes.APPLICATION_SUBRIP
                "vtt" -> MimeTypes.TEXT_VTT
                "ssa", "ass" -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            })
            .setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        return MediaItem.Builder().setUri(video).setSubtitleConfigurations(listOf(subtitleConfig)).build()
    }

    private fun applySubtitleStyle() {
        playerView.subtitleView?.apply {
            setFractionalTextSize(subtitleSize)
            setBottomPaddingFraction(subtitleBottom)
        }
        if (::externalSubtitleView.isInitialized) {
            externalSubtitleView.textSize = (subtitleSize * 100f * 0.34f).coerceIn(14f, 34f)
            (externalSubtitleView.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
                lp.bottomMargin = dp((82 + subtitleBottom * 260f).roundToInt())
                externalSubtitleView.layoutParams = lp
            }
        }
    }

    private fun attachSubtitle(uri: Uri) {
        val video = currentUri
        if (video == null) { Toast.makeText(this, "Open a video first", Toast.LENGTH_SHORT).show(); return }
        subtitleUri = uri
        historyPrefs.edit().putString("subtitle_${video}", uri.toString()).apply()
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        externalSubtitleCues = emptyList()
        externalSubtitleView.text = ""
        externalSubtitleView.visibility = View.GONE
        player.setMediaItem(buildVideoItem(video, uri))
        applySubtitleStyle()
        player.prepare(); player.seekTo(pos); player.playWhenReady = wasPlaying
        if (isCustomSubtitle(uri)) loadExternalSubtitle(uri)
        Toast.makeText(this, "Subtitle loaded", Toast.LENGTH_SHORT).show()
    }

    private fun loadExternalSubtitle(uri: Uri) {
        val requestUri = uri.toString()
        subtitleExecutor.execute {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("Unable to read subtitle")
                val cues = parseSubtitle(text, subtitleExtension(uri))
                handler.post {
                    if (currentUri != null && historyPrefs.getString("subtitle_${currentUri}", null) == requestUri) {
                        externalSubtitleCues = cues
                        applySubtitleStyle()
                        updateExternalSubtitle()
                    }
                }
            } catch (_: Exception) {
                handler.post { Toast.makeText(this, "Could not read subtitle file", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun parseSubtitle(source: String, extension: String): List<SubtitleCue> {
        val normalized = source.replace("\r\n", "\n").replace('\r', '\n')
        if (extension == "vtt") return parseVtt(normalized)
        return parseSrt(normalized)
    }

    private fun parseSrt(source: String): List<SubtitleCue> {
        return source.split(Regex("\\n\\s*\\n")).mapNotNull { block ->
            val lines = block.lines().filter { it.isNotBlank() }
            if (lines.size < 2) return@mapNotNull null
            val timingIndex = lines.indexOfFirst { it.contains(" --> ") }
            if (timingIndex < 0 || timingIndex + 1 >= lines.size) return@mapNotNull null
            val parts = lines[timingIndex].split(" --> ")
            if (parts.size != 2) return@mapNotNull null
            val start = parseSubtitleTime(parts[0]) ?: return@mapNotNull null
            val end = parseSubtitleTime(parts[1].split(' ').first()) ?: return@mapNotNull null
            val body = lines.drop(timingIndex + 1).joinToString("\n").trim()
            if (body.isBlank()) null else SubtitleCue(start, end, body)
        }.sortedBy { it.startMs }
    }

    private fun parseVtt(source: String): List<SubtitleCue> {
        return source.lines().dropWhile { !it.contains("WEBVTT", ignoreCase = true) }.drop(1)
            .joinToString("\n").split(Regex("\\n\\s*\\n")).mapNotNull { block ->
                val lines = block.lines().filter { it.isNotBlank() }
                val timingIndex = lines.indexOfFirst { it.contains(" --> ") }
                if (timingIndex < 0 || timingIndex + 1 >= lines.size) return@mapNotNull null
                val parts = lines[timingIndex].split(" --> ")
                if (parts.size != 2) return@mapNotNull null
                val start = parseSubtitleTime(parts[0]) ?: return@mapNotNull null
                val end = parseSubtitleTime(parts[1].trim().split(' ').first()) ?: return@mapNotNull null
                val body = lines.drop(timingIndex + 1).joinToString("\n").trim()
                if (body.isBlank()) null else SubtitleCue(start, end, body)
            }.sortedBy { it.startMs }
    }

    private fun parseSubtitleTime(value: String): Long? {
        val cleaned = value.trim().replace(',', '.')
        val parts = cleaned.split(':')
        return try {
            val seconds = when (parts.size) {
                3 -> parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toDouble()
                2 -> parts[0].toLong() * 60 + parts[1].toDouble()
                else -> return null
            }
            (seconds * 1000.0).roundToInt().toLong()
        } catch (_: Exception) { null }
    }

    private fun updateExternalSubtitle() {
        if (!::externalSubtitleView.isInitialized || externalSubtitleCues.isEmpty() || !::player.isInitialized) return
        val adjustedPosition = player.currentPosition - subtitleSyncMs
        var low = 0
        var high = externalSubtitleCues.lastIndex
        var candidate = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (externalSubtitleCues[mid].startMs <= adjustedPosition) {
                candidate = mid
                low = mid + 1
            } else high = mid - 1
        }
        val cue = if (candidate >= 0) externalSubtitleCues[candidate] else null
        if (cue != null && adjustedPosition <= cue.endMs) {
            if (externalSubtitleView.text.toString() != cue.text) externalSubtitleView.text = cue.text
            externalSubtitleView.visibility = View.VISIBLE
        } else {
            externalSubtitleView.visibility = View.GONE
        }
    }

    private fun showSubtitleSyncDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        val valueLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(8)) }
        val bar = SeekBar(this).apply { max = 10000; progress = subtitleSyncMs + 5000 }
        fun updateLabel() {
            subtitleSyncMs = (bar.progress - 5000).coerceIn(-5000, 5000)
            valueLabel.text = if (subtitleSyncMs == 0) "No delay" else if (subtitleSyncMs > 0) "+${subtitleSyncMs} ms" else "${subtitleSyncMs} ms"
            historyPrefs.edit().putInt("subtitle_sync_ms", subtitleSyncMs).apply()
            updateExternalSubtitle()
        }
        box.addView(valueLabel); box.addView(bar)
        updateLabel()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) updateLabel() }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        AlertDialog.Builder(this).setTitle("Subtitle synchronization").setMessage("Positive values delay subtitles; negative values make them appear earlier.")
            .setView(box).setPositiveButton("Done", null).setNeutralButton("Reset") { _, _ -> subtitleSyncMs = 0; historyPrefs.edit().putInt("subtitle_sync_ms", 0).apply(); updateExternalSubtitle() }.show()
    }

    private val previewRunnable = Runnable {
        val uri = currentUri ?: return@Runnable
        val requestId = ++previewRequestId
        val target = pendingPreviewPositionMs.coerceAtLeast(0L)
        previewFuture?.cancel(true)
        previewFuture = previewExecutor.submit {
            try {
                if (previewRetrieverUri != uri || previewRetriever == null) {
                    try { previewRetriever?.release() } catch (_: Exception) { }
                    previewRetriever = MediaMetadataRetriever()
                    contentResolver.openFileDescriptor(uri, "r")?.use { previewRetriever!!.setDataSource(it.fileDescriptor) }
                        ?: throw IllegalStateException("Unable to open video")
                    previewRetrieverUri = uri
                }

                // High-quality 500 ms buckets keep previews responsive without sacrificing visible detail.
                // Decode directly to the preview resolution rather than using low-resolution thumbnails.
                val bucket = (target / 500L) * 500L
                val cacheKey = "${uri}#$bucket"
                val cached = previewCache.get(cacheKey)
                val bitmap = cached ?: run {
                    val retriever = previewRetriever ?: return@run null
                    val frame = if (Build.VERSION.SDK_INT >= 27) {
                        retriever.getScaledFrameAtTime(
                            bucket * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                            dp(320),
                            dp(180)
                        )
                    } else {
                        retriever.getFrameAtTime(bucket * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }
                    frame?.let {
                        val scaled = if (Build.VERSION.SDK_INT < 27 && (it.width > dp(640) || it.height > dp(360))) {
                            Bitmap.createScaledBitmap(it, dp(320), dp(180), true).also { scaled -> if (scaled !== it) it.recycle() }
                        } else it
                        previewCache.put(cacheKey, scaled)
                        scaled
                    }
                }

                handler.post {
                    if (requestId == previewRequestId && userSeeking && bitmap != null) {
                        previewImage.setImageBitmap(bitmap)
                        previewImage.visibility = View.VISIBLE
                        lastPreviewShownKey = cacheKey
                    }
                }
            } catch (_: Exception) {
                handler.post {
                    if (requestId == previewRequestId && userSeeking && lastPreviewShownKey == null) previewImage.visibility = View.GONE
                }
            }
        }
    }

    private fun showSeekPreview(positionMs: Long, immediate: Boolean = false) {
        pendingPreviewPositionMs = positionMs.coerceAtLeast(0L)
        val bucket = (pendingPreviewPositionMs / 500L) * 500L
        val key = "${currentUri ?: return}#$bucket"
        previewCache.get(key)?.let {
            previewImage.setImageBitmap(it)
            previewImage.visibility = View.VISIBLE
            lastPreviewShownKey = key
        }
        handler.removeCallbacks(previewRunnable)
        handler.postDelayed(previewRunnable, if (immediate) 0L else 25L)
    }

    private fun createProfessionalSeekTrack(): LayerDrawable {
        val track = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(2).toFloat()
            setColor(0x668A8A8A)
        }
        val progress = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(2).toFloat()
            setColor(0xFF5DA9E9.toInt())
        }
        val clipped = ClipDrawable(progress, Gravity.START, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf(track, clipped)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
            setLayerHeight(0, dp(4))
            setLayerHeight(1, dp(4))
            setLayerGravity(0, Gravity.CENTER_VERTICAL)
            setLayerGravity(1, Gravity.CENTER_VERTICAL)
        }
    }

    private fun createSeekThumb(): android.graphics.drawable.Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF5DA9E9.toInt())
            setSize(dp(16), dp(16))
        }
    }

    private fun showFitOptions() {
        val labels = fitModeNames.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Screen fit")
            .setSingleChoiceItems(labels, fitMode) { dialog, which ->
                fitMode = which
                playerView.resizeMode = fitModes[fitMode]
                zoomScale = 1f; panX = 0f; panY = 0f; applyZoom()
                historyPrefs.edit().putInt("fit_mode", fitMode).apply()
                fitButton.contentDescription = "Screen fit: ${fitModeNames[fitMode]}"
                dialog.dismiss()
                showControlsTemporarily()
            }
            .setNeutralButton(if (horizontalFlip) "Horizontal flip: ON" else "Horizontal flip: OFF") { _, _ ->
                horizontalFlip = !horizontalFlip
                historyPrefs.edit().putBoolean("horizontal_flip", horizontalFlip).apply()
                applyZoom()
                showControlsTemporarily()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showMoreDialog() {
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        fun section(title: String) {
            val v = TextView(this).apply {
                text = title.uppercase(Locale.getDefault())
                textSize = 12f
                setTextColor(0xFF8AB4F8.toInt())
                setPadding(dp(12), dp(14), dp(12), dp(6))
            }
            content.addView(v)
        }
        fun action(title: String, onClick: () -> Unit) {
            val v = TextView(this).apply {
                text = title
                textSize = 15f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(14), dp(13))
                background = roundedBackground(0xFF252525.toInt(), 12)
                isClickable = true
                setOnClickListener { onClick() }
            }
            content.addView(v, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(6) })
        }

        section("Playback")
        action("Resume current video") {
            val uri = currentUri
            if (uri != null) player.seekTo(historyPrefs.getLong("pos_${uri}", player.currentPosition))
            else Toast.makeText(this, "No current video", Toast.LENGTH_SHORT).show()
        }
        action("Playback history") { showHistoryDialog() }
        action("Seek amount · ${seekSeconds} sec") { showSeekAmountDialog() }
        action("Gesture sensitivity · ${gestureSensitivity}×") { showGestureSensitivityDialog() }
        action("Speed hold + drag · 0.5× steps") { Toast.makeText(this, "Hold the speed button and drag left/right. Each step changes speed by 0.5×; release restores the previous speed.", Toast.LENGTH_LONG).show() }
        action("Auto Skip Silence · ${when (autoSkipMode) { 1 -> "Mild"; 2 -> "Strong"; else -> "Off" }}") { showAutoSkipSilenceDialog() }
        action("Fast seeking · ${if (fastSeekEnabled) "On" else "Off"}") { showFastSeekDialog() }
        action("Repeat · ${repeatName()}") { showRepeatDialog() }
        action("Video information") { showVideoInfo() }

        section("Display")
        action("Screen fit · ${fitModeNames[fitMode]}") { showFitOptions() }
        action("Orientation") { showOrientationDialog() }
        action("Pinch zoom · ${(zoomScale * 100).roundToInt()}%") { resetZoom(); Toast.makeText(this, "Zoom reset", Toast.LENGTH_SHORT).show() }
        action("Subtitle appearance") { showSubtitleAppearanceDialog() }
        action("Haptic feedback · ${if (hapticsEnabled) "On" else "Off"}") { showHapticsDialog() }

        section("Decoder")
        action("Decoder · ${decoderName()}") { showDecoderDialog() }

        section("Audio & subtitles")
        action("Volume boost · ${volumePercent}%") { showVolumeDialog() }
        action("Reset volume to 100%") { applyGestureVolume(100); Toast.makeText(this, "Volume reset to 100%", Toast.LENGTH_SHORT).show() }
        action("Voice Clarity · ${if (voiceClarityEnabled) "On" else "Off"}") { showVoiceClarityDialog() }
        action("Audio / subtitle tracks") { showTrackDialog() }
        action("Load subtitle file") { pickSubtitle.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "application/octet-stream")) }
        action("Subtitle synchronization · ${if (subtitleSyncMs > 0) "+" else ""}${subtitleSyncMs} ms") { showSubtitleSyncDialog() }
                action("Picture-in-picture") { enterPip() }
        action("Background play · ${if (isBackgroundPlaybackActive()) "On" else "Off"}") { toggleBackgroundPlayback() }
        action("Automatic picture-in-picture · ${if (autoPictureInPicture) "On" else "Off"}") {
            autoPictureInPicture = !autoPictureInPicture
            historyPrefs.edit().putBoolean("auto_pip", autoPictureInPicture).apply()
            updatePictureInPictureParamsForAutoEntry()
            Toast.makeText(this, "Automatic picture-in-picture ${if (autoPictureInPicture) "on" else "off"}", Toast.LENGTH_SHORT).show()
        }

        section("Library")
        action("Delete playback history") { confirmDeleteHistory() }
        action("Clear saved resume positions") { confirmClearResumePositions() }
        action("Choose video folder") { pickFolder.launch(null) }
        action("Videos in saved folder") { showFolderVideos() }

        scroll.addView(content)
        val dialog = AlertDialog.Builder(this).setTitle("Alvi Player").setView(scroll).setNegativeButton("Close", null).create()
        dialog.show()
    }

    private fun buildPlayer() {
        val factory = AlviRenderersFactory(this, decoderMode, autoSkipMode)
        if (::player.isInitialized) {
            try { player.release() } catch (_: Exception) {}
        }
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        player = ExoPlayer.Builder(this, factory)
            .setSkipSilenceEnabled(autoSkipMode > 0)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.repeatMode = repeatMode
        player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
        voiceClarityAppliedSessionId = 0
        playerView.player = player
        playerView.useController = false
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val transitionedUri = mediaItem?.localConfiguration?.uri
                if (transitionedUri != null) {
                    currentUri = transitionedUri
                    lastVideoTitle = displayName(transitionedUri)
                    historyPrefs.edit().putString("last_uri", transitionedUri.toString()).putString("name_$transitionedUri", lastVideoTitle).apply()
                    val saved = historyPrefs.getLong("pos_$transitionedUri", 0L)
                    if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && saved > 0L && player.currentPosition < 1500L) player.seekTo(saved)
                    val savedSubtitle = historyPrefs.getString("subtitle_$transitionedUri", null)?.let(Uri::parse)
                    subtitleUri = savedSubtitle
                    externalSubtitleCues = emptyList()
                    externalSubtitleView.visibility = View.GONE
                    if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
                }
                applySubtitleStyle(); updateUi(); updateTitle()
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                voiceClarityAppliedSessionId = 0
                applyVoiceClarityIfNeeded()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updateScreenAwake(isPlaying)
                updateUi()
                updatePictureInPictureParamsForAutoEntry()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                updateUi()
                updatePictureInPictureParamsForAutoEntry()
            }
            override fun onPlayerError(error: PlaybackException) {
                if (error is androidx.media3.exoplayer.ExoPlaybackException && error.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && decoderMode == 1) {
                    try {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
                        player.prepare(); player.playWhenReady = true
                        Toast.makeText(this@MainActivity, "Unsupported audio codec; retrying video without audio", Toast.LENGTH_LONG).show()
                        return
                    } catch (_: Exception) {}
                }
                Toast.makeText(this@MainActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun switchDecoder(mode: Int) {
        if (decoderMode == mode) return
        saveCurrentProgress()
        val uri = currentUri
        val pos = if (::player.isInitialized) player.currentPosition else 0L
        val playing = ::player.isInitialized && player.playWhenReady
        decoderMode = mode
        historyPrefs.edit().putInt("decoder_mode", mode).apply()
        buildPlayer()
        player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
        handler.postDelayed({ if (::player.isInitialized) applyGestureVolume(volumePercent) }, 350L)
        if (uri != null) {
            val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
            subtitleUri = savedSubtitle
            externalSubtitleCues = emptyList()
            externalSubtitleView.visibility = View.GONE
            player.setMediaItem(if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri))
            player.prepare(); player.seekTo(pos); player.setPlaybackSpeed(selectedSpeed); player.playWhenReady = playing
            if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
        }
        showControlsTemporarily()
    }

    private fun decoderName() = when (decoderMode) { 0 -> "HW"; 1 -> "HW+"; else -> "SW" }

    private fun showDecoderDialog() {
        val labels = arrayOf(
            "HW — hardware decoder only",
            "HW+ — hardware with decoder fallback",
            "SW — software preferred"
        )
        AlertDialog.Builder(this).setTitle("Decoder")
            .setSingleChoiceItems(labels, decoderMode) { dialog, which ->
                switchDecoder(which); dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showOrientationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Orientation")
            .setMessage("Landscape mode only. The phone can automatically rotate between Landscape and Landscape Right. Tap the orientation button to switch the landscape side manually.")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun toggleOrientation() {
        // Button toggles Portrait <-> sensor-driven Landscape. In portrait mode,
        // stop the landscape sensor so it cannot immediately force the player back.
        if (orientationMode == 1) {
            landscapeOrientationListener?.disable()
            orientationMode = 2
            historyPrefs.edit().putInt("orientation_mode", 2).apply()
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            Toast.makeText(this, "Portrait", Toast.LENGTH_SHORT).show()
        } else {
            orientationMode = 1
            historyPrefs.edit().putInt("orientation_mode", 1).apply()
            enableLandscapeAutoRotation()
            Toast.makeText(this, "Auto Landscape", Toast.LENGTH_SHORT).show()
        }
        updateButtonStates()
        haptic()
    }

    private fun applyOrientationMode() {
        orientationMode = historyPrefs.getInt("orientation_mode", 1).coerceIn(1, 2)
        if (orientationMode == 2) {
            landscapeOrientationListener?.disable()
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            enableLandscapeAutoRotation()
        }
    }

    private fun showHapticsDialog() {
        hapticsEnabled = !hapticsEnabled
        historyPrefs.edit().putBoolean("haptics", hapticsEnabled).apply()
        Toast.makeText(this, "Haptic feedback ${if (hapticsEnabled) "on" else "off"}", Toast.LENGTH_SHORT).show()
    }

    private fun haptic() {
        if (hapticsEnabled) root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun resetZoom() { zoomScale = 1f; panX = 0f; panY = 0f; playerView.resizeMode = fitModes[fitMode]; applyZoom() }
    private fun applyZoom() {
        playerView.scaleX = if (horizontalFlip) -zoomScale else zoomScale
        playerView.scaleY = zoomScale
        playerView.translationX = panX.coerceIn(-root.width * (zoomScale - 1f) / 2f, root.width * (zoomScale - 1f) / 2f)
        playerView.translationY = panY.coerceIn(-root.height * (zoomScale - 1f) / 2f, root.height * (zoomScale - 1f) / 2f)
    }

    private fun applyVoiceClarityIfNeeded() {
        if (!voiceClarityEnabled || !::player.isInitialized || player.audioSessionId == 0) return
        val sessionId = player.audioSessionId
        if (voiceClarityAppliedSessionId == sessionId && voiceClarityEqualizer != null) return
        try {
            voiceClarityEqualizer?.release()
            val eq = Equalizer(0, sessionId)
            eq.enabled = false
            val bandCount = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            val minLevel = range[0].toInt()
            val maxLevel = range[1].toInt()
            for (bandIndex in 0 until bandCount) {
                val centerHz = eq.getCenterFreq(bandIndex.toShort()) / 1000
                val gainDb = when {
                    centerHz < 180 -> -2.0
                    centerHz < 500 -> -1.0
                    centerHz < 1200 -> 2.0
                    centerHz < 3500 -> 4.0
                    centerHz < 7000 -> 2.0
                    else -> 0.5
                }
                val level = (gainDb * 100).roundToInt().coerceIn(minLevel, maxLevel).toShort()
                eq.setBandLevel(bandIndex.toShort(), level)
            }
            eq.enabled = true
            voiceClarityEqualizer = eq
            voiceClarityAppliedSessionId = sessionId
        } catch (_: Exception) {
            voiceClarityEqualizer?.release()
            voiceClarityEqualizer = null
            voiceClarityAppliedSessionId = 0
        }
    }

    private fun disableVoiceClarity() {
        try { voiceClarityEqualizer?.enabled = false } catch (_: Exception) {}
        try { voiceClarityEqualizer?.release() } catch (_: Exception) {}
        voiceClarityEqualizer = null
        voiceClarityAppliedSessionId = 0
    }

    private fun autoSkipIcon(): String = when (autoSkipMode) {
        1 -> "≋"
        2 -> "≋≋"
        else -> "≋"
    }

    private fun decoderShortLabel(): String = when (decoderMode) {
        0 -> "HW"
        1 -> "HW+"
        else -> "SW"
    }

    private fun showAutoSkipSilenceDialog() {
        val labels = arrayOf("Off", "Mild — keep natural pauses", "Strong — tighter podcast-style skipping")
        AlertDialog.Builder(this)
            .setTitle("Auto Skip Silence")
            .setSingleChoiceItems(labels, autoSkipMode) { dialog, which ->
                autoSkipMode = which
                autoSkipSilence = which > 0
                historyPrefs.edit().putInt("auto_skip_mode", autoSkipMode).putBoolean("auto_skip_silence", autoSkipSilence).apply()
                val uri = currentUri
                val pos = if (::player.isInitialized) player.currentPosition else 0L
                val playing = ::player.isInitialized && player.playWhenReady
                val speed = selectedSpeed
                buildPlayer()
                if (uri != null) {
                    val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
                    subtitleUri = savedSubtitle
                    player.setMediaItem(if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri))
                    player.prepare(); player.seekTo(pos); player.setPlaybackSpeed(speed); player.playWhenReady = playing
                    if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
                }
                Toast.makeText(this, "Auto Skip Silence: ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun showVoiceClarityDialog() {
        if (!::player.isInitialized || player.audioSessionId == 0) {
            Toast.makeText(this, "Play a video first to use Voice Clarity", Toast.LENGTH_SHORT).show()
            return
        }
        voiceClarityEnabled = !voiceClarityEnabled
        historyPrefs.edit().putBoolean("voice_clarity", voiceClarityEnabled).apply()
        if (voiceClarityEnabled) {
            voiceClarityAppliedSessionId = 0
            applyVoiceClarityIfNeeded()
            if (voiceClarityEqualizer != null) {
                Toast.makeText(this, "Voice Clarity on", Toast.LENGTH_SHORT).show()
            } else {
                voiceClarityEnabled = false
                historyPrefs.edit().putBoolean("voice_clarity", false).apply()
                Toast.makeText(this, "Voice Clarity is not supported on this device", Toast.LENGTH_LONG).show()
            }
        } else {
            disableVoiceClarity()
            Toast.makeText(this, "Voice Clarity off", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showVideoInfo() {
        val duration = if (::player.isInitialized) player.duration else C.TIME_UNSET
        val tracks = if (::player.isInitialized) player.currentTracks.groups.size else 0
        val vf = if (::player.isInitialized) player.videoFormat else null
        val af = if (::player.isInitialized) player.audioFormat else null
        val videoLine = vf?.let { "${it.width}×${it.height} · ${it.sampleMimeType ?: "unknown"}${it.frameRate.takeIf { r -> r > 0f }?.let { r -> " · ${String.format(Locale.getDefault(), "%.2f", r)} fps" } ?: ""}" } ?: "—"
        val audioLine = af?.let { "${it.sampleMimeType ?: "unknown"} · ${it.channelCount} ch · ${if (it.sampleRate > 0) "${it.sampleRate} Hz" else "sample rate n/a"}" } ?: "—"
        AlertDialog.Builder(this).setTitle(lastVideoTitle)
            .setMessage("Duration: ${formatMs(duration)}\nSpeed: ${speedLabel(selectedSpeed)}\nDecoder: ${decoderName()}\nVideo: $videoLine\nAudio: $audioLine\nTracks: $tracks\nFast seeking: ${if (fastSeekEnabled) "On" else "Off"}\nAuto skip silence: ${when (autoSkipMode) { 1 -> "Mild"; 2 -> "Strong"; else -> "Off" }}")
            .setPositiveButton("Close", null).show()
    }

    /** The Background Play setting (not whether the service is currently running). */
    private fun isBackgroundPlaybackActive(): Boolean =
        historyPrefs.getBoolean(KEY_BACKGROUND_ENABLED, false)

    private fun isBackgroundServiceRunning(): Boolean =
        historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)

    /**
     * Background Play is a setting. Switching it on or off never touches the video that is on screen.
     * Audio is handed to BackgroundPlaybackService only when the app leaves the foreground
     * (see handOffToBackgroundService) and is taken back when the app returns.
     */
    private fun toggleBackgroundPlayback() {
        val enable = !isBackgroundPlaybackActive()
        historyPrefs.edit().putBoolean(KEY_BACKGROUND_ENABLED, enable).apply()
        updatePictureInPictureParamsForAutoEntry()
        updateButtonStates()
        Toast.makeText(
            this,
            if (enable) "Background play on · audio continues when you leave the app" else "Background play off",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun handOffToBackgroundService() {
        if (!isBackgroundPlaybackActive() || isInPictureInPictureMode || isChangingConfigurations) return
        val uri = currentUri ?: return
        if (!::player.isInitialized || player.mediaItemCount == 0 || !player.playWhenReady) return
        val position = player.currentPosition.coerceAtLeast(0L)
        val intent = Intent(this, BackgroundPlaybackService::class.java).apply {
            putExtra(BackgroundPlaybackService.EXTRA_URI, uri.toString())
            putExtra(BackgroundPlaybackService.EXTRA_POSITION, position)
            putExtra(BackgroundPlaybackService.EXTRA_SPEED, selectedSpeed)
            putExtra(BackgroundPlaybackService.EXTRA_TITLE, displayName(uri))
            putExtra(BackgroundPlaybackService.EXTRA_REPEAT, repeatMode)
            putStringArrayListExtra(BackgroundPlaybackService.EXTRA_PLAYLIST, ArrayList(queuedFolderUris.ifEmpty { listOf(uri) }.map { it.toString() }))
            putExtra(BackgroundPlaybackService.EXTRA_START_INDEX, queuedFolderUris.indexOf(uri).takeIf { it >= 0 } ?: 0)
        }
        try {
            if (notificationStarted) {
                stopService(Intent(this, PlaybackNotificationService::class.java))
                notificationStarted = false
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            resumeAfterHandoff = true
            player.pause()
            saveCurrentProgress()
        } catch (_: Exception) {
            // Could not start the service: keep playing in the activity instead of going silent.
        }
    }

    /** Takes playback back from the service when the user returns to the app. */
    private fun reclaimFromBackgroundService() {
        if (!isBackgroundServiceRunning()) { resumeAfterHandoff = false; return }
        val snap = BackgroundPlaybackService.snapshot()
        val wasPlaying = snap?.playing ?: resumeAfterHandoff
        resumeAfterHandoff = false
        try { stopService(Intent(this, BackgroundPlaybackService::class.java)) } catch (_: Exception) {}
        historyPrefs.edit().putBoolean(BackgroundPlaybackService.KEY_ACTIVE, false).apply()
        if (!::player.isInitialized || player.mediaItemCount == 0) return
        if (snap != null) {
            val index = (0 until player.mediaItemCount).firstOrNull {
                player.getMediaItemAt(it).localConfiguration?.uri?.toString() == snap.uri
            }
            if (index != null) player.seekTo(index, snap.positionMs)
        }
        if (wasPlaying) player.play()
        updateUi()
    }

    /** Keep Android 12+ auto-entry in sync with playback and the Background Play preference. */
    private fun updatePictureInPictureParamsForAutoEntry() {
        if (Build.VERSION.SDK_INT < 26 || !::player.isInitialized) return
        try {
            val shouldAutoEnter = Build.VERSION.SDK_INT >= 31 && autoPictureInPicture &&
                !isBackgroundPlaybackActive() && player.mediaItemCount > 0 && player.isPlaying
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
            if (Build.VERSION.SDK_INT >= 31) params.setAutoEnterEnabled(shouldAutoEnter)
            setPictureInPictureParams(params.build())
        } catch (_: Exception) {
            // The onUserLeaveHint fallback below still supports devices that do not accept updates.
        }
    }

    private fun enterPip() {
        if (isBackgroundPlaybackActive()) {
            Toast.makeText(this, "Background play is active", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT < 26 || !::player.isInitialized || player.mediaItemCount == 0) {
            Toast.makeText(this, "Picture-in-picture is unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val builder = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
            if (Build.VERSION.SDK_INT >= 31) {
                // Manual PiP is separate from automatic PiP; do not auto-enter while Background Play owns playback.
                builder.setAutoEnterEnabled(autoPictureInPicture && !isBackgroundPlaybackActive() && player.isPlaying)
            }
            enterPictureInPictureMode(builder.build())
        } catch (_: Exception) {
            Toast.makeText(this, "Picture-in-picture is unavailable on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDeleteHistory() {
        AlertDialog.Builder(this).setTitle("Delete playback history?")
            .setMessage("This removes only the playback history list. Saved resume positions and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val editor = historyPrefs.edit()
                historyPrefs.all.keys.filter { it.startsWith("history_") || it.startsWith("name_") }.forEach { editor.remove(it) }
                editor.apply()
                Toast.makeText(this, "Playback history deleted", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun confirmClearResumePositions() {
        AlertDialog.Builder(this).setTitle("Clear saved resume positions?")
            .setMessage("This removes saved playback positions only. Playback history and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                historyPrefs.edit().apply {
                    historyPrefs.all.keys.filter { it.startsWith("pos_") }.forEach { remove(it) }
                    apply()
                }
                Toast.makeText(this, "Saved resume positions cleared", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showHistoryDialog() {
        val history = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }
            .distinctBy { it.toString() }
            .take(30)
        if (history.isEmpty()) {
            // Backward compatibility with older builds that stored name_<uri>.
            val legacy = historyPrefs.all.keys.filter { it.startsWith("name_") }.map { Uri.parse(it.removePrefix("name_")) }.distinct().take(30)
            if (legacy.isEmpty()) { Toast.makeText(this, "No playback history yet", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("Playback history").setItems(legacy.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(legacy[index], true) }.setNegativeButton("Close", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Playback history")
            .setItems(history.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(history[index], true) }
            .setNegativeButton("Close", null).show()
    }

    private fun showTrackDialog() {
        if (!::player.isInitialized) return
        val tracks = player.currentTracks.groups
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        for (group in tracks) {
            val type = group.type
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val typeName = if (type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                val language = format.language ?: "und"
                options.add("$typeName · $language${if (format.label != null) " · ${format.label}" else ""}")
                actions.add {
                    val builder = player.trackSelectionParameters.buildUpon()
                    builder.setTrackTypeDisabled(type, false)
                    builder.setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(i)))
                    player.trackSelectionParameters = builder.build()
                }
            }
        }
        if (options.isEmpty()) { Toast.makeText(this, "No alternate audio or subtitle tracks in this video", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Available tracks").setItems(options.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNeutralButton("Disable subtitles") { _, _ -> player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }
            .setNegativeButton("Close", null).show()
    }

    private fun showAudioDelayDialog() {
        val values = intArrayOf(-500, -250, -100, 0, 100, 250, 500)
        val labels = values.map { if (it > 0) "+${it} ms" else "$it ms" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Audio delay")
            .setSingleChoiceItems(labels, values.indexOf(audioDelayMs).coerceAtLeast(0)) { dialog, which ->
                audioDelayMs = values[which]
                Toast.makeText(this, "Audio delay preference saved. Subtitle synchronization is available separately for external SRT/VTT subtitles.", Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showFolderVideos() {
        val folder = historyPrefs.getString("folder_uri", null)?.let(Uri::parse)
        if (folder == null) { Toast.makeText(this, "Choose a folder first", Toast.LENGTH_SHORT).show(); pickFolder.launch(null); return }
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, DocumentsContract.getTreeDocumentId(folder))
            val found = mutableListOf<Pair<String, Uri>>()
            contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0); val name = c.getString(1) ?: "Video"; val mime = c.getString(2) ?: ""
                    if (mime.startsWith("video/")) found.add(name to DocumentsContract.buildDocumentUriUsingTree(folder, id))
                }
            }
            if (found.isEmpty()) { Toast.makeText(this, "No videos found directly in this folder", Toast.LENGTH_LONG).show(); return }
            val names = found.map { it.first }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Folder videos")
                .setItems(names) { _, index -> playFolder(found.map { it.second }, index) }
                .setNeutralButton("Play all") { _, _ -> playFolder(found.map { it.second }, 0) }
                .setNegativeButton("Close", null).show()
        } catch (_: Exception) { Toast.makeText(this, "Could not read this folder", Toast.LENGTH_SHORT).show() }
    }

    private fun playFolder(uris: List<Uri>, startIndex: Int) {
        if (uris.isEmpty()) return
        saveCurrentProgress()
        queuedFolderUris = uris
        val items = uris.map { uri ->
            val sub = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
            if (sub != null && !isCustomSubtitle(sub)) buildVideoItem(uri, sub) else MediaItem.fromUri(uri)
        }
        currentUri = uris[startIndex.coerceIn(0, uris.lastIndex)]
        lastVideoTitle = displayName(currentUri!!)
        externalSubtitleCues = emptyList()
        externalSubtitleView.visibility = View.GONE
        player.setMediaItems(items, startIndex.coerceIn(0, items.lastIndex), historyPrefs.getLong("pos_${currentUri}", 0L))
        player.prepare()
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        player.repeatMode = repeatMode
        historyPrefs.edit().putString("last_uri", currentUri.toString()).apply()
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateTitle(); updateUi()
    }

    private fun repeatName(): String = when (repeatMode) {
        Player.REPEAT_MODE_ONE -> "One"
        Player.REPEAT_MODE_ALL -> "All"
        else -> "Off"
    }

    private fun showRepeatDialog() {
        val labels = arrayOf("Off", "Repeat one", "Repeat all")
        val modes = intArrayOf(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ONE, Player.REPEAT_MODE_ALL)
        val checked = modes.indexOf(repeatMode).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Repeat")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                repeatMode = modes[which]
                historyPrefs.edit().putInt("repeat_mode", repeatMode).apply()
                if (::player.isInitialized) player.repeatMode = repeatMode
                haptic(); dialog.dismiss(); showControlsTemporarily()
            }.setNegativeButton("Close", null).show()
    }

    private fun showFastSeekDialog() {
        val labels = arrayOf("On — faster, nearby keyframe", "Off — exact seeking")
        AlertDialog.Builder(this).setTitle("Fast seeking")
            .setSingleChoiceItems(labels, if (fastSeekEnabled) 0 else 1) { dialog, which ->
                fastSeekEnabled = which == 0
                historyPrefs.edit().putBoolean("fast_seek", fastSeekEnabled).apply()
                if (::player.isInitialized) player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                Toast.makeText(this, if (fastSeekEnabled) "Fast seeking enabled" else "Exact seeking enabled", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun speedLabel(speed: Float) = if (speed % 1f == 0f) "${speed.toInt()}×" else "${speed}×"


    private fun showSpeedDialog() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        val dialog = AlertDialog.Builder(this).setTitle("Playback speed").setView(scroll).setNegativeButton("Close", null).create()
        speeds.forEach { value ->
            val b = button("${value}×")
            b.setPadding(dp(12), dp(12), dp(12), dp(12))
            if (value == selectedSpeed) b.setBackgroundColor(0xFF1769AA.toInt())
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            b.setOnClickListener {
                selectedSpeed = value
                historyPrefs.edit().putFloat("selected_speed", selectedSpeed).apply()
                if (::player.isInitialized) player.setPlaybackSpeed(selectedSpeed)
                speedButton.text = speedBtnLabel(value)
                updateUi(); dialog.dismiss(); showControlsTemporarily()
            }
        }
        dialog.show()
    }

    private fun applyGestureVolume(percent: Int) {
        volumePercent = percent.coerceIn(0, 200)
        historyPrefs.edit().putInt("volume_percent", volumePercent).apply()

        val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val maxVol = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)

        try {
            // 0–100% of the app maps directly to the phone's normal media-volume range.
            // App 100% therefore means the phone's media volume is exactly 100%.
            val systemPercent = volumePercent.coerceAtMost(100)
            val systemVolume = (maxVol * systemPercent / 100f).roundToInt().coerceIn(0, maxVol)
            audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, systemVolume, 0)

            volumeBoostEnhancer?.release()
            volumeBoostEnhancer = null
            if (volumePercent > 100 && player.audioSessionId != 0) {
                volumeBoostEnhancer = LoudnessEnhancer(player.audioSessionId).apply {
                    val gainDb = 20.0 * kotlin.math.log10(volumePercent / 100.0)
                    setTargetGain((gainDb * 100).roundToInt())
                    enabled = true
                }
            }

            // System volume is the sole 0–100% control; keep the player at unity gain.
            player.volume = 1f
        } catch (_: Exception) {
            // Device restrictions fallback.
            player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
        }
    }

    private fun showSeekAmountDialog() {
        val values = intArrayOf(5, 10, 15, 20, 30)
        val labels = values.map { "$it seconds" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Double-tap seek amount")
            .setSingleChoiceItems(labels, values.indexOf(seekSeconds).coerceAtLeast(0)) { dialog, which ->
                seekSeconds = values[which]
                historyPrefs.edit().putInt("seek_seconds", seekSeconds).apply()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showGestureSensitivityDialog() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { "${it}×" }.toTypedArray()
        val selected = values.indexOfFirst { abs(it - gestureSensitivity) < 0.01f }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Gesture sensitivity")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                gestureSensitivity = values[which]
                historyPrefs.edit().putFloat("gesture_sensitivity", gestureSensitivity).apply()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSubtitleAppearanceDialog() {
        val sizes = floatArrayOf(0.04f, 0.0533f, 0.065f, 0.08f)
        val positions = floatArrayOf(0.03f, 0.08f, 0.14f, 0.22f)
        val labels = sizes.map { "${(it / 0.0533f * 100).roundToInt()}% size" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Subtitle size")
            .setSingleChoiceItems(labels, sizes.indexOfFirst { abs(it - subtitleSize) < 0.005f }.coerceAtLeast(0)) { dialog, which ->
                subtitleSize = sizes[which]
                historyPrefs.edit().putFloat("subtitle_size", subtitleSize).apply()
                applySubtitleStyle(); dialog.dismiss(); showSubtitlePositionDialog()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSubtitlePositionDialog() {
        val positions = floatArrayOf(0.03f, 0.08f, 0.14f, 0.22f)
        val labels = arrayOf("Near bottom", "Default", "Higher", "Much higher")
        AlertDialog.Builder(this).setTitle("Subtitle position")
            .setSingleChoiceItems(labels, positions.indexOfFirst { abs(it - subtitleBottom) < 0.01f }.coerceAtLeast(0)) { dialog, which ->
                subtitleBottom = positions[which]
                historyPrefs.edit().putFloat("subtitle_bottom", subtitleBottom).apply()
                applySubtitleStyle(); dialog.dismiss()
            }.setNegativeButton("Skip", null).show()
    }

    private fun showVolumeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(8)) }
        val label = TextView(this).apply { text = "Volume: ${volumePercent}%"; setTextColor(Color.WHITE); textSize = 16f }
        val bar = SeekBar(this).apply { max = 200; progress = volumePercent }
        box.addView(label); box.addView(bar)
        val dialog = AlertDialog.Builder(this).setTitle("Amplified volume (up to 200%)").setView(box).setPositiveButton("Done", null).create()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                applyGestureVolume(progress)
                label.text = "Volume: ${volumePercent}%"
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        dialog.show()
    }

    private fun toggleVoiceClarity() = showVoiceClarityDialog()

    private fun showGestureHint(text: String) {
        gestureHint.text = text
        gestureHint.visibility = View.VISIBLE
    }

    private fun toggleControls() = setControlsVisible(!controlsVisible)

    private fun speedBtnLabel(speed: Float) = speedLabel(speed).replace("×", "X")

    /** Icon/text button that renders itself through BtnState; icons are vector drawables. */
    private fun iconBtn(resId: Int, circle: Boolean, frac: Float = 0.5f): TextView = TextView(this).apply {
        text = ""
        setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        gravity = Gravity.CENTER
        includeFontPadding = false
        setPadding(0, 0, 0, 0)
        isClickable = true
        isFocusable = true
        stateListAnimator = null
        tag = BtnState(resId, false, circle, frac)
        renderButton(this)
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().cancel().also { v.alpha = 0.6f; v.scaleX = 0.92f; v.scaleY = 0.92f }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(110L).start()
            }
            false
        }
    }

    private fun renderButton(v: TextView) {
        val st = v.tag as? BtnState ?: return
        val circleOn = st.circle || st.active
        val circleColor = when {
            !circleOn -> 0
            st.color != 0 -> st.color
            st.active -> 0xCC5C7CFA.toInt()
            else -> 0x99263238.toInt()
        }
        if (st.res == 0) {
            v.setTextColor(Color.WHITE)
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(circleColor)
            }
        } else {
            v.background = IconDrawable(getDrawable(st.res)!!.mutate(), circleColor, st.frac, resources.displayMetrics.density)
        }
    }

    private fun setIconRes(view: TextView, resId: Int) {
        val st = view.tag as? BtnState ?: return
        if (st.res == resId) return
        st.res = resId
        renderButton(view)
    }

    private fun setButtonActive(view: TextView, active: Boolean) {
        val st = view.tag as? BtnState ?: return
        if (st.active == active) return
        st.active = active
        renderButton(view)
    }

    private fun updateButtonStates() {
        if (::autoSkipButton.isInitialized) setButtonActive(autoSkipButton, autoSkipSilence)
        if (::speedButton.isInitialized) {
            val activeSpeed = if (temporarySpeedActive && ::player.isInitialized) player.playbackParameters.speed else selectedSpeed
            speedButton.text = speedBtnLabel(activeSpeed)
            setButtonActive(speedButton, activeSpeed != 1f)
        }
        if (::audioBoostButton.isInitialized) setButtonActive(audioBoostButton, voiceClarityEnabled)
        if (::orientationButton.isInitialized) setButtonActive(orientationButton, currentLandscapeOrientation == ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE)
        if (::fitButton.isInitialized) setButtonActive(fitButton, fitMode != 0)
        if (::backgroundButton.isInitialized) setButtonActive(backgroundButton, isBackgroundPlaybackActive())
        if (::pipButton.isInitialized) setButtonActive(pipButton, isInPictureInPictureMode)
    }

    private fun fadeTo(v: View, show: Boolean) {
        if (show) {
            v.animate().cancel()
            if (v.visibility != View.VISIBLE) { v.alpha = 0f; v.visibility = View.VISIBLE }
            v.animate().alpha(1f).setDuration(180L).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        } else if (v.visibility == View.VISIBLE) {
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(150L).setInterpolator(android.view.animation.AccelerateInterpolator())
                .withEndAction { if (v.alpha < 0.01f) v.visibility = View.GONE }.start()
        }
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible && !locked && !isInPictureInPictureMode
        if (player.mediaItemCount == 0) {
            topBar.visibility = View.VISIBLE
            topBar.alpha = 1f
            selectButton.visibility = View.VISIBLE
            speedButton.visibility = View.GONE
            clarityButton.visibility = View.GONE
            decoderButton.visibility = View.GONE
            subtitleButton.visibility = View.GONE
            autoSkipButton.visibility = View.GONE
            previousButton.visibility = View.GONE
            nextButton.visibility = View.GONE
            playPauseButton.visibility = View.GONE
            lockButton.visibility = View.GONE
            bottomBar.visibility = View.GONE
            fitButton.visibility = View.GONE
            fullscreenButton.visibility = View.GONE
            orientationButton.visibility = View.GONE
            audioBoostButton.visibility = View.GONE
            leftTools.visibility = View.GONE
        } else {
            selectButton.visibility = View.VISIBLE
            fitButton.visibility = View.GONE
            for (v in listOf(speedButton, decoderButton, subtitleButton, autoSkipButton, previousButton, nextButton,
                playPauseButton, orientationButton, audioBoostButton)) v.visibility = View.VISIBLE
            fadeTo(topBar, controlsVisible)
            fadeTo(bottomBar, controlsVisible)
            fadeTo(leftTools, controlsVisible)
            fadeTo(fullscreenButton, controlsVisible)
            // While locked the padlock is managed by flashLockButton().
            if (!locked) fadeTo(lockButton, controlsVisible)
        }
        if (controlsVisible) scheduleAutoHide() else cancelAutoHide()
    }

    private fun showControlsTemporarily() { setControlsVisible(true) }
    private fun scheduleAutoHide() {
        cancelAutoHide()
        handler.postDelayed(autoHideRunnable, 3500)
    }
    private fun cancelAutoHide() { handler.removeCallbacks(autoHideRunnable) }
    private val autoHideRunnable = Runnable { if (!userSeeking && !locked && player.mediaItemCount > 0) setControlsVisible(false) }

    private fun syncPlaybackNotification() {
        if (isBackgroundServiceRunning()) return
        if (!::player.isInitialized || player.mediaItemCount == 0) {
            if (notificationStarted) {
                try { stopService(Intent(this, PlaybackNotificationService::class.java)) } catch (_: Exception) {}
                notificationStarted = false
            }
            return
        }
        val playing = player.isPlaying
        val title = lastVideoTitle
        if (notificationStarted && lastNotificationPlaying == playing && lastNotificationTitle == title) return
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_UPDATE
            putExtra(PlaybackNotificationService.EXTRA_TITLE, title)
            putExtra(PlaybackNotificationService.EXTRA_PLAYING, playing)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            notificationStarted = true
            lastNotificationPlaying = playing
            lastNotificationTitle = title
        } catch (_: Exception) {}
    }

    private fun updateTitle() {
        if (::titleView.isInitialized) titleView.text = lastVideoTitle
    }

    private fun updateUi() {
        if (!::player.isInitialized) return
        val duration = player.duration
        val current = max(0L, player.currentPosition)
        val validDuration = duration > 0 && duration != C.TIME_UNSET
        val remaining = if (validDuration) max(0L, duration - current) else C.TIME_UNSET
        // Estimate wall-clock time remaining at current speed: 2× => /2, 2.5× => /3, 3× => /4.
        val playbackSpeed = player.playbackParameters.speed.coerceAtLeast(0.01f)
        val speedFactor = if (playbackSpeed <= 2f) playbackSpeed else (playbackSpeed * 2f - 2f)
        val adjustedRemaining = if (remaining != C.TIME_UNSET) {
            (remaining / speedFactor).roundToInt().toLong().coerceAtLeast(0L)
        } else C.TIME_UNSET
        timeLeftText.text = ""
        positionText.text = formatMs(current)
        durationText.text = formatMs(adjustedRemaining)
        positionText.contentDescription = "Elapsed ${formatMs(current)}"
        durationText.contentDescription = "Remaining ${formatMs(adjustedRemaining)}"
        if (!userSeeking) seekBar.progress = if (validDuration) (current * SEEK_MAX / duration).toInt().coerceIn(0, SEEK_MAX.toInt()) else 0
        updateExternalSubtitle()
        applyVoiceClarityIfNeeded()
        setIconRes(playPauseButton, if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        updateButtonStates()
        syncPlaybackNotification()
    }

    private val updateRunnable = object : Runnable {
        private var tick = 0
        override fun run() {
            updateUi()
            if (++tick % 4 == 0) saveCurrentProgress()
            handler.postDelayed(this, 250L)
        }
    }

    private fun plainIconButton(textValue: String, sizeSp: Float) = TextView(this).apply {
        text = textValue
        textSize = sizeSp
        setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xE6000000.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(4), dp(6), dp(4))
        background = ColorDrawable(Color.TRANSPARENT)
        alpha = 1f
        isClickable = true
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.58f
                    v.scaleX = 0.94f
                    v.scaleY = 0.94f
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(90L).start()
                }
            }
            false
        }
        isFocusable = true
        stateListAnimator = null
    }

    private fun prepareSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.setStatusBarContrastEnforced(false)
            window.setNavigationBarContrastEnforced(false)
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
    }

    private fun showStatusBarTemporarily() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.show(WindowInsetsCompat.Type.statusBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        handler.removeCallbacks(hideStatusBarRunnable)
        handler.postDelayed(hideStatusBarRunnable, 2600L)
    }

    private fun hideStatusBarOnly() {
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.statusBars())
    }

    private fun toggleFullscreenBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        val visible = WindowInsetsCompat.toWindowInsetsCompat(window.decorView.rootWindowInsets).isVisible(WindowInsetsCompat.Type.statusBars())
        if (visible) controller.hide(WindowInsetsCompat.Type.statusBars()) else controller.show(WindowInsetsCompat.Type.statusBars())
        haptic()
    }

    private fun iconButton(textValue: String, sizeSp: Float) = TextView(this).apply {
        text = textValue
        textSize = sizeSp
        setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xE6000000.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(4), dp(6), dp(4))
        background = GradientDrawable().apply {
            setColor(0x44101010)
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), 0x44FFFFFF)
        }
        alpha = 1f
        isClickable = true
        isFocusable = true
        stateListAnimator = null
    }

    private fun button(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 14f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8))
        background = roundedBackground(0xFF303030.toInt(), 12); isClickable = true; isFocusable = true
    }
    private fun roundedBackground(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 12f; setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xF0000000.toInt())
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
    }
    private fun formatMs(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0L) return "—"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
    private fun updateScreenAwake(isPlaying: Boolean) {
        if (isPlaying) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Leaving the app enters PiP automatically unless the user explicitly
        // selected Background Play. Background Play owns playback outside the UI.
        if (autoPictureInPicture && !isBackgroundPlaybackActive() && Build.VERSION.SDK_INT >= 26 &&
            ::player.isInitialized && player.mediaItemCount > 0 &&
            player.isPlaying && !isInPictureInPictureMode) {
            enterPip()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        updateButtonStates()
        if (isInPictureInPictureMode) setControlsVisible(false)
    }

    override fun onStop() {
        saveCurrentProgress()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        reclaimFromBackgroundService()
    }

    override fun onPause() {
        endTemporarySpeed()
        handOffToBackgroundService()

        saveCurrentProgress()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    private fun togglePlaybackFromNotification() {
        if (::player.isInitialized && player.mediaItemCount > 0) {
            if (player.isPlaying) player.pause() else player.play()
            updateUi()
            showControlsTemporarily()
            syncPlaybackNotification()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == PlaybackNotificationService.ACTION_TOGGLE) {
            togglePlaybackFromNotification()
            intent.action = null
        } else {
            handleIncomingIntent(intent)
        }
    }

    override fun onDestroy() {
        landscapeOrientationListener?.disable()
        landscapeOrientationListener = null
        if (activeInstance?.get() === this) activeInstance = null
        saveCurrentProgress()
        handler.removeCallbacks(updateRunnable)
        cancelAutoHide()
        volumeBoostEnhancer?.release()
        volumeBoostEnhancer = null
        disableVoiceClarity()
        subtitleExecutor.shutdownNow()
        handler.removeCallbacks(previewRunnable)
        previewRequestId++
        previewFuture?.cancel(true)
        try { previewRetriever?.release() } catch (_: Exception) { }
        previewRetriever = null
        previewRetrieverUri = null
        previewCache.evictAll()
        lastPreviewShownKey = null
        previewExecutor.shutdownNow()
        if (notificationStarted) {
            try { stopService(Intent(this, PlaybackNotificationService::class.java)) } catch (_: Exception) {}
            notificationStarted = false
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

/** Visual state of an MX-style button: vector icon (res == 0 means text), optional circle, tint colours. */
private class BtnState(var res: Int, var active: Boolean, var circle: Boolean, var frac: Float, var color: Int = 0)

/** Draws an optional circle plus a white vector icon with a soft shadow so it reads on any video frame. */
private class IconDrawable(
    private val icon: android.graphics.drawable.Drawable,
    private val circleColor: Int,
    private val frac: Float,
    private val density: Float
) : android.graphics.drawable.Drawable() {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: android.graphics.Canvas) {
        val s = minOf(bounds.width(), bounds.height()).toFloat()
        if (s <= 0f) return
        val cx = bounds.exactCenterX()
        val cy = bounds.exactCenterY()
        if (circleColor != 0) {
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = circleColor
            canvas.drawCircle(cx, cy, s * 0.46f, paint)
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = density
            paint.color = 0x33FFFFFF
            canvas.drawCircle(cx, cy, s * 0.46f - density * 0.5f, paint)
        }
        val half = (s * frac / 2f).toInt().coerceAtLeast(1)
        val l = (cx - half).toInt(); val t = (cy - half).toInt()
        val r = (cx + half).toInt(); val b = (cy + half).toInt()
        icon.setBounds(l, t, r, b)
        if (circleColor == 0) {
            icon.setTint(0x99000000.toInt())
            val save = canvas.save()
            canvas.translate(0f, density * 1.2f)
            icon.draw(canvas)
            canvas.restoreToCount(save)
        }
        icon.setTint(android.graphics.Color.WHITE)
        icon.draw(canvas)
    }

    override fun setAlpha(alpha: Int) { icon.alpha = alpha }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) { icon.colorFilter = colorFilter }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}
