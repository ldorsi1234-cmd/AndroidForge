package com.example.speedtimeplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Keeps a compact media notification visible while the foreground player is active.
 * The play/pause action returns to MainActivity, so the notification controls the
 * same ExoPlayer instance instead of creating a second player.
 */
class PlaybackNotificationService : Service() {
    private var title = "Alvi Player"
    private var playing = false
    private var started = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_UPDATE -> {
                title = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: title
                playing = intent.getBooleanExtra(EXTRA_PLAYING, playing)
                showNotification()
            }
            ACTION_STOP -> {
                stopForeground(true)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun showNotification() {
        val toggleIntent = Intent(this, MainActivity::class.java).apply {
            action = ACTION_TOGGLE
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val togglePending = PendingIntent.getActivity(
            this, 9101, toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, PlaybackNotificationService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 9102, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            .setContentTitle(title)
            .setContentText(if (playing) "Playing · Alvi Player" else "Paused · Alvi Player")
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(togglePending)
            .addAction(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Pause" else "Play",
                togglePending
            )
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPending)

        if (!started) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(
                    NOTIFICATION_ID,
                    builder.build(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, builder.build())
            }
            started = true
        } else {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, builder.build())
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alvi Player playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Playback controls for Alvi Player"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "alvi_player_playback"
        const val NOTIFICATION_ID = 9100
        const val ACTION_UPDATE = "com.example.speedtimeplayer.action.NOTIFICATION_UPDATE"
        const val ACTION_TOGGLE = "com.example.speedtimeplayer.action.NOTIFICATION_TOGGLE"
        const val ACTION_STOP = "com.example.speedtimeplayer.action.NOTIFICATION_STOP"
        const val EXTRA_TITLE = "notification_title"
        const val EXTRA_PLAYING = "notification_playing"
    }
}
