# Alvi Player Pro 2.6

A fast, study-focused Android video player built on AndroidX Media3 1.5.1.

## UI / playback changes in 2.5
- MX-style compact top control bar and large center play/previous/next controls.
- Bottom control surface reduced to a thin seek bar only; no bottom +/- seek buttons.
- Playback speed is a clock-style top button (◷).
- Voice Clarity has its own top control (CL).
- Auto Skip Silence has its own top control (AS) with Off / Mild / Strong modes.
- Horizontal seeking also changes speed in 0.5x steps: left slows down, right speeds up, with an on-screen hint.
- Folder playlists expose previous/next playback in-app and through the Android media notification.
- Background playback uses Media3 MediaSessionService. The system media controls automatically expose pause and next/previous when a playlist is available.

## Auto Skip Silence
Media3's PCM silence processor is configured directly in the audio sink for two practical modes:
- Mild: trims only longer quiet gaps while preserving more natural pauses.
- Strong: trims shorter/larger silent gaps for tighter lecture/podcast playback.

This detects low-level audio silence, not semantic human speech. It does not use cloud/AI processing.

## Notification controls
Background playback uses a MediaSessionService. When playing a folder playlist, Android's media controls can expose pause and next/previous actions from the active playlist. This follows Media3's recommended background playback architecture.

## Build
- compileSdk / targetSdk: 35
- minSdk: 23
- Java/Kotlin target: 17
- Media3: 1.5.1
- No FFmpeg Maven dependency is included.

This package is source code. APK/device validation must be performed in an Android build environment.


## MX-style long-press speed
Press and hold the video surface to temporarily play at 2× speed. Release immediately restores the user-selected speed. Horizontal swipe remains seek-only. This mirrors the familiar MX Player long-press fast-forward interaction.



## 3.3 MX-style control placement
- Playback OSD follows the supplied MX Player reference layout rather than using a generic control arrangement.
- Top bar: back/title on the left; audio tracks, subtitles, decoder and More on the right.
- Left-side playback cluster: Voice Clarity, Landscape/Portrait, playback speed and Auto Skip Silence.
- Speed button remains tap-to-select and hold + left/right drag for temporary speed, releasing back to the previously selected speed.
- Bottom: elapsed time at left, thin seekbar, remaining time at right; centered previous/play-pause/next controls; lock at lower left; aspect-ratio and fullscreen controls at lower right.
- Horizontal flip remains available; vertical flip remains excluded.
- Lock and playback icons use plain monochrome glyphs.
- Auto Skip Silence remains icon-only with Off/Mild/Strong modes.
- Noise Reduction is not part of the playback OSD.


## 3.4 volume and OSD refinement
- Top and bottom playback OSD panels use a more transparent MX-style black overlay.
- App volume 0–100% maps directly to the Android media-volume range: app 100% equals phone media volume 100%.
- App volume 100–200% keeps the phone at maximum and applies LoudnessEnhancer only to the excess.
- Temporary hold speed uses horizontal left/right drag, matching the requested MX-style interaction.
