plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.speedtimeplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.speedtimeplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 82
        versionName = "15.0"
    }

    // Keep Java and Kotlin bytecode targets aligned for the CI build.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        // Drop Kotlin's runtime null-check helpers: slightly less work in hot UI/audio paths.
        freeCompilerArgs += listOf("-Xno-param-assertions", "-Xno-call-assertions", "-Xno-receiver-assertions")
    }

    buildTypes {
        // The CI runs assembleDebug. A debuggable build runs noticeably slower on the phone, so this
        // debug-signed build is made non-debuggable (it still installs the same way).
        getByName("debug") {
            isDebuggable = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
}
