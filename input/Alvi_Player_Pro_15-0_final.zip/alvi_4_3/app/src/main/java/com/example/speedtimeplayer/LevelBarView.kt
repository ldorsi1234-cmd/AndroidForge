package com.example.speedtimeplayer

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View

/**
 * Thin vertical level bar for the brightness / volume gestures, in MX Player colours: dark grey track,
 * blue fill from the bottom, and (for volume above 100%) the part past the [splitAt] mark fading to amber.
 */
class LevelBarView(context: Context) : View(context) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5A5A5A.toInt() }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = BLUE }
    // Soft dark outline around the whole bar so it stays visible on white slides as well as on dark video.
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x8C000000.toInt() }
    private val density = context.resources.displayMetrics.density
    private var fraction = 0f
    private var split = 1f

    fun setLevel(level: Float, splitAt: Float = 1f) {
        fraction = level.coerceIn(0f, 1f)
        split = splitAt.coerceIn(0.01f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val full = width.toFloat()
        val h = height.toFloat()
        val trackW = 2.5f * density
        val o = 0.8f * density                 // outline thickness
        val left = (full - trackW) / 2f
        val right = left + trackW
        val r = trackW / 2f
        val top0 = o
        val bottom0 = h - o
        val trackH = bottom0 - top0
        canvas.drawRoundRect(left - o, 0f, right + o, h, r + o, r + o, outlinePaint)
        canvas.drawRoundRect(left, top0, right, bottom0, r, r, trackPaint)
        if (fraction <= 0f) return
        val top = top0 + trackH * (1f - fraction)
        fillPaint.shader = if (fraction > split) {
            // Past the split mark (volume above 100%): amber at the top, blending into blue at the mark.
            LinearGradient(0f, top, 0f, top0 + trackH * (1f - split), AMBER, BLUE, Shader.TileMode.CLAMP)
        } else null
        fillPaint.color = BLUE
        canvas.drawRoundRect(left, top, right, bottom0, r, r, fillPaint)
    }

    private companion object {
        const val BLUE = 0xFF3B7CEB.toInt()
        const val AMBER = 0xFFE2C26A.toInt()
    }
}
