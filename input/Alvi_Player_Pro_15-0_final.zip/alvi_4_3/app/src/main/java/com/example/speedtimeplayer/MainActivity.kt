package com.example.speedtimeplayer

import android.content.Intent
import android.content.Context
import android.content.pm.ActivityInfo
import android.view.OrientationEventListener
import android.media.audiofx.LoudnessEnhancer
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.Build
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.view.ViewConfiguration
import android.util.Rational
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ScaleGestureDetector
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.graphics.Typeface
import android.widget.Toast
import android.util.LruCache
import android.util.TypedValue
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.session.MediaSession
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.text.SimpleDateFormat
import java.util.Locale
import java.lang.ref.WeakReference
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.log10

@UnstableApi
class MainActivity : ComponentActivity() {

    private var landscapeOrientationListener: OrientationEventListener? = null
    private var currentLandscapeOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

    private fun enableLandscapeAutoRotation() {
        currentLandscapeOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        requestedOrientation = currentLandscapeOrientation
        landscapeOrientationListener?.disable()
        landscapeOrientationListener = object : OrientationEventListener(this) {
            override fun onOrientationChanged(orientation: Int) {
                if (orientation == ORIENTATION_UNKNOWN) return
                // Only react to clear landscape orientations. The portrait sectors
                // are deliberately ignored, so tilting through portrait never changes
                // the requested orientation. A small dead-zone prevents rapid flipping.
                // The device sensor direction is opposite to the visual side
                // we want on this landscape player, so map the two landscape
                // sectors explicitly in the corrected direction.
                val target = when {
                    orientation in 70..110 -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
                    orientation in 250..290 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    else -> return
                }
                if (target != currentLandscapeOrientation) {
                    currentLandscapeOrientation = target
                    requestedOrientation = target
                }
            }
        }
        if (landscapeOrientationListener?.canDetectOrientation() == true) {
            landscapeOrientationListener?.enable()
        }
    }



    companion object {
        private const val KEY_BACKGROUND_ENABLED = "background_play_enabled"
        private const val ACTION_PIP_TOGGLE = "com.example.speedtimeplayer.action.PIP_TOGGLE"
        private const val SCRUB_MIN_GAP_MS = 30L // measured from a screen recording of MX Player: its picture refreshes about every 30-60 ms while dragging
        private const val SEEK_MAX = 100000L // fine resolution: smooth thumb movement even on multi-hour videos
        private var activeInstance: WeakReference<MainActivity>? = null
        /** Returns false when there is no live player to control (the notification service then removes itself). */
        fun toggleFromNotification(): Boolean = activeInstance?.get()?.togglePlaybackFromNotification() ?: false
        fun stopFromNotification(): Boolean = activeInstance?.get()?.stopPlaybackFromNotification() ?: false
        /** What the notification button should show right now; null if there is no live player. */
        fun currentNotificationPlaying(): Boolean? = activeInstance?.get()?.notificationPlayingState()
        /** The screen player's media session (for the notification's media style); null if there is none. */
        fun currentSession(): MediaSession? = activeInstance?.get()?.screenSession
    }
    /** Asks for notifications (Android 13+) and video access in one go; video access lets next / previous work in the same folder. */
    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasVideoAccess()) {
            val current = currentUri
            if (current != null && queuedFolderUris.isEmpty()) queueFolderSiblings(current)
        } else if (!historyPrefs.getBoolean("video_access_hint_shown", false)) {
            historyPrefs.edit().putBoolean("video_access_hint_shown", true).apply()
            Toast.makeText(this, "Allow video access in the phone's app settings to use next / previous in the same folder", Toast.LENGTH_LONG).show()
        }
    }
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var orientationButton: TextView
    private lateinit var audioBoostButton: TextView
    private lateinit var leftTools: LinearLayout
    private lateinit var brightnessPanel: LinearLayout
    private lateinit var brightnessPercent: TextView
    private lateinit var brightnessBar: LevelBarView
    private lateinit var volumePanel: LinearLayout
    private lateinit var volumePercentText: TextView
    private lateinit var volumeBar: LevelBarView
    private lateinit var skipBackPanel: LinearLayout
    private lateinit var skipFwdPanel: LinearLayout
    private lateinit var skipBackArrows: LinearLayout
    private lateinit var skipFwdArrows: LinearLayout
    private lateinit var skipBackLabel: TextView
    private lateinit var skipFwdLabel: TextView
    private var skipIndicatorActive = false
    private var skipIndicatorForward = true
    private var skipAccumSeconds = 0
    private var topTouch = false
    private var gestureSeekTarget = 0L
    private var statusBarShownUntil = 0L
    private lateinit var fullscreenButton: TextView
    private lateinit var bottomBar: LinearLayout
    private lateinit var speedButton: TextView
    private lateinit var decoderButton: TextView
    private lateinit var subtitleButton: TextView
    private var volumeBoostEnhancer: LoudnessEnhancer? = null
    private var voiceClarityLevel = 0 // 0=off, 1=light, 2=balanced, 3=strong
    private val voiceClarityEnabled: Boolean get() = voiceClarityLevel > 0
    private var selectedSpeed = 2f
    private lateinit var clarityButton: TextView
    private lateinit var autoSkipButton: TextView
    private var autoSkipMode = 0 // 0=off, 1=mild, 2=strong
    private var temporarySpeedActive = false
    private var temporarySpeedPrevious = 1f
    private var holdBaseSpeed = 2f
    private var longPressSpeedMode = false
    private var longPressStartY = 0f
    private var longPressStartX = 0f
    private var longPressRunnable: Runnable? = null
    private var speedButtonLongPressRunnable: Runnable? = null
    private var speedButtonDownY = 0f
    private var speedButtonDownX = 0f
    private var speedButtonDownAt = 0L
    private val endTemporarySpeedRunnable = Runnable { endTemporarySpeed() }
    private lateinit var timeLeftText: TextView
    private lateinit var playPauseButton: TextView
    private lateinit var previousButton: TextView
    private lateinit var nextButton: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var etaText: TextView
    private var seekTickScheduled = false
    // Disk/content-provider work (history, file names) runs here so opening a video never waits on it.
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private var volumePercent = 100
    private var gestureSensitivity = 1.0f
    private var seekSeconds = 10
    private var subtitleSize = 0.0533f
    private var subtitleBottom = 0.08f
    private var gestureStartVolumePercent = 100
    private var gestureStartSystemVolume = 0
    private var gestureStartSystemMax = 1
    private lateinit var selectButton: TextView
    private lateinit var lockButton: TextView
    private lateinit var pipButton: TextView
    private lateinit var backgroundButton: TextView
    private lateinit var fitButton: TextView
    private lateinit var gestureHint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val hideStatusBarRunnable = Runnable { hideStatusBarOnly() }
    private var controlsVisible = false
    private var locked = false
    private var userSeeking = false
    private var lastScrubSeekAt = 0L
    private var lastScrubSec = -1L
    private var resumeAfterScrub = false
    private var pendingScrubTarget = -1L
    private val scrubTrailingRunnable = Runnable {
        val t = pendingScrubTarget
        if (t >= 0L && ::player.isInitialized && (userSeeking || gestureMode == 1)) scrubSeekTo(t)
    }

    /**
     * Seek while dragging (seekbar or swipe). The next seek goes out as soon as the previous one has put a frame
     * on screen (player back in READY), so the picture follows the finger as fast as the decoder can deliver
     * frames without flooding it; after 300 ms a seek is sent regardless. A held-still finger still gets the
     * latest position through a short trailing retry.
     */
    private fun scrubSeekTo(target: Long) {
        pendingScrubTarget = target
        handler.removeCallbacks(scrubTrailingRunnable)
        val now = SystemClock.uptimeMillis()
        val elapsed = now - lastScrubSeekAt
        if (elapsed >= 300L || (elapsed >= SCRUB_MIN_GAP_MS && player.playbackState == Player.STATE_READY)) {
            lastScrubSeekAt = now
            pendingScrubTarget = -1L
            // Keyframe seeks, like the final seek on release (MX shows no jump when the finger is lifted), so each update is fast.
            player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
            player.seekTo(target)
        } else {
            handler.postDelayed(scrubTrailingRunnable, 30L)
        }
    }

    private fun cancelScrubSeek() {
        pendingScrubTarget = -1L
        handler.removeCallbacks(scrubTrailingRunnable)
    }
    private var brightnessBeforeGesture = -1f
    private val speeds = listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 2.5f, 3f)
    private data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartPosition = 0L
    private var gestureMode = 0 // 0 unknown, 1 seek, 2 brightness, 3 volume
    private var fitMode = 0
    private val fitModes = listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FIT)
    private val fitModeNames = listOf("Fit", "Stretch", "Crop/Zoom", "Fit with black bars")
    private val historyPrefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }
    private var currentUri: Uri? = null
    private var resumePosition = 0L
    private var subtitleUri: Uri? = null
    private var audioDelayMs = 0
    private var subtitleSyncMs = 0
    private var decoderMode = 1 // 0=HW, 1=HW+, 2=SW
    private var orientationMode = 1 // 1=Landscape, 2=Portrait; playback defaults to landscape
    private var orientationRequestedFor: String? = null
    private var orientationDecidedFor: String? = null
    private var horizontalFlip = false
    /** Crop box for the current video as fractions (left, top, right, bottom) of the picture; null = no crop. Saved per video. */
    private var cropRect: FloatArray? = null
    private var cropEditor: android.view.View? = null
    private lateinit var cropButton: TextView
    private var cropBeforeEdit: FloatArray? = null
    private var zoomScale = 1f
    private var zoomFocusX = 0f
    private var zoomFocusY = 0f
    private var zoomFocusValid = false
    private var panX = 0f
    private var panY = 0f
    private var lastVideoTitle = "Alvi Player"
    private var hapticsEnabled = true
    private var autoPictureInPicture = false
    private var autoSkipSilence = false
    private var fastSeekEnabled = true
    private var earphoneControlsEnabled = true
    private var repeatMode = Player.REPEAT_MODE_OFF
    private var notificationStarted = false
    private var resumeAfterHandoff = false
    private var lastNotificationPlaying: Boolean? = null
    private var lastNotificationTitle: String? = null
    /** Set by the notification's Stop button: keeps the notification away until playback is started again. */
    private var notificationSuppressed = false
    private var queuedFolderUris: List<Uri> = emptyList()
    /** The video the person actually opened; a failure on it is reported, a failure on a queued neighbour is skipped. */
    private var openedAnchorUri: Uri? = null
    /** True once the opened video has started playing; a failure before that leaves a black screen, so the home panel is shown. */
    private var playbackReady = false
    private val aliasRetried = HashSet<String>()
    private var externalSubtitleCues: List<SubtitleCue> = emptyList()
    private var subtitleExecutor = Executors.newSingleThreadExecutor()
    private lateinit var externalSubtitleView: TextView

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            openVideo(uri, true)
        }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            attachSubtitle(uri)
        }
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
            historyPrefs.edit().putString("folder_uri", uri.toString()).apply()
            Toast.makeText(this, "Folder access saved. Use Folder videos in More to browse files.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Performance: read the phone's decoder list on a side thread while the screen is being built, so the first video
        // does not wait for it (Media3 keeps the result in a cache).
        Thread {
            for (mime in arrayOf("video/avc", "video/hevc", "video/x-vnd.on2.vp9", "audio/mp4a-latm")) {
                try { androidx.media3.exoplayer.mediacodec.MediaCodecUtil.getDecoderInfos(mime, false, false) } catch (_: Throwable) { }
            }
        }.apply { name = "alvi-codec-warmup" }.start()
        activeInstance = WeakReference(this)
        enableLandscapeAutoRotation()
        prepareSystemBars()
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (cropEditor != null) {
                    cropRect = cropBeforeEdit
                    closeCropEditor()
                } else if (locked) {
                    flashLockButton()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        val wantedPermissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            wantedPermissions.add(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        if (!hasVideoAccess()) {
            wantedPermissions.add(if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_VIDEO else android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (wantedPermissions.isNotEmpty()) permissionsLauncher.launch(wantedPermissions.toTypedArray())
        selectedSpeed = historyPrefs.getFloat("selected_speed", 2f)
        volumePercent = historyPrefs.getInt("volume_percent", 100).coerceIn(0, 200)
        gestureSensitivity = historyPrefs.getFloat("gesture_sensitivity", 1.0f).coerceIn(0.5f, 2.0f)
        seekSeconds = historyPrefs.getInt("seek_seconds", 10).coerceIn(5, 30)
        subtitleSize = historyPrefs.getFloat("subtitle_size", 0.0533f).coerceIn(0.03f, 0.10f)
        subtitleBottom = historyPrefs.getFloat("subtitle_bottom", 0.08f).coerceIn(0f, 0.30f)
        fitMode = historyPrefs.getInt("fit_mode", 0).coerceIn(0, fitModes.lastIndex)
        decoderMode = historyPrefs.getInt("decoder_mode", 1).coerceIn(0, 2)
        orientationMode = historyPrefs.getInt("orientation_mode", 1).coerceIn(1, 2)
        horizontalFlip = historyPrefs.getBoolean("horizontal_flip", false)
        // Crops are saved per video ("crop_<video>"); drop the single global crop an earlier build stored.
        historyPrefs.edit().remove("crop_on").remove("crop_l").remove("crop_t").remove("crop_r").remove("crop_b").apply()
        hapticsEnabled = historyPrefs.getBoolean("haptics", true)
        autoPictureInPicture = historyPrefs.getBoolean("auto_pip", true)
        autoSkipMode = historyPrefs.getInt("auto_skip_mode", if (historyPrefs.getBoolean("auto_skip_silence", false)) 1 else 0).coerceIn(0, 2)
        autoSkipSilence = autoSkipMode > 0
        fastSeekEnabled = historyPrefs.getBoolean("fast_seek", true)
        earphoneControlsEnabled = historyPrefs.getBoolean("earphone_controls", true)
        repeatMode = historyPrefs.getInt("repeat_mode", Player.REPEAT_MODE_OFF).coerceIn(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL)
        voiceClarityLevel = historyPrefs.getInt("voice_clarity_level", if (historyPrefs.getBoolean("voice_clarity", false)) 2 else 0).coerceIn(0, 3)
        VoiceClarityState.level = voiceClarityLevel
        subtitleSyncMs = historyPrefs.getInt("subtitle_sync_ms", 0).coerceIn(-5000, 5000)
        applyOrientationMode()
        applySubtitleStyle()
        buildPlayer()
        syncVolumeFromSystem(keepBoost = false)   // follow the phone's media volume; never change it just because the app opened
        playPauseButton.setOnClickListener { if (player.isPlaying) player.pause() else player.play(); updateUi(); showControlsTemporarily() }
        selectButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        lockButton.setOnClickListener {
            if (locked) unlockScreen() else lockScreen()
        }
        updateButtonStates()
                installSpeedButtonGesture()
        // Live scrubbing (MX Player style): the whole video frame follows the thumb while dragging; the elapsed and
        // remaining times beside the seekbar follow the finger. No thumbnail box, no centre readout. Same in portrait and landscape.
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                userSeeking = true
                cancelAutoHide()
                lastScrubSeekAt = 0L
                lastScrubSec = -1L
                // Stay paused for as long as the finger is on the seekbar; playback resumes on release.
                resumeAfterScrub = player.playWhenReady
                if (resumeAfterScrub) player.pause()
            }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && player.duration > 0 && player.duration != C.TIME_UNSET) {
                    val target = (player.duration * progress / SEEK_MAX).coerceIn(0L, player.duration)
                    // Text is rebuilt only when the displayed second changes (TextView relayout is the costly part).
                    val sec = target / 1000L
                    if (sec != lastScrubSec) {
                        lastScrubSec = sec
                        positionText.text = formatMs(target)
                        showRemaining(target, player.duration)
                    }
                    scrubSeekTo(target)
                }
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val duration = player.duration
                if (duration > 0 && duration != C.TIME_UNSET) {
                    val target = (duration * (seekBar?.progress ?: 0) / SEEK_MAX).coerceIn(0L, duration)
                    player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                    player.seekTo(target)
                }
                userSeeking = false
                cancelScrubSeek()
                if (resumeAfterScrub) { resumeAfterScrub = false; player.play() }
                lastShownPosSec = -2L; lastShownRemSec = -2L; lastShownEtaKey = -2L
                showControlsTemporarily()
            }
        })
        installGestures()
        speedButton.text = speedBtnLabel(selectedSpeed)
        playerView.resizeMode = fitModes[fitMode]
        fitButton.contentDescription = "Screen fit: ${fitModeNames[fitMode]}"
        applyZoom()
        val handledIncoming = handleIncomingIntent(intent)
        // If background play is still running, keep it going while the video loads and then join its live position,
        // instead of stopping it first (which left silence and reopened at an old saved position).
        val serviceSnap = if (!handledIncoming && historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)) {
            BackgroundPlaybackService.snapshot()
        } else null
        if (!handledIncoming && serviceSnap == null && historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)) {
            stopService(Intent(this, BackgroundPlaybackService::class.java).apply { action = BackgroundPlaybackService.ACTION_STOP })
            historyPrefs.edit().putBoolean(BackgroundPlaybackService.KEY_ACTIVE, false).apply()
        }
        if (!handledIncoming) {
            val last = serviceSnap?.uri ?: historyPrefs.getString("last_uri", null)
            if (!last.isNullOrBlank()) {
                try {
                    openVideo(Uri.parse(last), true)
                    if (serviceSnap != null) {
                        player.seekTo(serviceSnap.positionMs)
                        player.playWhenReady = false
                        syncWasPlaying = serviceSnap.playing
                        syncPollCount = 0
                        handler.removeCallbacks(syncFromServiceRunnable)
                        handler.post(syncFromServiceRunnable)
                    }
                } catch (_: Exception) {
                    Toast.makeText(this, "The last video is no longer accessible", Toast.LENGTH_LONG).show()
                    showHomePanel()
                }
            } else {
                showHomePanel()
            }
        }
        handler.post(updateRunnable)
        setControlsVisible(false)
    }

    private fun showHomePanel(failed: Uri? = null) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(24), dp(28), dp(24)); background = roundedBackground(0xF0161616.toInt(), 28)
        }
        val title = TextView(this).apply { text = "ALVI PLAYER"; textSize = 26f; letterSpacing = 0.12f; setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD)); setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val sub = TextView(this).apply { text = "Fast, focused video playback"; textSize = 14f; setTextColor(0xFFBDBDBD.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(18)) }
        panel.addView(title); panel.addView(sub)
        val open = button("Open video", true)
        val folder = button("Open folder")
        panel.addView(open, LinearLayout.LayoutParams(dp(220), dp(50)).apply { bottomMargin = dp(8) })
        panel.addView(folder, LinearLayout.LayoutParams(dp(220), dp(50)).apply { bottomMargin = dp(16) })
        open.setOnClickListener { pickVideo.launch(arrayOf("video/*")); panel.visibility = View.GONE }
        folder.setOnClickListener { pickFolder.launch(null); panel.visibility = View.GONE }
        val recent = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }.distinctBy { it.toString() }.filter { it != failed }.take(3)
        if (recent.isNotEmpty()) {
            val recentTitle = TextView(this).apply { text = "Recent"; textSize = 13f; setTextColor(0xFF8AB4F8.toInt()); gravity = Gravity.LEFT; setPadding(0, 0, 0, dp(8)) }
            panel.addView(recentTitle, LinearLayout.LayoutParams(-1, -2))
            recent.forEach { uri ->
                val item = TextView(this).apply { text = displayName(uri); textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(10), 0); background = roundedBackground(0xFF252525.toInt(), 12); isClickable = true }
                item.setOnClickListener { openVideo(uri, true); panel.visibility = View.GONE }
                panel.addView(item, LinearLayout.LayoutParams(dp(280), dp(44)).apply { bottomMargin = dp(6) })
            }
        }
        root.addView(panel, FrameLayout.LayoutParams(dp(330), -2, Gravity.CENTER))
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        // TextureView surface (see res/layout/alvi_player_view.xml): zoom and pan are drawn in the same frame as the fingers move.
        playerView = (android.view.LayoutInflater.from(this).inflate(R.layout.alvi_player_view, root, false) as PlayerView).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        playerView.addOnLayoutChangeListener { _, l, t, r, b, oldL, oldT, oldR, oldB ->
            if (cropRect != null && (r - l != oldR - oldL || b - t != oldB - oldT)) applyZoom()
        }

        externalSubtitleView = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif", Typeface.NORMAL); gravity = Gravity.CENTER
            setPadding(dp(18), dp(4), dp(18), dp(4)); setShadowLayer(dp(3).toFloat(), 0f, dp(2).toFloat(), Color.BLACK)
            visibility = View.GONE; maxLines = 4; includeFontPadding = true
        }
        root.addView(externalSubtitleView, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            leftMargin = dp(18); rightMargin = dp(18); bottomMargin = dp(118)
        })

        // MX-style playback OSD: top bar + a single tool row below it + bottom transport strip.
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            setPadding(dp(16), 0, dp(16), 0)
            // MX Player scrim: ~50% black at the very top fading out over ~55 dp.
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x80000000.toInt(), 0x40000000, 0x00000000))
        }
        // MX Player geometry: every top-bar button is 48 dp wide with a 24 dp icon.
        selectButton = iconBtn(R.drawable.ic_arrow_back, false, 0.5f)
        selectButton.contentDescription = "Back"
        topBar.addView(selectButton, LinearLayout.LayoutParams(dp(48), dp(56)))

        titleView = TextView(this).apply {
            text = lastVideoTitle
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            includeFontPadding = false
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0)
        }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, dp(56), 1f))

        val topAudio = iconBtn(R.drawable.ic_music_note, false, 0.5f)
        topAudio.contentDescription = "Audio tracks"
        topBar.addView(topAudio, LinearLayout.LayoutParams(dp(48), dp(56)))
        topAudio.setOnClickListener { showTrackDialog() }

        val topSubtitle = iconBtn(R.drawable.ic_subtitles, false, 0.5f)
        topSubtitle.contentDescription = "Subtitles"
        subtitleButton = topSubtitle
        topBar.addView(topSubtitle, LinearLayout.LayoutParams(dp(48), dp(56)))
        topSubtitle.setOnClickListener { showTrackDialog() }

        decoderButton = plainIconButton(decoderShortLabel(), 14f).apply { setShadowLayer(0f, 0f, 0f, 0); setPadding(0, 0, 0, 0) }
        decoderButton.contentDescription = "Decoder: ${decoderName()}"
        topBar.addView(decoderButton, LinearLayout.LayoutParams(dp(48), dp(56)))

        // Picture-in-picture now lives at the bottom-right, next to the screen-fit button, exactly like MX Player.
        pipButton = iconBtn(R.drawable.ic_pip, false, 0.533f)
        pipButton.contentDescription = "Picture-in-picture"
        pipButton.setOnClickListener { enterPip(); showControlsTemporarily() }

        val moreButton = iconBtn(R.drawable.ic_more_vert, false, 0.5f)
        moreButton.contentDescription = "More options"
        topBar.addView(moreButton, LinearLayout.LayoutParams(dp(48), dp(56)))
        moreButton.setOnClickListener { showMoreDialog() }
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(80), Gravity.TOP))

        // MX-style tool row: "1X" as plain bold text, then 44 dp round buttons 6 dp apart
        // (grey #566569, light blue #6BAAFF (a bit deeper than MX) when active).
        val toolRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        leftTools = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val toolGap = dp(6)
        // Smaller than the first MX match so it sits comfortably inside the circle: up to 13sp, semi-bold white "1X". Long labels such as "0.25X" shrink to fit the 44dp button.
        speedButton = iconBtn(0, false, 0.5f).apply {
            text = speedBtnLabel(selectedSpeed)
            typeface = if (android.os.Build.VERSION.SDK_INT >= 28) Typeface.create(Typeface.create("sans-serif", Typeface.NORMAL), 700, false)
                else Typeface.create("sans-serif", Typeface.BOLD)
            maxLines = 1
            androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(this, 9, 13, 1, android.util.TypedValue.COMPLEX_UNIT_SP)
        }
        speedButton.contentDescription = "Playback speed. Tap to select; press and drag left/right to temporarily change speed."
        toolRow.addView(speedButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = toolGap })

        backgroundButton = iconBtn(R.drawable.ic_headset, true, 0.55f)
        backgroundButton.contentDescription = "Background play"
        toolRow.addView(backgroundButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = toolGap })
        backgroundButton.setOnClickListener { toggleBackgroundPlayback(); updateButtonStates(); showControlsTemporarily() }

        orientationButton = iconBtn(R.drawable.ic_screen_rotation, true, 0.58f)
        orientationButton.contentDescription = "Change landscape or portrait"
        toolRow.addView(orientationButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = toolGap })
        orientationButton.setOnClickListener { toggleOrientation() }

        autoSkipButton = iconBtn(R.drawable.ic_skip_silence, true, 0.58f)
        autoSkipButton.contentDescription = "Auto Skip Silence"
        toolRow.addView(autoSkipButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = toolGap })

        audioBoostButton = iconBtn(R.drawable.ic_graphic_eq, true, 0.56f)
        audioBoostButton.contentDescription = "Voice clarity. Tap to change level, hold for options"
        clarityButton = audioBoostButton
        toolRow.addView(audioBoostButton, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = toolGap })
        audioBoostButton.setOnClickListener { cycleVoiceClarity(); showControlsTemporarily() }
        audioBoostButton.setOnLongClickListener { showVoiceClarityDialog(); true }

        // Crop: tap to draw the crop box (the button turns blue once a crop is on); tap the blue button to undo the crop.
        cropButton = iconBtn(R.drawable.ic_crop, true, 0.55f)
        cropButton.contentDescription = "Crop video. Tap to crop; when it is blue, tap to undo the crop"
        toolRow.addView(cropButton, LinearLayout.LayoutParams(dp(44), dp(44)))
        cropButton.setOnClickListener {
            if (cropRect != null) {
                // Blue (crop on): one tap undoes the crop.
                cropRect = null
                saveCropFor(currentUri)
                applyZoom()
                updateCropButton()
                Toast.makeText(this, "Crop removed", Toast.LENGTH_SHORT).show()
            } else {
                startCropEditor()
            }
        }
        leftTools.addView(toolRow)
        root.addView(leftTools, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply {
            leftMargin = dp(20); topMargin = dp(65)
        })

        selectButton.setOnClickListener {
            if (player.mediaItemCount > 0) onBackPressedDispatcher.onBackPressed()
            else pickVideo.launch(arrayOf("video/*"))
        }
        decoderButton.setOnClickListener { showDecoderDialog() }
        autoSkipButton.setOnClickListener { showAutoSkipSilenceDialog() }

        // Bottom MX-style timeline: elapsed | seekbar | remaining, then centered transport controls.
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(28), 0, dp(28), 0)
            // MX Player scrim: ~45% black at the bottom edge fading out over ~110 dp.
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0x73000000, 0x33000000, 0x00000000))
        }
        val timelineRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        // MX times: 13 sp Roboto Regular, elapsed left-aligned, remaining right-aligned with a leading minus.
        positionText = label("0:00").apply { textSize = 13f; typeface = Typeface.create("sans-serif", Typeface.NORMAL); setShadowLayer(0f, 0f, 0f, 0); gravity = Gravity.START or Gravity.CENTER_VERTICAL; setSingleLine(true); setPadding(0, 0, 0, 0); includeFontPadding = false }
        durationText = label("0:00").apply { textSize = 13f; typeface = Typeface.create("sans-serif", Typeface.NORMAL); setShadowLayer(0f, 0f, 0f, 0); gravity = Gravity.END or Gravity.CENTER_VERTICAL; setSingleLine(true); setPadding(0, 0, 0, 0); includeFontPadding = false }
        seekBar = SeekBar(this).apply {
            max = SEEK_MAX.toInt()
            progress = 0
            minHeight = dp(30)
            minimumHeight = dp(30)
            setPadding(dp(14), 0, dp(14), 0)
            thumbOffset = dp(14)
            progressDrawable = createProfessionalSeekTrack()
            thumb = createSeekThumb()
            setSplitTrack(false)   // Material's default cuts a see-through gap in the track around the thumb
        }
        timelineRow.addView(positionText, LinearLayout.LayoutParams(dp(59), dp(42)))
        timelineRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(42), 1f))
        // Remaining time keeps its exact MX position; the expected finish clock time sits just below it.
        etaText = TextView(this).apply {
            textSize = 11f; setTextColor(0xCCFFFFFF.toInt()); typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.END; setSingleLine(true); setPadding(0, 0, 0, 0); includeFontPadding = false
            contentDescription = "Expected finish time"
        }
        val remainingBox = FrameLayout(this).apply {
            addView(durationText, FrameLayout.LayoutParams(-1, -1))
            addView(etaText, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM or Gravity.END))
        }
        timelineRow.addView(remainingBox, LinearLayout.LayoutParams(dp(59), dp(42)))
        bottomBar.addView(timelineRow, LinearLayout.LayoutParams(-1, dp(42)))

        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        // MX geometry: 98 dp between the three transport icons, 45 dp pause glyph, ~35 dp previous/next glyphs.
        previousButton = iconBtn(R.drawable.ic_skip_previous, false, 0.77f); previousButton.contentDescription = "Previous"
        playPauseButton = iconBtn(R.drawable.ic_pause, false, 1.0f); playPauseButton.contentDescription = "Play or pause"
        nextButton = iconBtn(R.drawable.ic_skip_next, false, 0.77f); nextButton.contentDescription = "Next"
        transport.addView(previousButton, LinearLayout.LayoutParams(dp(98), dp(45)))
        transport.addView(playPauseButton, LinearLayout.LayoutParams(dp(98), dp(45)))
        transport.addView(nextButton, LinearLayout.LayoutParams(dp(98), dp(45)))
        bottomBar.addView(transport, LinearLayout.LayoutParams(-1, dp(45)))
        // 42 dp timeline above a 45 dp transport row: seekbar centre 66 dp and buttons centre 22.5 dp above the bottom edge, as in MX.
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(110), Gravity.BOTTOM))

        lockButton = iconBtn(R.drawable.ic_lock_open, false, 0.533f)
        setLockIcon(false)
        root.addView(lockButton, FrameLayout.LayoutParams(dp(48), dp(45), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(28); bottomMargin = 0
        })

        // The extra "↔" button stays removed (5.9). fitButton is only a detached view so older
        // state-update code keeps compiling; the far-right button opens Screen Fit.
        fitButton = plainIconButton("", 24f)
        fitButton.contentDescription = "Screen fit / aspect ratio"

        // Bottom-right pair like MX: screen-fit (↔ in a box) and picture-in-picture, centres 106 dp and 52 dp from the edge.
        fullscreenButton = iconBtn(R.drawable.ic_aspect_fit, false, 0.533f)
        fullscreenButton.contentDescription = "Screen fit / aspect ratio"
        root.addView(fullscreenButton, FrameLayout.LayoutParams(dp(48), dp(45), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(82); bottomMargin = 0
        })
        fullscreenButton.setOnClickListener { cycleFitMode() }
        fullscreenButton.setOnLongClickListener { showFitOptions(); true }
        root.addView(pipButton, FrameLayout.LayoutParams(dp(48), dp(45), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(28); bottomMargin = 0
        })

        gestureHint = TextView(this).apply {
            text = ""; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setPadding(dp(22), dp(10), dp(22), dp(10)); background = roundedBackground(0xB3000000.toInt(), 28); visibility = View.GONE
        }
        root.addView(gestureHint, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(76) })

        // Brightness (left side) and volume (right side) level indicators: percent on top, vertical bar, icon below.
        fun levelPanel(iconRes: Int, onLeft: Boolean): Triple<LinearLayout, TextView, LevelBarView> {
            // White text and icon with a dark outline, so they stay readable on white slides as well as on dark video.
            val percent = OutlinedTextView(this).apply {
                textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; minWidth = dp(62)
                setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)) // regular weight, not bold
                outlinePx = 0.8f * resources.displayMetrics.density
            }
            val bar = LevelBarView(this)
            val icon = OutlinedIconView(this, iconRes)
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(16), dp(16), dp(16), dp(16))
                // No background box: just the percent, bar and icon floating on the screen edge.
                visibility = View.GONE; isClickable = false
                addView(percent, LinearLayout.LayoutParams(-2, -2))
                addView(bar, LinearLayout.LayoutParams(dp(7), dp(100)).apply { topMargin = dp(12) })
                addView(icon, LinearLayout.LayoutParams(dp(30), dp(30)).apply { topMargin = dp(12) })
            }
            return Triple(panel, percent, bar)
        }
        levelPanel(R.drawable.ic_brightness, true).let { brightnessPanel = it.first; brightnessPercent = it.second; brightnessBar = it.third }
        levelPanel(R.drawable.ic_volume, false).let { volumePanel = it.first; volumePercentText = it.second; volumeBar = it.third }
        root.addView(brightnessPanel, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.START))
        root.addView(volumePanel, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.END))

        // Skip indicator like MX Player (without the oval shadow): two chevrons above the seconds, centred 1/6 of the screen width from the skipped edge.
        fun skipPanel(): Triple<LinearLayout, TextView, LinearLayout> {
            val arrows = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                repeat(2) {
                    addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_skip_tri) }, LinearLayout.LayoutParams(dp(13), dp(14)))
                }
            }
            val secs = OutlinedTextView(this).apply {
                text = "10s"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                includeFontPadding = false
                setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)) // regular Roboto, as in MX Player
                outlinePx = 0.8f * resources.displayMetrics.density   // thin dark outline: readable on white slides too
            }
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                visibility = View.GONE; isClickable = false
                addView(arrows, LinearLayout.LayoutParams(-2, -2))
                addView(secs, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
            }
            return Triple(panel, secs, arrows)
        }
        skipPanel().let { skipBackPanel = it.first; skipBackLabel = it.second; skipBackArrows = it.third }
        skipPanel().let { skipFwdPanel = it.first; skipFwdLabel = it.second; skipFwdArrows = it.third }
        // Backward chevrons point left.
        for (i in 0 until skipBackArrows.childCount) skipBackArrows.getChildAt(i).scaleX = -1f
        // Right at the screen edges (40 dp in), so they stay clear of the video content.
        root.addView(skipBackPanel, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.START).apply { leftMargin = dp(40) })
        root.addView(skipFwdPanel, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.END).apply { rightMargin = dp(40) })


        timeLeftText = label("").apply { visibility = View.GONE }
        setContentView(root)
        applyMaxPerformance()
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val cut = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
            applyCutoutInsets(cut.left, cut.right)
            insets
        }
        installEdgeGestureExclusion()
        root.requestApplyInsets()

        playPauseButton.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
            updateUi(); showControlsTemporarily()
        }
        previousButton.setOnClickListener {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else seekFast(max(0L, player.currentPosition - seekSeconds * 1000L))
            showControlsTemporarily()
        }
        nextButton.setOnClickListener {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem() else Toast.makeText(this, "No next video", Toast.LENGTH_SHORT).show()
            showControlsTemporarily()
        }
        lockButton.setOnClickListener { if (locked) unlockScreen() else lockScreen() }
    }


    /**
     * Fast ±10-second gesture seek. CLOSEST_SYNC lets Media3 land on a nearby
     * keyframe instead of waiting for an exact frame; this can reduce seek delay,
     * but exact zero-buffer seeking cannot be guaranteed for every file/source.
     */
    private fun seekFast(targetMs: Long) {
        if (::skipBackPanel.isInitialized) showSkipIndicator(targetMs >= player.currentPosition)
        val duration = player.duration
        val safeTarget = if (duration > 0 && duration != C.TIME_UNSET) targetMs.coerceAtMost(duration) else targetMs
        if (fastSeekEnabled) {
            player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
            player.seekTo(safeTarget)
            handler.removeCallbacks(restoreSeekParametersRunnable)
            handler.postDelayed(restoreSeekParametersRunnable, 700L)
        } else {
            player.setSeekParameters(SeekParameters.EXACT)
            player.seekTo(safeTarget)
        }
    }

    private val hideSkipRunnable = Runnable {
        if (!::skipBackPanel.isInitialized) return@Runnable
        skipIndicatorActive = false
        listOf(skipBackPanel, skipFwdPanel).forEach { v ->
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(220L).withEndAction { v.visibility = View.GONE }.start()
        }
    }

    /** Shows the skipped seconds on the skipped side; repeated skips in one direction add up (10s, 20s, 30s...). */
    private fun showSkipIndicator(forward: Boolean) {
        val shown = if (forward) skipFwdPanel else skipBackPanel
        val other = if (forward) skipBackPanel else skipFwdPanel
        skipAccumSeconds = if (skipIndicatorActive && skipIndicatorForward == forward) skipAccumSeconds + seekSeconds else seekSeconds
        skipIndicatorActive = true; skipIndicatorForward = forward
        other.animate().cancel(); other.visibility = View.GONE
        (if (forward) skipFwdLabel else skipBackLabel).text = "${skipAccumSeconds}s"
        shown.animate().cancel(); shown.alpha = 1f; shown.visibility = View.VISIBLE
        // Chevrons light up one after the other in the direction of the skip.
        val arrows = if (forward) skipFwdArrows else skipBackArrows
        for (i in 0 until arrows.childCount) {
            val order = if (forward) i else arrows.childCount - 1 - i
            val c = arrows.getChildAt(i)
            c.animate().cancel(); c.alpha = 0.25f
            c.animate().alpha(1f).setStartDelay(order * 110L).setDuration(140L).start()
        }
        handler.removeCallbacks(hideSkipRunnable)
        handler.postDelayed(hideSkipRunnable, 650L)
    }

    /**
     * Touch near the top edge: first touch shows the phone's own status bar (time, battery,
     * signal); a second touch while it is showing pulls down the notification panel.
     */
    private fun onTopTouch() {
        val now = SystemClock.elapsedRealtime()
        if (now < statusBarShownUntil) {
            statusBarShownUntil = 0L
            expandNotificationPanel()
        } else {
            showStatusBarTemporarily()
            statusBarShownUntil = now + 4000L
        }
    }

    private fun expandNotificationPanel() {
        try {
            val statusBarService = getSystemService("statusbar")
            statusBarService?.javaClass?.getMethod("expandNotificationsPanel")?.invoke(statusBarService)
        } catch (_: Exception) {
            Toast.makeText(this, "Swipe down on the status bar to open notifications", Toast.LENGTH_SHORT).show()
        }
    }

    private val restoreSeekParametersRunnable = Runnable {
        if (::player.isInitialized) player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
    }

    private val hideLockRunnable = Runnable {
        if (locked) lockButton.animate().alpha(0f).setDuration(180L).withEndAction { if (locked) lockButton.visibility = View.GONE }.start()
    }

    /** Padlock icon: plain open padlock when unlocked, closed padlock on a red circle when locked. */
    private fun setLockIcon(isLocked: Boolean) {
        (lockButton.tag as? BtnState)?.let {
            it.res = if (isLocked) R.drawable.ic_lock else R.drawable.ic_lock_open
            it.circle = isLocked
            // Locked: solid white disc with a dark padlock (readable on white slides too). Unlocked: plain white padlock.
            it.color = if (isLocked) 0xFFFFFFFF.toInt() else 0
            it.iconTint = if (isLocked) 0xFF1A1A1A.toInt() else 0xFFFFFFFF.toInt()
        }
        renderButton(lockButton)
        lockButton.contentDescription = if (isLocked) "Screen locked. Tap to unlock" else "Lock screen"
    }

    /** Briefly shows the red closed padlock so the locked state is obvious. */
    private fun flashLockButton() {
        setLockIcon(true)
        handler.removeCallbacks(hideLockRunnable)
        lockButton.animate().cancel()
        lockButton.alpha = 0f
        lockButton.visibility = View.VISIBLE
        lockButton.animate().alpha(1f).setDuration(160L).start()
        handler.postDelayed(hideLockRunnable, 1800L)
    }

    private fun lockScreen() {
        locked = true
        setControlsVisible(false)
        flashLockButton()
        Toast.makeText(this, "Screen locked", Toast.LENGTH_SHORT).show()
    }

    private fun unlockScreen() {
        locked = false
        handler.removeCallbacks(hideLockRunnable)
        lockButton.animate().cancel()
        setLockIcon(false)
        lockButton.alpha = 1f
        setControlsVisible(true)
        Toast.makeText(this, "Screen unlocked", Toast.LENGTH_SHORT).show()
    }

    /** MX-style hold-and-drag speed control. Hold the video, then move left/right. */
    private fun startTemporarySpeed(startX: Float) {
        if (temporarySpeedActive || !::player.isInitialized || player.mediaItemCount == 0) return
        temporarySpeedPrevious = selectedSpeed
        longPressStartX = startX
        temporarySpeedActive = true
        longPressSpeedMode = true
        // Hold starts at the speed you used the last time you held (saved); drag right/left changes it in 0.1× steps.
        holdBaseSpeed = (Math.round(historyPrefs.getFloat("hold_speed", selectedSpeed) * 10f) / 10f).coerceIn(0.1f, 4f)
        player.setPlaybackSpeed(holdBaseSpeed)
        if (::speedButton.isInitialized) speedButton.text = speedBtnLabel(holdBaseSpeed)
        showGestureHint(speedLabel(holdBaseSpeed), compact = true)
        haptic()
    }

    /**
     * [stepPx] is the drag distance the callers use for a 0.5× change; the speed now moves in 0.1× steps,
     * so one step is a fifth of that distance.
     */
    private fun applyTemporarySpeedDrag(dx: Float, stepPx: Float) {
        if (!::player.isInitialized || stepPx <= 0f) return
        val steps = (dx / (stepPx / 5f)).toInt()
        val tenths = (Math.round(holdBaseSpeed * 10f) + steps).coerceIn(1, 40)
        val speed = tenths / 10f
        if (player.playbackParameters.speed == speed) return
        player.setPlaybackSpeed(speed)
        showGestureHint(speedLabel(speed), compact = true)
        if (::speedButton.isInitialized) speedButton.text = speedBtnLabel(speed)
        if (tenths % 5 == 0) haptic() // a light tick only on whole and half speeds
    }

    private fun endTemporarySpeed() {
        longPressRunnable?.let { handler.removeCallbacks(it) }
        longPressRunnable = null
        if (!temporarySpeedActive || !::player.isInitialized) return
        temporarySpeedActive = false
        longPressSpeedMode = false
        // Remember the speed you ended on: the next hold starts there.
        historyPrefs.edit().putFloat("hold_speed", player.playbackParameters.speed).apply()
        player.setPlaybackSpeed(temporarySpeedPrevious)
        if (::speedButton.isInitialized) speedButton.text = speedBtnLabel(temporarySpeedPrevious)
        gestureHint.visibility = View.GONE
    }

    /** MX-style speed button gesture: hold the 2×/speed control, then drag left/right.
     * Drag right increases temporary speed; drag left decreases it. Release restores the
     * previously selected speed. A short tap still opens the normal speed selector.
     */
    private fun installSpeedButtonGesture() {
        speedButton.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    speedButtonDownY = event.rawY
                    speedButtonDownAt = SystemClock.elapsedRealtime()
                    speedButtonDownX = event.rawX
                    speedButtonLongPressRunnable?.let { handler.removeCallbacks(it) }
                    speedButtonLongPressRunnable = Runnable {
                        if (::player.isInitialized && player.mediaItemCount > 0) {
                            startTemporarySpeed(speedButtonDownX)
                        }
                    }
                    handler.postDelayed(speedButtonLongPressRunnable!!, 220L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (temporarySpeedActive) {
                        // Stepped temporary speed: every horizontal step changes by exactly 0.5×.
                        applyTemporarySpeedDrag(event.rawX - speedButtonDownX, dp(32).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    speedButtonLongPressRunnable?.let { handler.removeCallbacks(it) }
                    speedButtonLongPressRunnable = null
                    if (temporarySpeedActive) {
                        endTemporarySpeed()
                    } else if (event.actionMasked == MotionEvent.ACTION_UP && SystemClock.elapsedRealtime() - speedButtonDownAt < 500L) {
                        showSpeedDialog()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun installGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (e.y < dp(80)) return true
                if (locked) flashLockButton() else toggleControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked || e.y < dp(80)) return true
                if (e.x < root.width * 0.35f) seekFast(max(0L, player.currentPosition - seekSeconds * 1000L))
                else if (e.x > root.width * 0.65f) seekFast(player.currentPosition + seekSeconds * 1000L)
                else if (zoomScale > 1.01f) resetZoom() else if (player.isPlaying) player.pause() else player.play()
                haptic(); return true
            }
        })
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (locked || player.mediaItemCount == 0) return true
                longPressRunnable?.let { handler.removeCallbacks(it) }
                if (playerView.resizeMode != AspectRatioFrameLayout.RESIZE_MODE_FIT) playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                val oldScale = zoomScale
                val newScale = (zoomScale * detector.scaleFactor).coerceIn(1f, 4f)
                val fx = detector.focusX; val fy = detector.focusY
                if (!zoomFocusValid) { zoomFocusX = fx; zoomFocusY = fy; zoomFocusValid = true }
                // Zoom around the fingers, not the middle of the screen: the picture point that was under the fingers stays under them
                // (and follows them if they move).
                val cx = playerView.width / 2f; val cy = playerView.height / 2f
                val ratio = newScale / oldScale
                panX = (fx - cx) - ratio * ((zoomFocusX - cx) - panX)
                panY = (fy - cy) - ratio * ((zoomFocusY - cy) - panY)
                zoomScale = newScale
                zoomFocusX = fx; zoomFocusY = fy
                applyZoom(); return true
            }
        })
        playerView.setOnTouchListener { _, rawEvent ->
            // The view being zoomed is also the view that receives the touches. In its own (scaled) coordinates a pinch keeps
            // changing while it is applied, which made the whole picture shake. Work in the parent's fixed screen coordinates instead.
            val event = MotionEvent.obtain(rawEvent)
            event.transform(playerView.matrix)
            event.offsetLocation(playerView.left.toFloat(), playerView.top.toFloat())
            try {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> zoomFocusValid = false
            }
            scaleDetector.onTouchEvent(event); detector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    topTouch = event.y < dp(80)
                    // The status bar (time, battery) now only appears with the system's own swipe-down from the top edge, never on a tap.
                    gestureStartX = event.x; gestureStartY = event.y; gestureStartPosition = player.currentPosition; gestureMode = 0
                    longPressStartY = event.y
                    longPressStartX = event.x
                    longPressRunnable?.let { handler.removeCallbacks(it) }
                    longPressRunnable = Runnable {
                        if (!locked && !topTouch && player.mediaItemCount > 0 && gestureMode == 0) startTemporarySpeed(gestureStartX)
                    }
                    handler.postDelayed(longPressRunnable!!, ViewConfiguration.getLongPressTimeout().toLong())
                    brightnessBeforeGesture = window.attributes.screenBrightness
                    if (brightnessBeforeGesture < 0f) brightnessBeforeGesture = 0.5f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (locked || topTouch) return@setOnTouchListener true
                    if (longPressSpeedMode) {
                        // Every 10% of screen width dragged = one 0.5× step. Release restores the default speed.
                        applyTemporarySpeedDrag(event.x - longPressStartX, root.width * 0.045f)
                        return@setOnTouchListener true
                    }
                    if (event.pointerCount >= 2) {
                        longPressRunnable?.let { handler.removeCallbacks(it) }
                        if (zoomScale > 1.01f && !scaleDetector.isInProgress) {
                            // Two-finger drag while zoomed in: the picture follows the midpoint of the fingers.
                            val fx = (event.getX(0) + event.getX(1)) / 2f; val fy = (event.getY(0) + event.getY(1)) / 2f
                            if (zoomFocusValid) { panX += fx - zoomFocusX; panY += fy - zoomFocusY; applyZoom() }
                            zoomFocusX = fx; zoomFocusY = fy; zoomFocusValid = true
                        }
                        return@setOnTouchListener true
                    }
                    val dx = event.x - gestureStartX; val dy = event.y - gestureStartY
                    if (gestureMode == 0 && (abs(dx) > dp(18) || abs(dy) > dp(18))) {
                        // Let a genuine long-press speed gesture win once the hold has matured.
                        if (!temporarySpeedActive) {
                            longPressRunnable?.let { handler.removeCallbacks(it) }
                            longPressRunnable = null
                            gestureMode = if (abs(dx) > abs(dy)) 1 else if (gestureStartX < root.width / 2f) 2 else 3
                        }
                        if (gestureMode == 3) {
                            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                            gestureStartSystemVolume = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                            gestureStartSystemMax = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                            syncVolumeFromSystem(keepBoost = true)
                            gestureStartVolumePercent = volumePercent
                        }
                        cancelAutoHide()
                    }
                    when (gestureMode) {
                        1 -> {
                            val delta = (dx / root.width * 120_000L * gestureSensitivity).toLong(); val target = max(0L, gestureStartPosition + delta)
                            val clamped = if (player.duration > 0 && player.duration != C.TIME_UNSET) target.coerceAtMost(player.duration) else target
                            gestureSeekTarget = clamped
                            // Frame-paced fast keyframe seeks while dragging; the finger-up seek is final.
                            scrubSeekTo(clamped)
                            showGestureHint("${if (delta >= 0) "+" else "−"}${formatMs(abs(delta))}")
                        }
                        2 -> {
                            val value = (brightnessBeforeGesture - (dy / root.height) * gestureSensitivity).coerceIn(0f, 1f)
                            if (abs(value - lastAppliedBrightness) >= 0.004f || value == 0f || value == 1f) {
                                lastAppliedBrightness = value
                                val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                            }
                            showLevelIndicator(brightness = true, percent = (value * 100).roundToInt(), fraction = value)
                        }
                        3 -> {
                            val deltaPercent = (-dy / root.height * 200f * gestureSensitivity).roundToInt()
                            applyGestureVolume((gestureStartVolumePercent + deltaPercent).coerceIn(0, 200)); showLevelIndicator(brightness = false, percent = volumePercent, fraction = volumePercent / 200f)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressRunnable?.let { handler.removeCallbacks(it) }; longPressRunnable = null
                    if (temporarySpeedActive) endTemporarySpeed()
                    if (gestureMode == 1 && ::player.isInitialized) {
                        cancelScrubSeek()
                        player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                        player.seekTo(gestureSeekTarget)
                    }
                    if (gestureMode != 0) {
                        gestureHint.visibility = View.GONE
                        if (gestureMode == 2 || gestureMode == 3) scheduleHideLevelIndicators(500L)
                        showControlsTemporarily()
                    }
                    gestureMode = 0; true
                }
                else -> true
            }
            } finally { event.recycle() }
        }
    }

    private fun handleIncomingIntent(incoming: Intent?): Boolean {
        val uri = incoming?.data ?: if (android.os.Build.VERSION.SDK_INT >= 33) {
            incoming?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") incoming?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (uri == null) return false
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        openVideo(uri, true)
        return true
    }

    private fun openVideo(uri: Uri, resume: Boolean) {
        saveCurrentProgress()
        queuedFolderUris = emptyList()
        openedAnchorUri = uri
        playbackReady = false
        orientationRequestedFor = null; orientationDecidedFor = null
        loadCropFor(uri)
        currentUri = uri
        // Show a title at once; the real file name is looked up off the main thread and swapped in.
        lastVideoTitle = nameCache[uri.toString()] ?: (uri.lastPathSegment ?: "Video")
        if (!nameCache.containsKey(uri.toString())) ioExecutor.execute {
            val resolved = displayName(uri)
            handler.post { if (currentUri == uri) { lastVideoTitle = resolved; updateTitle() } }
        }
        val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
        subtitleUri = savedSubtitle
        externalSubtitleCues = emptyList()
        externalSubtitleView.text = ""
        externalSubtitleView.visibility = View.GONE
        val item = if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri)
        player.setMediaItem(item)
        player.prepare()
        if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
        val saved = if (resume) historyPrefs.getLong("pos_${uri}", 0L) else 0L
        player.seekTo(saved)
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        recordHistory(uri)
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateUi()
        decideOrientation(uri)
        queueFolderSiblings(uri)
    }

    /** Performance over battery: ask for steady (non-throttled) CPU speed and give the UI thread CPU first. The refresh rate is left to the phone's own setting (60 Hz here), not forced to the highest. */
    private fun applyMaxPerformance() {
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY) } catch (_: Exception) { }   // UI thread gets CPU first
        try {
            if (Build.VERSION.SDK_INT >= 24) {
                val power = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                if (power.isSustainedPerformanceModeSupported) window.setSustainedPerformanceMode(true)
            }
        } catch (_: Exception) { }
    }

    private fun hasVideoAccess(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_VIDEO else android.Manifest.permission.READ_EXTERNAL_STORAGE
        return checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun mediaItemFor(uri: Uri): MediaItem {
        val sub = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
        return if (sub != null && !isCustomSubtitle(sub)) buildVideoItem(uri, sub) else MediaItem.fromUri(uri)
    }

    /** Looks up the other videos in [opened]'s folder off the main thread and, if found, queues them around it without interrupting playback. */
    private fun queueFolderSiblings(opened: Uri) {
        if (!hasVideoAccess()) return
        ioExecutor.execute {
            val found = try { findFolderVideos(opened) } catch (_: Exception) { null }
            if (found != null) handler.post { applyFolderQueue(opened, found.first, found.second) }
        }
    }

    private fun applyFolderQueue(opened: Uri, uris: List<Uri>, index: Int) {
        if (!::player.isInitialized || currentUri != opened || player.mediaItemCount != 1 || queuedFolderUris.isNotEmpty()) return
        if (index < 0 || index > uris.lastIndex) return
        val before = uris.subList(0, index).map { mediaItemFor(it) }
        val after = uris.subList(index + 1, uris.size).map { mediaItemFor(it) }
        if (before.isNotEmpty()) player.addMediaItems(0, before)
        if (after.isNotEmpty()) player.addMediaItems(after)
        // Remember the permanent MediaStore address of this video: a one-time file-manager grant dies with the app process.
        if (uris[index] != opened) historyPrefs.edit().putString("alias_$opened", uris[index].toString()).apply()
        val queue = uris.toMutableList()
        queue[index] = opened
        queuedFolderUris = queue
        updateUi()
    }

    /** Videos in the same folder as [opened] (natural name order, so "Lecture 2" comes before "Lecture 10") and the index of [opened] in them. */
    private fun findFolderVideos(opened: Uri): Pair<List<Uri>, Int>? {
        val videos = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val idCol = android.provider.MediaStore.Video.Media._ID
        val bucketCol = android.provider.MediaStore.Video.Media.BUCKET_ID
        val nameCol = android.provider.MediaStore.Video.Media.DISPLAY_NAME
        val sizeCol = android.provider.MediaStore.Video.Media.SIZE
        // 1) The opened video's own row: its id and its folder (bucket).
        val own: Pair<Long, Long>? = if (opened.authority == android.provider.MediaStore.AUTHORITY) {
            contentResolver.query(opened, arrayOf(idCol, bucketCol), null, null, null)?.use { c ->
                if (c.moveToFirst()) Pair(c.getLong(0), c.getLong(1)) else null
            }
        } else {
            // Other providers (file managers, document picker): match the file by name and size.
            val info = contentResolver.query(opened, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) Pair(c.getString(0), if (c.isNull(1)) -1L else c.getLong(1)) else null
            } ?: return null
            val name = info.first ?: return null
            val size = info.second
            val selection = if (size >= 0L) "$nameCol=? AND $sizeCol=?" else "$nameCol=?"
            val args = if (size >= 0L) arrayOf(name, size.toString()) else arrayOf(name)
            contentResolver.query(videos, arrayOf(idCol, bucketCol), selection, args, null)?.use { c ->
                if (c.moveToFirst()) Pair(c.getLong(0), c.getLong(1)) else null
            }
        }
        val (ownId, bucketId) = own ?: return null
        // 2) Every video in that folder.
        val rows = ArrayList<Pair<String, Long>>()
        contentResolver.query(videos, arrayOf(idCol, nameCol, sizeCol), "$bucketCol=?", arrayOf(bucketId.toString()), null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (id != ownId) {
                    // Leave out empty files and stale entries whose file is gone, so Next never lands on an unplayable video.
                    if (c.getLong(2) <= 0L) continue
                    val readable = try {
                        contentResolver.openFileDescriptor(android.content.ContentUris.withAppendedId(videos, id), "r")?.use { true } ?: false
                    } catch (_: Exception) { false }
                    if (!readable) continue
                }
                rows.add(Pair(c.getString(1) ?: "", id))
            }
        }
        if (rows.isEmpty()) return null
        rows.sortWith(Comparator { a, b -> naturalCompare(a.first, b.first) })
        val index = rows.indexOfFirst { it.second == ownId }
        if (index < 0) return null
        return Pair(rows.map { android.content.ContentUris.withAppendedId(videos, it.second) }, index)
    }

    /** Case-insensitive name order where digit runs compare as numbers. */
    private fun naturalCompare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ie = i
                while (ie < a.length && a[ie].isDigit()) ie++
                var je = j
                while (je < b.length && b[je].isDigit()) je++
                val na = a.substring(i, ie).trimStart('0')
                val nb = b.substring(j, je).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ie
                j = je
            } else {
                val c = ca.lowercaseChar().compareTo(cb.lowercaseChar())
                if (c != 0) return c
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }

    /** One history entry per video (most recent first), capped at 50, instead of one per launch. */
    private fun recordHistory(uri: Uri) {
        val now = System.currentTimeMillis()
        ioExecutor.execute {
            try {
                val editor = historyPrefs.edit()
                val key = uri.toString()
                val entries = historyPrefs.all.entries.filter { it.key.startsWith("history_") && it.value is String }
                entries.filter { it.value == key }.forEach { editor.remove(it.key) }
                entries.filter { it.value != key }
                    .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
                    .drop(49).forEach { editor.remove(it.key) }
                editor.putString("last_uri", key)
                    .putString("history_$now", key)
                    .putString("name_${uri}", displayName(uri)).apply()
            } catch (_: Exception) {}
        }
    }

    private fun saveCurrentProgress() {
        if (!::player.isInitialized) return
        val uri = currentUri ?: return
        val duration = player.duration
        val position = max(0L, player.currentPosition)
        // A video that is (almost) finished should restart from the beginning next time.
        val toSave = if (duration > 0 && duration != C.TIME_UNSET && position >= duration - 5000L) 0L else position
        historyPrefs.edit().putLong("pos_${uri}", toSave)
            .putString("name_${uri}", displayName(uri)).putString("last_uri", uri.toString()).apply()
    }

    private val nameCache = java.util.concurrent.ConcurrentHashMap<String, String>()

    private fun displayName(uri: Uri): String = nameCache.getOrPut(uri.toString()) {
        var name = uri.lastPathSegment ?: "Video"
        try { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (_: Exception) { }
        name
    }

    private fun subtitleExtension(uri: Uri): String =
        uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase(Locale.ROOT) ?: ""

    private fun isCustomSubtitle(uri: Uri): Boolean =
        subtitleExtension(uri) == "srt" || subtitleExtension(uri) == "vtt"

    private fun buildVideoItem(video: Uri, subtitle: Uri): MediaItem {
        if (isCustomSubtitle(subtitle)) return MediaItem.fromUri(video)
        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(subtitle)
            .setMimeType(when (subtitleExtension(subtitle)) {
                "srt" -> MimeTypes.APPLICATION_SUBRIP
                "vtt" -> MimeTypes.TEXT_VTT
                "ssa", "ass" -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            })
            .setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        return MediaItem.Builder().setUri(video).setSubtitleConfigurations(listOf(subtitleConfig)).build()
    }

    private fun applySubtitleStyle() {
        playerView.subtitleView?.apply {
            setFractionalTextSize(subtitleSize)
            setBottomPaddingFraction(subtitleBottom)
        }
        if (::externalSubtitleView.isInitialized) {
            externalSubtitleView.textSize = (subtitleSize * 100f * 0.34f).coerceIn(14f, 34f)
            (externalSubtitleView.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
                lp.bottomMargin = dp((82 + subtitleBottom * 260f).roundToInt())
                externalSubtitleView.layoutParams = lp
            }
        }
    }

    private fun attachSubtitle(uri: Uri) {
        val video = currentUri
        if (video == null) { Toast.makeText(this, "Open a video first", Toast.LENGTH_SHORT).show(); return }
        subtitleUri = uri
        historyPrefs.edit().putString("subtitle_${video}", uri.toString()).apply()
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        externalSubtitleCues = emptyList()
        externalSubtitleView.text = ""
        externalSubtitleView.visibility = View.GONE
        if (player.mediaItemCount > 1) {
            // Keep the folder queue (next / previous) and swap only the current video's item.
            val items = (0 until player.mediaItemCount).map { player.getMediaItemAt(it) }.toMutableList()
            val at = player.currentMediaItemIndex
            items[at] = buildVideoItem(video, uri)
            player.setMediaItems(items, at, pos)
        } else {
            player.setMediaItem(buildVideoItem(video, uri))
        }
        applySubtitleStyle()
        player.prepare(); player.seekTo(pos); player.playWhenReady = wasPlaying
        if (isCustomSubtitle(uri)) loadExternalSubtitle(uri)
        Toast.makeText(this, "Subtitle loaded", Toast.LENGTH_SHORT).show()
    }

    private fun loadExternalSubtitle(uri: Uri) {
        val requestUri = uri.toString()
        subtitleExecutor.execute {
            try {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("Unable to read subtitle")
                var text = String(bytes, Charsets.UTF_8)
                // Not valid UTF-8 (older Windows subtitle files): decode as Windows-1252 instead.
                if (text.indexOf('\uFFFD') >= 0) text = String(bytes, charset("windows-1252"))
                val cues = parseSubtitle(text.removePrefix("\uFEFF"), subtitleExtension(uri))
                handler.post {
                    if (currentUri != null && historyPrefs.getString("subtitle_${currentUri}", null) == requestUri) {
                        externalSubtitleCues = cues
                        applySubtitleStyle()
                        updateExternalSubtitle()
                    }
                }
            } catch (_: Exception) {
                handler.post { Toast.makeText(this, "Could not read subtitle file", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun parseSubtitle(source: String, extension: String): List<SubtitleCue> {
        val normalized = source.replace("\r\n", "\n").replace('\r', '\n')
        if (extension == "vtt") return parseVtt(normalized)
        return parseSrt(normalized)
    }

    private fun parseSrt(source: String): List<SubtitleCue> {
        return source.split(Regex("\\n\\s*\\n")).mapNotNull { block ->
            val lines = block.lines().filter { it.isNotBlank() }
            if (lines.size < 2) return@mapNotNull null
            val timingIndex = lines.indexOfFirst { it.contains(" --> ") }
            if (timingIndex < 0 || timingIndex + 1 >= lines.size) return@mapNotNull null
            val parts = lines[timingIndex].split(" --> ")
            if (parts.size != 2) return@mapNotNull null
            val start = parseSubtitleTime(parts[0]) ?: return@mapNotNull null
            val end = parseSubtitleTime(parts[1].split(' ').first()) ?: return@mapNotNull null
            val body = lines.drop(timingIndex + 1).joinToString("\n").trim()
            if (body.isBlank()) null else SubtitleCue(start, end, body)
        }.sortedBy { it.startMs }
    }

    private fun parseVtt(source: String): List<SubtitleCue> {
        return source.lines().dropWhile { !it.contains("WEBVTT", ignoreCase = true) }.drop(1)
            .joinToString("\n").split(Regex("\\n\\s*\\n")).mapNotNull { block ->
                val lines = block.lines().filter { it.isNotBlank() }
                val timingIndex = lines.indexOfFirst { it.contains(" --> ") }
                if (timingIndex < 0 || timingIndex + 1 >= lines.size) return@mapNotNull null
                val parts = lines[timingIndex].split(" --> ")
                if (parts.size != 2) return@mapNotNull null
                val start = parseSubtitleTime(parts[0]) ?: return@mapNotNull null
                val end = parseSubtitleTime(parts[1].trim().split(' ').first()) ?: return@mapNotNull null
                val body = lines.drop(timingIndex + 1).joinToString("\n").trim()
                if (body.isBlank()) null else SubtitleCue(start, end, body)
            }.sortedBy { it.startMs }
    }

    private fun parseSubtitleTime(value: String): Long? {
        val cleaned = value.trim().replace(',', '.')
        val parts = cleaned.split(':')
        return try {
            val seconds = when (parts.size) {
                3 -> parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toDouble()
                2 -> parts[0].toLong() * 60 + parts[1].toDouble()
                else -> return null
            }
            (seconds * 1000.0).roundToInt().toLong()
        } catch (_: Exception) { null }
    }

    private fun updateExternalSubtitle() {
        if (!::externalSubtitleView.isInitialized || externalSubtitleCues.isEmpty() || !::player.isInitialized) return
        val adjustedPosition = player.currentPosition - subtitleSyncMs
        var low = 0
        var high = externalSubtitleCues.lastIndex
        var candidate = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (externalSubtitleCues[mid].startMs <= adjustedPosition) {
                candidate = mid
                low = mid + 1
            } else high = mid - 1
        }
        val cue = if (candidate >= 0) externalSubtitleCues[candidate] else null
        if (cue != null && adjustedPosition <= cue.endMs) {
            if (!android.text.TextUtils.equals(externalSubtitleView.text, cue.text)) externalSubtitleView.text = cue.text
            externalSubtitleView.visibility = View.VISIBLE
        } else {
            externalSubtitleView.visibility = View.GONE
        }
    }

    private fun showSubtitleSyncDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        val valueLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(8)) }
        val bar = SeekBar(this).apply { max = 10000; progress = subtitleSyncMs + 5000 }
        fun updateLabel() {
            subtitleSyncMs = (bar.progress - 5000).coerceIn(-5000, 5000)
            valueLabel.text = if (subtitleSyncMs == 0) "No delay" else if (subtitleSyncMs > 0) "+${subtitleSyncMs} ms" else "${subtitleSyncMs} ms"
            historyPrefs.edit().putInt("subtitle_sync_ms", subtitleSyncMs).apply()
            updateExternalSubtitle()
        }
        box.addView(valueLabel); box.addView(bar)
        updateLabel()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) updateLabel() }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        AlertDialog.Builder(this).setTitle("Subtitle synchronization").setMessage("Positive values delay subtitles; negative values make them appear earlier.")
            .setView(box).setPositiveButton("Done", null).setNeutralButton("Reset") { _, _ -> subtitleSyncMs = 0; historyPrefs.edit().putInt("subtitle_sync_ms", 0).apply(); updateExternalSubtitle() }.show()
    }

    private fun createProfessionalSeekTrack(): LayerDrawable {
        val track = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(2).toFloat()
            setColor(0x4DFFFFFF)
        }
        val progress = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(2).toFloat()
            setColor(0xFF6BAAFF.toInt())
        }
        val clipped = ClipDrawable(progress, Gravity.START, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf(track, clipped)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
            val trackPx = (3.5f * resources.displayMetrics.density).roundToInt()   // MX track is about 3.5dp
            setLayerHeight(0, trackPx)
            setLayerHeight(1, trackPx)
            setLayerGravity(0, Gravity.CENTER_VERTICAL)
            setLayerGravity(1, Gravity.CENTER_VERTICAL)
        }
    }

    /** Small solid dot with no halo; the insets only keep the thumb footprint and track alignment unchanged. */
    private fun createSeekThumb(): android.graphics.drawable.Drawable {
        // One solid, fully opaque 15 dp circle. The insets keep the old 28 dp footprint so the thumb stays aligned with the
        // track ends, but there is no translucent halo layer (pressed or not) around or over the circle any more.
        val core = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xFF6BAAFF.toInt())
            setSize(dp(15), dp(15))
        }
        return android.graphics.drawable.InsetDrawable(core, dp(6), dp(6), dp(7), dp(7))
    }

    private var fitHintHider: Runnable? = null

    private fun applyFitMode(mode: Int) {
        fitMode = mode
        playerView.resizeMode = fitModes[fitMode]
        zoomScale = 1f; panX = 0f; panY = 0f; applyZoom()
        historyPrefs.edit().putInt("fit_mode", fitMode).apply()
        fitButton.contentDescription = "Screen fit: ${fitModeNames[fitMode]}"
        setButtonActive(fitButton, fitMode != 0)
    }

    /** Tap on the screen-fit button: Fit, Stretch, Crop/Zoom, Fit with black bars, then Fit again. */
    private fun cycleFitMode() {
        applyFitMode((fitMode + 1) % fitModes.size)
        showGestureHint(fitModeNames[fitMode])
        fitHintHider?.let { handler.removeCallbacks(it) }
        fitHintHider = Runnable { gestureHint.visibility = View.GONE }
        handler.postDelayed(fitHintHider!!, 1000L)
        showControlsTemporarily()
    }

    private fun showFitOptions() {
        val labels = fitModeNames.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Screen fit")
            .setSingleChoiceItems(labels, fitMode) { dialog, which ->
                applyFitMode(which)
                dialog.dismiss()
                showControlsTemporarily()
            }
            .setNeutralButton(if (horizontalFlip) "Horizontal flip: ON" else "Horizontal flip: OFF") { _, _ ->
                horizontalFlip = !horizontalFlip
                historyPrefs.edit().putBoolean("horizontal_flip", horizontalFlip).apply()
                applyZoom()
                showControlsTemporarily()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showMoreDialog() {
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        var menuDialog: AlertDialog? = null
        fun section(title: String) {
            val v = TextView(this).apply {
                text = title.uppercase(Locale.getDefault())
                textSize = 12f
                letterSpacing = 0.08f
                setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
                setTextColor(0xFF8AB4F8.toInt())
                setPadding(dp(12), dp(16), dp(12), dp(6))
            }
            content.addView(v)
        }
        // "Title · Value" is shown as the title on the left and the current value on the right.
        fun action(title: String, onClick: () -> Unit) {
            val parts = title.split(" · ", limit = 2)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = roundedBackground(0xFF262626.toInt(), 12)
                isClickable = true
                isFocusable = true
                setOnClickListener { menuDialog?.dismiss(); onClick() }
            }
            row.addView(TextView(this).apply {
                text = parts[0]
                textSize = 15f
                setTextColor(Color.WHITE)
                setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            }, LinearLayout.LayoutParams(0, -2, 1f))
            if (parts.size > 1) {
                row.addView(TextView(this).apply {
                    text = parts[1]
                    textSize = 14f
                    setTextColor(0xFF8AB4F8.toInt())
                    gravity = Gravity.END
                }, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) })
            }
            content.addView(row, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(6) })
        }

        section("Playback")
        action("Playback history") { showHistoryDialog() }
        action("Seek amount · ${seekSeconds} sec") { showSeekAmountDialog() }
        action("Gesture sensitivity · ${gestureSensitivity}×") { showGestureSensitivityDialog() }
        action("Fast seeking · ${if (fastSeekEnabled) "On" else "Off"}") { showFastSeekDialog() }
        action("Earphone controls · ${if (earphoneControlsEnabled) "On" else "Off"}") { showEarphoneControlsDialog() }
        action("Repeat · ${repeatName()}") { showRepeatDialog() }
        action("Video information") { showVideoInfo() }

        section("Display & audio")
        action("Subtitle appearance") { showSubtitleAppearanceDialog() }
        action("Subtitle synchronization · ${if (subtitleSyncMs > 0) "+" else ""}${subtitleSyncMs} ms") { showSubtitleSyncDialog() }
        action("Load subtitle file") { pickSubtitle.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "application/octet-stream")) }
        action("Volume boost · ${volumePercent}%") { showVolumeDialog() }
        action("Haptic feedback · ${if (hapticsEnabled) "On" else "Off"}") { showHapticsDialog() }
        action("Automatic picture-in-picture · ${if (autoPictureInPicture) "On" else "Off"}") {
            autoPictureInPicture = !autoPictureInPicture
            historyPrefs.edit().putBoolean("auto_pip", autoPictureInPicture).apply()
            updatePictureInPictureParamsForAutoEntry()
            Toast.makeText(this, "Automatic picture-in-picture ${if (autoPictureInPicture) "on" else "off"}", Toast.LENGTH_SHORT).show()
        }

        section("Library")
        action("Delete playback history") { confirmDeleteHistory() }
        action("Clear saved resume positions") { confirmClearResumePositions() }
        action("Choose video folder") { pickFolder.launch(null) }
        action("Videos in saved folder") { showFolderVideos() }

        scroll.addView(content)
        val dialog = AlertDialog.Builder(this).setTitle("Alvi Player").setView(scroll).setNegativeButton("Close", null).create()
        menuDialog = dialog
        dialog.window?.setBackgroundDrawable(roundedBackground(0xFF1B1B1B.toInt(), 18))
        dialog.show()
    }

    /**
     * Media session for the on-screen player: headset / Bluetooth / car play-pause-next-previous buttons and the
     * system media controls drive this player directly, in the app, in PiP and with the screen off.
     */
    private var screenSession: MediaSession? = null

    private var earphoneControls: EarphoneControls? = null

    private fun releaseScreenSession() {
        earphoneControls?.release()
        earphoneControls = null
        try { screenSession?.release() } catch (_: Exception) {}
        screenSession = null
    }

    private fun createScreenSession() {
        releaseScreenSession()
        try {
            val open = PendingIntent.getActivity(
                this, 9104,
                Intent(this, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // Earphone buttons: 1 press play/pause, 2 next, 3 previous; next/previous/rewind/fast-forward keys too.
            val controls = EarphoneControls(
                player = { if (::player.isInitialized) player else null },
                seekAmountMs = { seekSeconds * 1000L },
                enabled = { earphoneControlsEnabled }
            )
            earphoneControls = controls
            // The id must differ from the background service's session (it uses the default id).
            screenSession = MediaSession.Builder(this, ScreenSessionPlayer(player))
                .setId("alvi_screen")
                .setSessionActivity(open)
                .setCallback(controls)
                .build()
        } catch (_: Exception) {
            // Without a session the on-screen buttons and notification still work; only headset buttons are lost.
        }
        // The notification points at the session: rebuild it on the next sync (e.g. after a decoder switch).
        lastNotificationPlaying = null
    }

    private fun buildPlayer() {
        val factory = AlviRenderersFactory(this, decoderMode, autoSkipMode)
        releaseScreenSession()
        if (::player.isInitialized) {
            try { player.release() } catch (_: Exception) {}
        }
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        player = ExoPlayer.Builder(this, factory)
            .setLoadControl(DefaultLoadControl.Builder()
            // Performance first: buffer 2 to 5 minutes ahead and restart almost at once after seeks (smoother 2x lecture playback, no stalls).
            .setBufferDurationsMs(120_000, 300_000, 200, 800)
            // Keep 2 minutes already played so skipping back needs no re-read or re-decode wait.
            .setBackBuffer(120_000, true)
            // Buffers may grow large, but are capped at 256 MB so a very high-bitrate video cannot run the app out of memory.
            .setTargetBufferBytes(256 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build())
            .setSkipSilenceEnabled(autoSkipMode > 0)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.repeatMode = repeatMode
        player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
        playerView.player = player
        playerView.useController = false
        createScreenSession()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val transitionedUri = mediaItem?.localConfiguration?.uri
                if (transitionedUri != null) {
                    currentUri = transitionedUri
                    lastVideoTitle = displayName(transitionedUri)
                    if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) loadCropFor(transitionedUri)   // each video keeps its own crop
                    if (orientationDecidedFor != transitionedUri.toString()) decideOrientation(transitionedUri)
                    historyPrefs.edit().putString("last_uri", transitionedUri.toString()).putString("name_$transitionedUri", lastVideoTitle).apply()
                    val saved = historyPrefs.getLong("pos_$transitionedUri", 0L)
                    if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && saved > 0L && player.currentPosition < 1500L) player.seekTo(saved)
                    val savedSubtitle = historyPrefs.getString("subtitle_$transitionedUri", null)?.let(Uri::parse)
                    subtitleUri = savedSubtitle
                    externalSubtitleCues = emptyList()
                    externalSubtitleView.visibility = View.GONE
                    if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
                }
                lastShownPosSec = -2L; lastShownRemSec = -2L; lastShownEtaKey = -2L
                applySubtitleStyle(); updateUi(); updateTitle()
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                updateLoudness()
            }
            override fun onPlaybackParametersChanged(playbackParameters: androidx.media3.common.PlaybackParameters) {
                // Recalculate the remaining time the moment the speed changes (any speed, including below 2x).
                updateUi()
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                syncPlaybackNotification()
                updatePictureInPictureParamsForAutoEntry()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updateScreenAwake(isPlaying)
                updateUi()
                updatePictureInPictureParamsForAutoEntry()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) playbackReady = true
                updateUi()
                updatePictureInPictureParamsForAutoEntry()
                if (playbackState == Player.STATE_ENDED && !player.hasNextMediaItem()) {
                    saveCurrentProgress()
                    setControlsVisible(true)
                }
            }
            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                updatePictureInPictureParamsForAutoEntry()
                if (cropRect != null) applyZoom()
                val shown = currentUri
                if (shown != null && videoSize.width > 0 && videoSize.height > 0 && orientationDecidedFor != shown.toString()) {
                    val turned = videoSize.unappliedRotationDegrees % 180 != 0
                    val shownWidth = if (turned) videoSize.height else videoSize.width
                    val shownHeight = if (turned) videoSize.width else videoSize.height
                    applyVideoOrientation(shown, shownHeight > shownWidth)
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                if (error is androidx.media3.exoplayer.ExoPlaybackException && error.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && decoderMode == 1) {
                    try {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
                        player.prepare(); player.playWhenReady = true
                        Toast.makeText(this@MainActivity, "Unsupported audio codec; retrying video without audio", Toast.LENGTH_LONG).show()
                        return
                    } catch (_: Exception) {}
                }
                if (error is androidx.media3.exoplayer.ExoPlaybackException && error.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && decoderMode == 0) {
                    Toast.makeText(this@MainActivity, "Hardware decoder failed; switching to HW+", Toast.LENGTH_LONG).show()
                    handler.post { if (!isFinishing && !isDestroyed) switchDecoder(1) }
                    return
                }
                val failedOpened = player.currentMediaItem?.localConfiguration?.uri
                if (failedOpened != null && failedOpened == openedAnchorUri && !playbackReady) {
                    // The opened video itself cannot be read (often a one-time file-manager permission that expired after the app closed).
                    val alias = historyPrefs.getString("alias_$failedOpened", null)?.let(Uri::parse)
                    if (alias != null && alias != failedOpened && hasVideoAccess() && aliasRetried.add(failedOpened.toString())) {
                        historyPrefs.edit().putLong("pos_$alias", historyPrefs.getLong("pos_$failedOpened", 0L)).apply()
                        handler.post { if (!isFinishing && !isDestroyed) openVideo(alias, true) }
                        return
                    }
                    Toast.makeText(this@MainActivity, "Could not open that video. Choose another one.", Toast.LENGTH_LONG).show()
                    handler.post { if (!isFinishing && !isDestroyed) showHomePanel(failedOpened) }
                    return
                }
                // A neighbour in the folder queue that cannot be opened (deleted file, stale entry, half-downloaded): skip it.
                val failedUri = player.currentMediaItem?.localConfiguration?.uri
                if (player.mediaItemCount > 1 && failedUri != null && failedUri != openedAnchorUri) {
                    player.removeMediaItem(player.currentMediaItemIndex)
                    queuedFolderUris = queuedFolderUris.filter { it != failedUri }
                    player.prepare(); player.playWhenReady = true
                    Toast.makeText(this@MainActivity, "Skipped a video that could not be played", Toast.LENGTH_SHORT).show()
                    return
                }
                Toast.makeText(this@MainActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun switchDecoder(mode: Int) {
        if (decoderMode == mode) return
        decoderMode = mode
        historyPrefs.edit().putInt("decoder_mode", mode).apply()
        rebuildPlayerKeepingState()
    }

    /** Rebuilds the player (new decoder or silence mode) and restores playlist, position, speed, volume and subtitles. */
    private fun rebuildPlayerKeepingState() {
        saveCurrentProgress()
        val uri = currentUri
        val pos = if (::player.isInitialized) player.currentPosition else 0L
        val playing = ::player.isInitialized && player.playWhenReady
        val items = if (::player.isInitialized) (0 until player.mediaItemCount).map { player.getMediaItemAt(it) } else emptyList()
        val index = if (::player.isInitialized) player.currentMediaItemIndex else 0
        buildPlayer()
        syncVolumeFromSystem(keepBoost = true)
        handler.postDelayed({ if (::player.isInitialized) updateLoudness() }, 350L)   // a boost needs the new audio session
        if (uri != null) {
            val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
            subtitleUri = savedSubtitle
            externalSubtitleCues = emptyList()
            externalSubtitleView.visibility = View.GONE
            if (items.size > 1) {
                player.setMediaItems(items, index.coerceIn(0, items.lastIndex), pos)
            } else {
                player.setMediaItem(if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri))
                player.seekTo(pos)
            }
            player.prepare(); player.setPlaybackSpeed(selectedSpeed); player.playWhenReady = playing
            if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
        }
        showControlsTemporarily()
    }

    private fun decoderName() = when (decoderMode) { 0 -> "HW"; 1 -> "HW+"; else -> "SW" }

    private fun showDecoderDialog() {
        val labels = arrayOf(
            "HW — hardware decoder only",
            "HW+ — hardware with decoder fallback",
            "SW — software preferred"
        )
        AlertDialog.Builder(this).setTitle("Decoder")
            .setSingleChoiceItems(labels, decoderMode) { dialog, which ->
                switchDecoder(which); dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showOrientationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Orientation")
            .setMessage("Landscape mode only. The phone can automatically rotate between Landscape and Landscape Right. Tap the orientation button to switch the landscape side manually.")
            .setPositiveButton("OK", null)
            .show()
    }

    /** Portrait videos open in portrait, landscape videos in sensor-driven landscape. The rotate button still overrides it afterwards. */
    private fun decideOrientation(uri: Uri) {
        if (orientationRequestedFor == uri.toString()) return
        orientationRequestedFor = uri.toString()
        val hint = historyPrefs.getInt("orient_$uri", -1)
        if (hint >= 0) { applyVideoOrientation(uri, hint == 1); return }
        // First time: read the size from the file's header (fast); onVideoSizeChanged is the fallback.
        ioExecutor.execute {
            try {
                val retriever = android.media.MediaMetadataRetriever()
                try {
                    retriever.setDataSource(this, uri)
                    val w = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    val h = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    val rotation = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (w > 0 && h > 0) {
                        val portrait = if (rotation % 180 != 0) w > h else h > w
                        handler.post { if (!isFinishing && !isDestroyed) applyVideoOrientation(uri, portrait) }
                    }
                } finally {
                    retriever.release()
                }
            } catch (_: Exception) { }
        }
    }

    private fun applyVideoOrientation(uri: Uri, portrait: Boolean) {
        historyPrefs.edit().putInt("orient_$uri", if (portrait) 1 else 0).apply()
        if (currentUri != uri) return
        orientationDecidedFor = uri.toString()
        if (portrait) {
            if (orientationMode == 2) return
            landscapeOrientationListener?.disable()
            orientationMode = 2
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            if (orientationMode == 1) return
            orientationMode = 1
            enableLandscapeAutoRotation()
        }
        updateButtonStates()
    }

    private fun toggleOrientation() {
        // Button toggles Portrait <-> sensor-driven Landscape. In portrait mode,
        // stop the landscape sensor so it cannot immediately force the player back.
        if (orientationMode == 1) {
            landscapeOrientationListener?.disable()
            orientationMode = 2
            historyPrefs.edit().putInt("orientation_mode", 2).apply()
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            Toast.makeText(this, "Portrait", Toast.LENGTH_SHORT).show()
        } else {
            orientationMode = 1
            historyPrefs.edit().putInt("orientation_mode", 1).apply()
            enableLandscapeAutoRotation()
            Toast.makeText(this, "Auto Landscape", Toast.LENGTH_SHORT).show()
        }
        updateButtonStates()
        haptic()
    }

    private fun applyOrientationMode() {
        orientationMode = historyPrefs.getInt("orientation_mode", 1).coerceIn(1, 2)
        // Start in the shape of the last video (portrait video => portrait) so the screen does not flip after it opens.
        val lastVideo = historyPrefs.getString("last_uri", null)
        if (lastVideo != null && historyPrefs.getInt("orient_${Uri.parse(lastVideo)}", -1) == 1) orientationMode = 2
        else if (lastVideo != null && historyPrefs.getInt("orient_${Uri.parse(lastVideo)}", -1) == 0) orientationMode = 1
        if (orientationMode == 2) {
            landscapeOrientationListener?.disable()
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            enableLandscapeAutoRotation()
        }
    }

    private fun showHapticsDialog() {
        hapticsEnabled = !hapticsEnabled
        historyPrefs.edit().putBoolean("haptics", hapticsEnabled).apply()
        Toast.makeText(this, "Haptic feedback ${if (hapticsEnabled) "on" else "off"}", Toast.LENGTH_SHORT).show()
    }

    private fun haptic() {
        if (hapticsEnabled) root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun resetZoom() { zoomScale = 1f; panX = 0f; panY = 0f; playerView.resizeMode = fitModes[fitMode]; applyZoom() }
    private fun applyZoom() {
        // Total picture transform = saved crop (base) combined with the pinch zoom and pan on top of it.
        val box = if (::player.isInitialized) cropBoxLocal() else null
        val (base, baseX, baseY) = if (box != null) cropBase(box) else NO_CROP
        val total = base * zoomScale
        playerView.scaleX = if (horizontalFlip) -total else total
        playerView.scaleY = total
        val maxPanX = root.width * (zoomScale - 1f) / 2f
        val maxPanY = root.height * (zoomScale - 1f) / 2f
        panX = panX.coerceIn(-maxPanX, maxPanX)
        panY = panY.coerceIn(-maxPanY, maxPanY)
        playerView.translationX = zoomScale * baseX + panX
        playerView.translationY = zoomScale * baseY + panY
        // Crop is a real cut: everything outside the box is hidden (black bars when the box and the screen differ in shape).
        // The clip is in the view's own coordinates, so it follows the crop zoom, the pinch zoom and pan, and the flip.
        if (box != null) {
            box.round(cropClipScratch)
            playerView.clipBounds = cropClipScratch
        } else {
            playerView.clipBounds = null
        }
    }

    /** The video picture inside the player view in Fit mode (the area the crop box is measured against). */
    private fun videoContentRect(): android.graphics.RectF? {
        if (!::player.isInitialized) return null
        val w = playerView.width.toFloat()
        val h = playerView.height.toFloat()
        val size = player.videoSize
        if (w <= 0f || h <= 0f || size.width <= 0 || size.height <= 0) return null
        var vw = size.width * size.pixelWidthHeightRatio
        var vh = size.height.toFloat()
        if (size.unappliedRotationDegrees % 180 != 0) { val t = vw; vw = vh; vh = t }
        val f = minOf(w / vw, h / vh)
        val cw = vw * f
        val ch = vh * f
        return android.graphics.RectF((w - cw) / 2f, (h - ch) / 2f, (w + cw) / 2f, (h + ch) / 2f)
    }

    /** Reused by every applyZoom() call, so a pinch on a cropped video allocates nothing per frame. */
    private val cropBoxScratch = android.graphics.RectF()
    private val cropClipScratch = android.graphics.Rect()

    /** The saved crop box in the player view's own coordinates (Fit mode only); null when there is no crop. */
    private fun cropBoxLocal(): android.graphics.RectF? {
        val crop = cropRect ?: return null
        if (fitMode != 0) return null
        val c = videoContentRect() ?: return null
        cropBoxScratch.set(
            c.left + crop[0] * c.width(), c.top + crop[1] * c.height(),
            c.left + crop[2] * c.width(), c.top + crop[3] * c.height()
        )
        return cropBoxScratch
    }

    /** Scale and shift that make the crop box fill the screen on its limiting side. */
    private fun cropBase(box: android.graphics.RectF): Triple<Float, Float, Float> {
        val w = playerView.width.toFloat()
        val h = playerView.height.toFloat()
        val x0 = box.left
        val x1 = box.right
        val y0 = box.top
        val y1 = box.bottom
        val s = minOf(w / (x1 - x0).coerceAtLeast(1f), h / (y1 - y0).coerceAtLeast(1f)).coerceIn(1f, 12f)
        val dx = s * ((x0 + x1) / 2f - w / 2f)
        val dy = s * ((y0 + y1) / 2f - h / 2f)
        return Triple(s, if (horizontalFlip) dx else -dx, -dy)
    }

    private val cropKeyCache = HashMap<String, String>()

    /** The same key for the same file however it was opened (file manager, picker or the folder queue): file name + size. */
    private fun cropKey(uri: Uri): String {
        cropKeyCache[uri.toString()]?.let { return it }
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    val size = if (c.isNull(1)) -1L else c.getLong(1)
                    if (name != null && size >= 0L) {
                        val key = "crop_${name}_$size"
                        cropKeyCache[uri.toString()] = key
                        return key
                    }
                }
            }
        } catch (_: Exception) { }
        return "crop_$uri"
    }

    /** Loads the crop saved for exactly this video (or none) and applies it. */
    private fun loadCropFor(uri: Uri?) {
        val saved = uri?.let { historyPrefs.getString(cropKey(it), null) ?: historyPrefs.getString("crop_$it", null) }
        val parts = saved?.split(",")?.mapNotNull { it.toFloatOrNull() }
        cropRect = if (parts != null && parts.size == 4) parts.toFloatArray() else null
        if (::player.isInitialized) applyZoom()
        updateCropButton()
    }

    private fun saveCropFor(uri: Uri?) {
        if (uri == null) return
        val crop = cropRect
        val e = historyPrefs.edit()
        if (crop == null) e.remove(cropKey(uri)).remove("crop_$uri") else e.putString(cropKey(uri), crop.joinToString(","))
        e.apply()
    }

    /** The round crop button is blue while the current video is cropped. */
    private fun updateCropButton() {
        if (::cropButton.isInitialized) setButtonActive(cropButton, cropRect != null)
    }

    private fun closeCropEditor() {
        cropEditor?.let { root.removeView(it) }
        cropEditor = null
        zoomScale = 1f; panX = 0f; panY = 0f
        applyZoom()
        showControlsTemporarily()
        updateCropButton()
    }

    /** Crop video: drag a box over the part of the picture to keep; the picture is then zoomed so that box fills the screen. */
    private fun startCropEditor() {
        if (!::player.isInitialized || player.videoSize.width <= 0) {
            Toast.makeText(this, "Start a video first", Toast.LENGTH_SHORT).show()
            return
        }
        if (cropEditor != null) return
        if (fitMode != 0) applyFitMode(0)
        cropBeforeEdit = cropRect
        cropRect = null
        zoomScale = 1f; panX = 0f; panY = 0f
        applyZoom()
        val bounds = videoContentRect() ?: return
        val saved = cropBeforeEdit
        val start = android.graphics.RectF()
        if (saved != null) {
            val l = if (horizontalFlip) 1f - saved[2] else saved[0]
            val r = if (horizontalFlip) 1f - saved[0] else saved[2]
            start.set(bounds.left + l * bounds.width(), bounds.top + saved[1] * bounds.height(), bounds.left + r * bounds.width(), bounds.top + saved[3] * bounds.height())
        } else {
            start.set(bounds.left + bounds.width() * 0.1f, bounds.top + bounds.height() * 0.1f, bounds.right - bounds.width() * 0.1f, bounds.bottom - bounds.height() * 0.1f)
        }
        val overlay = CropOverlayView(this, bounds, start)
        val editor = FrameLayout(this)
        editor.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        val hint = OutlinedTextView(this).apply {
            text = "Drag the box over the part to keep"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            outlinePx = 0.8f * resources.displayMetrics.density
        }
        editor.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(96) })
        fun makeCropButton(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 15f; setTextColor(0xFF8AB4F8.toInt()); gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
            background = GradientDrawable().apply { setColor(0xE6202124.toInt()); cornerRadius = dp(8).toFloat() }
            setOnClickListener { onClick() }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(makeCropButton("CANCEL") { cropRect = cropBeforeEdit; closeCropEditor() }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(10) })
            addView(makeCropButton("APPLY") {
                val r = overlay.rect
                var l = ((r.left - bounds.left) / bounds.width()).coerceIn(0f, 1f)
                var rt = ((r.right - bounds.left) / bounds.width()).coerceIn(0f, 1f)
                val t = ((r.top - bounds.top) / bounds.height()).coerceIn(0f, 1f)
                val b = ((r.bottom - bounds.top) / bounds.height()).coerceIn(0f, 1f)
                if (horizontalFlip) { val nl = 1f - rt; rt = 1f - l; l = nl }
                // A box that covers the whole picture means no crop.
                cropRect = if (l <= 0.01f && t <= 0.01f && rt >= 0.99f && b >= 0.99f) null else floatArrayOf(l, t, rt, b)
                saveCropFor(currentUri)
                closeCropEditor()
            }, LinearLayout.LayoutParams(-2, -2))
        }
        editor.addView(buttons, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(40) })
        root.addView(editor, FrameLayout.LayoutParams(-1, -1))
        cropEditor = editor
        setControlsVisible(false)
    }

    private fun clarityLevelName(level: Int) = when (level) { 1 -> "Light"; 2 -> "Balanced"; 3 -> "Strong"; else -> "Off" }


    private fun autoSkipIcon(): String = when (autoSkipMode) {
        1 -> "≋"
        2 -> "≋≋"
        else -> "≋"
    }

    private fun decoderShortLabel(): String = when (decoderMode) {
        0 -> "HW"
        1 -> "HW+"
        else -> "SW"
    }

    private fun showAutoSkipSilenceDialog() {
        val labels = arrayOf("Off", "Mild — keep natural pauses", "Strong — tighter podcast-style skipping")
        AlertDialog.Builder(this)
            .setTitle("Auto Skip Silence")
            .setSingleChoiceItems(labels, autoSkipMode) { dialog, which ->
                autoSkipMode = which
                autoSkipSilence = which > 0
                historyPrefs.edit().putInt("auto_skip_mode", autoSkipMode).putBoolean("auto_skip_silence", autoSkipSilence).apply()
                rebuildPlayerKeepingState()
                Toast.makeText(this, "Auto Skip Silence: ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun setVoiceClarityLevel(level: Int) {
        voiceClarityLevel = level.coerceIn(0, 3)
        VoiceClarityState.level = voiceClarityLevel
        historyPrefs.edit().putInt("voice_clarity_level", voiceClarityLevel).putBoolean("voice_clarity", voiceClarityLevel > 0).apply()
        updateButtonStates()
        Toast.makeText(this, "Voice Clarity: ${clarityLevelName(voiceClarityLevel)}", Toast.LENGTH_SHORT).show()
    }

    /** Tap on the toolbar button: Off → Light → Balanced → Strong → Off. */
    private fun cycleVoiceClarity() = setVoiceClarityLevel((voiceClarityLevel + 1) % 4)

    private fun showVoiceClarityDialog() {
        val labels = arrayOf(
            "Off",
            "Light — clearer voice, a bit louder",
            "Balanced — clear and loud, best for 2× lectures",
            "Strong — loudest and clearest (quiet, distant or noisy voices)"
        )
        AlertDialog.Builder(this)
            .setTitle("Voice Clarity")
            .setSingleChoiceItems(labels, voiceClarityLevel) { dialog, which ->
                setVoiceClarityLevel(which)
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun showVideoInfo() {
        val duration = if (::player.isInitialized) player.duration else C.TIME_UNSET
        val tracks = if (::player.isInitialized) player.currentTracks.groups.size else 0
        val vf = if (::player.isInitialized) player.videoFormat else null
        val af = if (::player.isInitialized) player.audioFormat else null
        val videoLine = vf?.let { "${it.width}×${it.height} · ${it.sampleMimeType ?: "unknown"}${it.frameRate.takeIf { r -> r > 0f }?.let { r -> " · ${String.format(Locale.getDefault(), "%.2f", r)} fps" } ?: ""}" } ?: "—"
        val audioLine = af?.let { "${it.sampleMimeType ?: "unknown"} · ${it.channelCount} ch · ${if (it.sampleRate > 0) "${it.sampleRate} Hz" else "sample rate n/a"}" } ?: "—"
        AlertDialog.Builder(this).setTitle(lastVideoTitle)
            .setMessage("Duration: ${formatMs(duration)}\nSpeed: ${speedLabel(selectedSpeed)}\nDecoder: ${decoderName()}\nVideo: $videoLine\nAudio: $audioLine\nTracks: $tracks\nFast seeking: ${if (fastSeekEnabled) "On" else "Off"}\nAuto skip silence: ${when (autoSkipMode) { 1 -> "Mild"; 2 -> "Strong"; else -> "Off" }}")
            .setPositiveButton("Close", null).show()
    }

    /** The Background Play setting (not whether the service is currently running). */
    private fun isBackgroundPlaybackActive(): Boolean =
        historyPrefs.getBoolean(KEY_BACKGROUND_ENABLED, false)

    private fun isBackgroundServiceRunning(): Boolean =
        historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)

    /**
     * Background Play is a setting. Switching it on or off never touches the video that is on screen.
     * Audio is handed to BackgroundPlaybackService only when the app leaves the foreground
     * (see handOffToBackgroundService) and is taken back when the app returns.
     */
    private fun toggleBackgroundPlayback() {
        val enable = !isBackgroundPlaybackActive()
        historyPrefs.edit().putBoolean(KEY_BACKGROUND_ENABLED, enable).apply()
        updatePictureInPictureParamsForAutoEntry()
        updateButtonStates()
        val xiaomi = Build.MANUFACTURER.equals("Xiaomi", true) || Build.MANUFACTURER.equals("POCO", true) || Build.MANUFACTURER.equals("Redmi", true)
        if (enable) requestBatteryExemptionOnce()
        Toast.makeText(
            this,
            when {
                !enable -> "Background play off"
                // MIUI's battery saver kills background audio unless the app is exempt.
                xiaomi -> "Background play on. If audio stops: Settings › Apps › Alvi Player › Battery saver › No restrictions, and turn Autostart on"
                else -> "Background play on · audio continues when you leave the app"
            },
            if (enable && xiaomi) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
        ).show()
    }

    /** Once: shows the system "always allow in background" prompt so background audio is not killed to save battery. */
    private fun requestBatteryExemptionOnce() {
        try {
            val power = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (power.isIgnoringBatteryOptimizations(packageName)) return
            if (historyPrefs.getBoolean("battery_exemption_asked", false)) return
            historyPrefs.edit().putBoolean("battery_exemption_asked", true).apply()
            startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (_: Exception) { }
    }

    private fun handoffPlaylist(current: Uri): List<Uri> =
        if (queuedFolderUris.contains(current)) queuedFolderUris else listOf(current)

    private fun handOffToBackgroundService() {
        if (!isBackgroundPlaybackActive() || isInPictureInPictureMode || isChangingConfigurations) return
        val uri = currentUri ?: return
        if (!::player.isInitialized || player.mediaItemCount == 0 || !player.playWhenReady) return
        val position = player.currentPosition.coerceAtLeast(0L)
        val intent = Intent(this, BackgroundPlaybackService::class.java).apply {
            putExtra(BackgroundPlaybackService.EXTRA_URI, uri.toString())
            putExtra(BackgroundPlaybackService.EXTRA_POSITION, position)
            putExtra(BackgroundPlaybackService.EXTRA_SPEED, selectedSpeed)
            putExtra(BackgroundPlaybackService.EXTRA_TITLE, displayName(uri))
            putExtra(BackgroundPlaybackService.EXTRA_REPEAT, repeatMode)
            putStringArrayListExtra(BackgroundPlaybackService.EXTRA_PLAYLIST, ArrayList(handoffPlaylist(uri).map { it.toString() }))
            putExtra(BackgroundPlaybackService.EXTRA_START_INDEX, handoffPlaylist(uri).indexOf(uri).coerceAtLeast(0))
            putExtra(BackgroundPlaybackService.EXTRA_DEFER_START, true)
        }
        try {
            if (notificationStarted) {
                stopService(Intent(this, PlaybackNotificationService::class.java))
                notificationStarted = false
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            resumeAfterHandoff = true
            saveCurrentProgress()
            // Seamless hand-off: this player keeps playing until the service player is ready, so there is no silent gap.
            handoffPending = true
            handoffPollCount = 0
            handler.removeCallbacks(handoffPollRunnable)
            handler.postDelayed(handoffPollRunnable, 80L)
        } catch (_: Exception) {
            // Could not start the service: keep playing in the activity instead of going silent.
        }
    }

    private var handoffPending = false
    private var handoffPollCount = 0
    private var reclaimWasPlaying = false
    private var reclaimPollCount = 0

    private fun stopBackgroundService() {
        try { stopService(Intent(this, BackgroundPlaybackService::class.java)) } catch (_: Exception) {}
        historyPrefs.edit().putBoolean(BackgroundPlaybackService.KEY_ACTIVE, false).apply()
    }

    private val handoffPollRunnable = object : Runnable {
        override fun run() {
            if (!handoffPending) return
            if (BackgroundPlaybackService.consumeStopRequest()) {
                // Stop was pressed in the notification before the hand-off finished: stop the screen player too.
                handoffPending = false; resumeAfterHandoff = false
                if (::player.isInitialized) player.pause()
                saveCurrentProgress()
                return
            }
            if (BackgroundPlaybackService.consumeUserControl()) {
                // Play/Pause was pressed in the notification before the hand-off finished: respect it. The screen
                // player stops, and the service continues (or stays paused) from this exact position.
                handoffPending = false; resumeAfterHandoff = false
                if (::player.isInitialized) {
                    val exact = player.currentPosition.coerceAtLeast(0L)
                    player.pause()
                    BackgroundPlaybackService.seekExact(exact)
                }
                return
            }
            if (!::player.isInitialized || !player.playWhenReady) {
                // The video was paused in the meantime: nothing to hand over.
                handoffPending = false; resumeAfterHandoff = false
                stopBackgroundService()
                return
            }
            if (BackgroundPlaybackService.isReady()) {
                handoffPending = false
                // Stop this player first, then let the service continue from exactly this spot: no overlap, no replay.
                val exact = player.currentPosition.coerceAtLeast(0L)
                if (resumeAfterHandoff) player.pause()
                BackgroundPlaybackService.resumeAt(exact)
                return
            }
            if (++handoffPollCount > 80) {
                // Service could not get ready (~8 s): keep playing here instead of risking silence.
                handoffPending = false; resumeAfterHandoff = false
                stopBackgroundService()
                return
            }
            handler.postDelayed(this, 100L)
        }
    }

    private var syncWasPlaying = false
    private var syncPollCount = 0

    /**
     * Returning to the app: the service keeps playing while this player loads. As soon as the picture
     * is ready, jump to the service's live position and start, so there is no silence and no replay.
     */
    private val syncFromServiceRunnable = object : Runnable {
        override fun run() {
            if (!::player.isInitialized) return
            val snap = BackgroundPlaybackService.snapshot()
            if (snap == null) {
                // Service is gone: just carry on here.
                if (syncWasPlaying) player.playWhenReady = true
                return
            }
            val ready = player.playbackState == Player.STATE_READY
            if (ready || ++syncPollCount > 100) {
                // Silence the service and read its exact position at this moment, then continue from exactly there
                // with an exact (not keyframe-snapped) seek, so nothing is played twice.
                val exact = BackgroundPlaybackService.pauseAndGetPosition() ?: snap.positionMs
                player.setSeekParameters(SeekParameters.EXACT)
                if (abs(player.currentPosition - exact) > 40L) player.seekTo(exact)
                handler.removeCallbacks(restoreSeekParametersRunnable)
                handler.postDelayed(restoreSeekParametersRunnable, 1500L)
                player.playWhenReady = syncWasPlaying
                reclaimWasPlaying = syncWasPlaying
                reclaimPollCount = 0
                updateUi()
                handler.removeCallbacks(stopServiceWhenReadyRunnable)
                handler.post(stopServiceWhenReadyRunnable)
            } else {
                handler.postDelayed(this, 60L)
            }
        }
    }

    /** Stops the service only once this player is audibly playing again, so returning to the app has no gap. */
    private val stopServiceWhenReadyRunnable = object : Runnable {
        override fun run() {
            val done = !reclaimWasPlaying || !::player.isInitialized || player.isPlaying || ++reclaimPollCount > 200
            if (done) stopBackgroundService() else handler.postDelayed(this, 50L)
        }
    }

    /** Takes playback back from the service when the user returns to the app. */
    private fun reclaimFromBackgroundService() {
        if (handoffPending) {
            // Came back before the hand-off finished: this player never stopped, just cancel it.
            handoffPending = false
            handler.removeCallbacks(handoffPollRunnable)
            resumeAfterHandoff = false
            stopBackgroundService()
            return
        }
        val stoppedUri = historyPrefs.getString(BackgroundPlaybackService.KEY_STOP_URI, null)
        if (stoppedUri != null) {
            // Stop was pressed in the background notification: come back paused, at the spot where audio stopped.
            val stoppedPos = historyPrefs.getLong(BackgroundPlaybackService.KEY_STOP_POS, 0L)
            historyPrefs.edit().remove(BackgroundPlaybackService.KEY_STOP_URI).remove(BackgroundPlaybackService.KEY_STOP_POS).apply()
            resumeAfterHandoff = false
            if (::player.isInitialized && player.mediaItemCount > 0) {
                val index = (0 until player.mediaItemCount).firstOrNull {
                    player.getMediaItemAt(it).localConfiguration?.uri?.toString() == stoppedUri
                }
                if (index != null) {
                    player.pause()
                    player.seekTo(index, stoppedPos)
                    updateUi()
                }
            }
            return
        }
        if (!isBackgroundServiceRunning()) { resumeAfterHandoff = false; return }
        val snap = BackgroundPlaybackService.snapshot()
        val wasPlaying = snap?.playing ?: resumeAfterHandoff
        resumeAfterHandoff = false
        if (!::player.isInitialized || player.mediaItemCount == 0) { stopBackgroundService(); return }
        if (snap != null) {
            val index = (0 until player.mediaItemCount).firstOrNull {
                player.getMediaItemAt(it).localConfiguration?.uri?.toString() == snap.uri
            }
            if (index != null) player.seekTo(index, snap.positionMs)
        }
        updateUi()
        if (wasPlaying) {
            // Wait for the picture, then join the service's live position (see syncFromServiceRunnable).
            player.playWhenReady = false
            syncWasPlaying = true
            syncPollCount = 0
            handler.removeCallbacks(syncFromServiceRunnable)
            handler.post(syncFromServiceRunnable)
        } else {
            reclaimWasPlaying = false
            reclaimPollCount = 0
            handler.removeCallbacks(stopServiceWhenReadyRunnable)
            handler.post(stopServiceWhenReadyRunnable)
        }
    }

    /** Aspect ratio plus a play/pause button on the PiP window. */
    private fun pipParamsBuilder(): PictureInPictureParams.Builder {
        val builder = PictureInPictureParams.Builder().setAspectRatio(pipAspect())
        if (Build.VERSION.SDK_INT >= 26 && ::player.isInitialized) {
            val playing = notificationPlayingState() ?: false
            val intent = Intent(ACTION_PIP_TOGGLE).setPackage(packageName)
            val pending = PendingIntent.getBroadcast(
                this, 7101, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val label = if (playing) "Pause" else "Play"
            val action = android.app.RemoteAction(
                android.graphics.drawable.Icon.createWithResource(this, if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                label, label, pending
            )
            builder.setActions(listOf(action))
        }
        return builder
    }

    private val pipReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_PIP_TOGGLE || !::player.isInitialized || player.mediaItemCount == 0) return
            // Same toggle as the notification: decided from playWhenReady (so it works while buffering) and replays when ended.
            togglePlaybackFromNotification()
            refreshPipActions()
        }
    }
    private var pipReceiverRegistered = false

    private fun registerPipReceiver() {
        if (pipReceiverRegistered) return
        try {
            androidx.core.content.ContextCompat.registerReceiver(
                this, pipReceiver, android.content.IntentFilter(ACTION_PIP_TOGGLE),
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
            pipReceiverRegistered = true
        } catch (_: Exception) {}
    }

    private fun unregisterPipReceiver() {
        if (!pipReceiverRegistered) return
        try { unregisterReceiver(pipReceiver) } catch (_: Exception) {}
        pipReceiverRegistered = false
    }

    /** PiP window ratio from the real video size (clamped to what Android accepts), 16:9 if unknown. */
    private fun pipAspect(): Rational {
        val size = if (::player.isInitialized) player.videoSize else androidx.media3.common.VideoSize.UNKNOWN
        val w = size.width
        val h = size.height
        if (w <= 0 || h <= 0) return Rational(16, 9)
        val ratio = w * size.pixelWidthHeightRatio / h
        if (ratio < 0.42f || ratio > 2.39f) return Rational(16, 9)
        return Rational((w * size.pixelWidthHeightRatio * 1000f).toInt().coerceAtLeast(1), h * 1000)
    }

    /** Keep Android 12+ auto-entry in sync with playback and the Background Play preference. */
    private var lastPipParamsKey: String? = null

    /** Re-draws the PiP window's play/pause button right now, bypassing the "nothing changed" shortcut. */
    private fun refreshPipActions() {
        lastPipParamsKey = null
        updatePictureInPictureParamsForAutoEntry()
    }

    private fun updatePictureInPictureParamsForAutoEntry() {
        if (Build.VERSION.SDK_INT < 26 || !::player.isInitialized) return
        try {
            val shouldAutoEnter = Build.VERSION.SDK_INT >= 31 && autoPictureInPicture &&
                !isBackgroundPlaybackActive() && player.mediaItemCount > 0
            // Skip identical updates: each call makes the system re-lay out the PiP window.
            val key = "$shouldAutoEnter|${notificationPlayingState()}|${pipAspect()}"
            if (key == lastPipParamsKey) return
            val params = pipParamsBuilder()
            if (Build.VERSION.SDK_INT >= 31) params.setAutoEnterEnabled(shouldAutoEnter)
            setPictureInPictureParams(params.build())
            lastPipParamsKey = key
        } catch (_: Exception) {
            // The onUserLeaveHint fallback below still supports devices that do not accept updates.
        }
    }

    private fun enterPip() {
        if (isBackgroundPlaybackActive()) {
            Toast.makeText(this, "Background play is active", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT < 26 || !::player.isInitialized || player.mediaItemCount == 0) {
            Toast.makeText(this, "Picture-in-picture is unavailable", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val builder = pipParamsBuilder()
            if (Build.VERSION.SDK_INT >= 31) {
                // Manual PiP is separate from automatic PiP; do not auto-enter while Background Play owns playback.
                builder.setAutoEnterEnabled(autoPictureInPicture && !isBackgroundPlaybackActive())
            }
            enterPictureInPictureMode(builder.build())
        } catch (_: Exception) {
            Toast.makeText(this, "Picture-in-picture is unavailable on this device", Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDeleteHistory() {
        AlertDialog.Builder(this).setTitle("Delete playback history?")
            .setMessage("This removes only the playback history list. Saved resume positions and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val editor = historyPrefs.edit()
                historyPrefs.all.keys.filter { it.startsWith("history_") || it.startsWith("name_") }.forEach { editor.remove(it) }
                editor.apply()
                Toast.makeText(this, "Playback history deleted", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun confirmClearResumePositions() {
        AlertDialog.Builder(this).setTitle("Clear saved resume positions?")
            .setMessage("This removes saved playback positions only. Playback history and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                historyPrefs.edit().apply {
                    historyPrefs.all.keys.filter { it.startsWith("pos_") }.forEach { remove(it) }
                    apply()
                }
                Toast.makeText(this, "Saved resume positions cleared", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showHistoryDialog() {
        val history = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }
            .distinctBy { it.toString() }
            .take(30)
        if (history.isEmpty()) {
            // Backward compatibility with older builds that stored name_<uri>.
            val legacy = historyPrefs.all.keys.filter { it.startsWith("name_") }.map { Uri.parse(it.removePrefix("name_")) }.distinct().take(30)
            if (legacy.isEmpty()) { Toast.makeText(this, "No playback history yet", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("Playback history").setItems(legacy.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(legacy[index], true) }.setNegativeButton("Close", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Playback history")
            .setItems(history.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(history[index], true) }
            .setNegativeButton("Close", null).show()
    }

    private fun showTrackDialog() {
        if (!::player.isInitialized) return
        val tracks = player.currentTracks.groups
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        for (group in tracks) {
            val type = group.type
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val typeName = if (type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                val language = format.language ?: "und"
                options.add("${if (group.isTrackSelected(i)) "✓  " else ""}$typeName · $language${if (format.label != null) " · ${format.label}" else ""}")
                actions.add {
                    val builder = player.trackSelectionParameters.buildUpon()
                    builder.setTrackTypeDisabled(type, false)
                    builder.setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(i)))
                    player.trackSelectionParameters = builder.build()
                }
            }
        }
        if (options.isEmpty()) { Toast.makeText(this, "No alternate audio or subtitle tracks in this video", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Available tracks").setItems(options.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNeutralButton("Disable subtitles") { _, _ -> player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }
            .setNegativeButton("Close", null).show()
    }

    private fun showAudioDelayDialog() {
        val values = intArrayOf(-500, -250, -100, 0, 100, 250, 500)
        val labels = values.map { if (it > 0) "+${it} ms" else "$it ms" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Audio delay")
            .setSingleChoiceItems(labels, values.indexOf(audioDelayMs).coerceAtLeast(0)) { dialog, which ->
                audioDelayMs = values[which]
                Toast.makeText(this, "Audio delay preference saved. Subtitle synchronization is available separately for external SRT/VTT subtitles.", Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showFolderVideos() {
        val folder = historyPrefs.getString("folder_uri", null)?.let(Uri::parse)
        if (folder == null) { Toast.makeText(this, "Choose a folder first", Toast.LENGTH_SHORT).show(); pickFolder.launch(null); return }
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, DocumentsContract.getTreeDocumentId(folder))
            val found = mutableListOf<Pair<String, Uri>>()
            contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0); val name = c.getString(1) ?: "Video"; val mime = c.getString(2) ?: ""
                    if (mime.startsWith("video/")) found.add(name to DocumentsContract.buildDocumentUriUsingTree(folder, id))
                }
            }
            if (found.isEmpty()) { Toast.makeText(this, "No videos found directly in this folder", Toast.LENGTH_LONG).show(); return }
            found.sortBy { it.first.lowercase(Locale.getDefault()) }
            val names = found.map { it.first }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Folder videos")
                .setItems(names) { _, index -> playFolder(found.map { it.second }, index) }
                .setNeutralButton("Play all") { _, _ -> playFolder(found.map { it.second }, 0) }
                .setNegativeButton("Close", null).show()
        } catch (_: Exception) { Toast.makeText(this, "Could not read this folder", Toast.LENGTH_SHORT).show() }
    }

    private fun playFolder(uris: List<Uri>, startIndex: Int) {
        if (uris.isEmpty()) return
        saveCurrentProgress()
        queuedFolderUris = uris
        val items = uris.map { uri ->
            val sub = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
            if (sub != null && !isCustomSubtitle(sub)) buildVideoItem(uri, sub) else MediaItem.fromUri(uri)
        }
        currentUri = uris[startIndex.coerceIn(0, uris.lastIndex)]
        lastVideoTitle = displayName(currentUri!!)
        externalSubtitleCues = emptyList()
        externalSubtitleView.visibility = View.GONE
        player.setMediaItems(items, startIndex.coerceIn(0, items.lastIndex), historyPrefs.getLong("pos_${currentUri}", 0L))
        player.prepare()
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        player.repeatMode = repeatMode
        historyPrefs.edit().putString("last_uri", currentUri.toString()).apply()
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateTitle(); updateUi()
    }

    private fun repeatName(): String = when (repeatMode) {
        Player.REPEAT_MODE_ONE -> "One"
        Player.REPEAT_MODE_ALL -> "All"
        else -> "Off"
    }

    private fun showRepeatDialog() {
        val labels = arrayOf("Off", "Repeat one", "Repeat all")
        val modes = intArrayOf(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ONE, Player.REPEAT_MODE_ALL)
        val checked = modes.indexOf(repeatMode).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Repeat")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                repeatMode = modes[which]
                historyPrefs.edit().putInt("repeat_mode", repeatMode).apply()
                if (::player.isInitialized) player.repeatMode = repeatMode
                haptic(); dialog.dismiss(); showControlsTemporarily()
            }.setNegativeButton("Close", null).show()
    }

    private fun showFastSeekDialog() {
        val labels = arrayOf("On — faster, nearby keyframe", "Off — exact seeking")
        AlertDialog.Builder(this).setTitle("Fast seeking")
            .setSingleChoiceItems(labels, if (fastSeekEnabled) 0 else 1) { dialog, which ->
                fastSeekEnabled = which == 0
                historyPrefs.edit().putBoolean("fast_seek", fastSeekEnabled).apply()
                if (::player.isInitialized) player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                Toast.makeText(this, if (fastSeekEnabled) "Fast seeking enabled" else "Exact seeking enabled", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun showEarphoneControlsDialog() {
        val labels = arrayOf(
            "On — 1 press play/pause, 2 next, 3 previous; hold next/previous to seek",
            "Off — system default buttons"
        )
        AlertDialog.Builder(this).setTitle("Earphone controls")
            .setSingleChoiceItems(labels, if (earphoneControlsEnabled) 0 else 1) { dialog, which ->
                earphoneControlsEnabled = which == 0
                historyPrefs.edit().putBoolean("earphone_controls", earphoneControlsEnabled).apply()
                Toast.makeText(this, if (earphoneControlsEnabled) "Earphone controls on" else "Earphone controls off", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun speedLabel(speed: Float) = if (speed % 1f == 0f) "${speed.toInt()}×" else "${speed}×"


    private fun showSpeedDialog() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        // MX-style: each value in its own dark glass box; the selected one gets a blue label.
        fun ashBox(selected: Boolean) = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(6).toFloat()
            setColor(if (selected) 0x99000000.toInt() else 0x73000000)
        }
        val selectedBlue = 0xFF4FC3F7.toInt()
        // Lowercase x like MX Player: 0.5x, 1.0x, 2.0x, 0.25x.
        fun dialogLabel(v: Float): String {
            val tenths = Math.round(v * 10f)
            return if (Math.abs(v * 10f - tenths) < 0.001f) String.format(java.util.Locale.US, "%.1fx", v)
            else String.format(java.util.Locale.US, "%.2fx", v)
        }
        fun chip(t: String, sp: Float) = OutlinedTextView(this).apply {
            text = t; textSize = sp; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.CENTER; setPadding(dp(11), dp(9), dp(11), dp(9))
            outlinePx = 0f
            isClickable = true; isFocusable = true
            background = ashBox(false)
        }
        fun stepButton(t: String) = chip(t, 22f)
        val minus = stepButton("−")
        val plus = stepButton("+")
        // Just the number (no title words), so the panel stays small and see-through.
        val readout = OutlinedTextView(this).apply {
            text = dialogLabel(selectedSpeed); textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(Typeface.create("sans-serif", Typeface.NORMAL))
            outlinePx = 0f
            setPadding(dp(18), dp(6), dp(18), dp(6))
            background = ashBox(false)
        }
        val compact = resources.configuration.screenWidthDp < 480
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(8))
        }
        if (compact) {
            // Portrait: [−] 2.1x [+] on top and every speed box in a row below, so nothing is pushed off a narrow screen.
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(minus, LinearLayout.LayoutParams(-2, -2))
                addView(readout, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8); rightMargin = dp(8) })
                addView(plus, LinearLayout.LayoutParams(-2, -2))
            }
            panel.addView(top, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(6); gravity = Gravity.CENTER_HORIZONTAL })
            panel.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        } else {
            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                addView(minus, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(4) })
                // The speed boxes take the space between − and + and scroll sideways if they do not fit.
                addView(scroll, LinearLayout.LayoutParams(0, -2, 1f))
                addView(plus, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(4) })
            }
            panel.addView(readout, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(6); gravity = Gravity.CENTER_HORIZONTAL })
            panel.addView(controls, LinearLayout.LayoutParams(-1, -2))
        }
        val dialog = AlertDialog.Builder(this).setView(panel).create()
        val boxes = ArrayList<Pair<Float, TextView>>()
        fun refreshBoxes() {
            boxes.forEach { (value, b) ->
                b.typeface = if (value == selectedSpeed) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.create("sans-serif", Typeface.NORMAL)
                b.background = ashBox(value == selectedSpeed)
                b.setTextColor(if (value == selectedSpeed) selectedBlue else Color.WHITE)
            }
        }
        fun setSpeedValue(value: Float) {
            selectedSpeed = value
            historyPrefs.edit().putFloat("selected_speed", selectedSpeed).apply()
            if (::player.isInitialized) player.setPlaybackSpeed(selectedSpeed)
            speedButton.text = speedBtnLabel(selectedSpeed)
            readout.text = dialogLabel(selectedSpeed)
            refreshBoxes(); updateUi(); showControlsTemporarily()
        }
        speeds.forEach { value ->
            val b = chip(dialogLabel(value), 14f)
            b.setPadding(dp(9), dp(8), dp(9), dp(8))
            boxes.add(value to b)
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            b.setOnClickListener { setSpeedValue(value); dialog.dismiss() }
        }
        // − / + move in 0.1 steps (0.25 steps to 0.2 or 0.3), limited to 0.1×–4.0×.
        minus.setOnClickListener {
            val tenths = kotlin.math.floor(selectedSpeed * 10.0 - 0.0001).toInt()
            setSpeedValue((tenths.coerceIn(1, 40)) / 10f)
        }
        plus.setOnClickListener {
            val tenths = kotlin.math.ceil(selectedSpeed * 10.0 + 0.0001).toInt()
            setSpeedValue((tenths.coerceIn(1, 40)) / 10f)
        }
        refreshBoxes()
        // Size the window to the panel itself (an AlertDialog would otherwise stretch to a minimum width).
        val unspecified = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        row.measure(unspecified, unspecified); minus.measure(unspecified, unspecified)
        plus.measure(unspecified, unspecified); readout.measure(unspecified, unspecified)
        val naturalWidth = if (compact) maxOf(row.measuredWidth, minus.measuredWidth + plus.measuredWidth + readout.measuredWidth + dp(16)) + dp(20)
            else row.measuredWidth + minus.measuredWidth + plus.measuredWidth + dp(8) + dp(20)
        val panelWidth = minOf(naturalWidth, (resources.displayMetrics.widthPixels * 0.92f).toInt())
        dialog.show()
        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setDimAmount(0f)
            setGravity(Gravity.CENTER)
            setLayout(panelWidth, android.view.ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    private val saveVolumeRunnable = Runnable { historyPrefs.edit().putInt("volume_percent", volumePercent).apply() }

    private var loudnessSessionId = 0

    /**
     * The LoudnessEnhancer carries the volume-gesture boost (above 100%).
     */
    private fun updateLoudness() {
        if (!::player.isInitialized) return
        val sessionId = player.audioSessionId
        val gestureDb = if (volumePercent > 100) 20.0 * kotlin.math.log10(volumePercent / 100.0) else 0.0
        val gainDb = gestureDb
        try {
            if (volumeBoostEnhancer != null && loudnessSessionId != sessionId) {
                volumeBoostEnhancer?.release(); volumeBoostEnhancer = null
            }
            if (gainDb <= 0.0 || sessionId == 0) {
                volumeBoostEnhancer?.release(); volumeBoostEnhancer = null
                loudnessSessionId = 0
                return
            }
            val enhancer = volumeBoostEnhancer ?: LoudnessEnhancer(sessionId).also { volumeBoostEnhancer = it; loudnessSessionId = sessionId }
            enhancer.setTargetGain((gainDb * 100).roundToInt())
            enhancer.enabled = true
        } catch (_: Exception) {
            try { volumeBoostEnhancer?.release() } catch (_: Exception) {}
            volumeBoostEnhancer = null
            loudnessSessionId = 0
        }
    }

    /**
     * Makes the app's volume follow the phone's media volume instead of pushing a saved level onto the phone.
     * Boost above 100% only exists while the phone's volume is at maximum, so it is kept only when [keepBoost] is true
     * (inside a session) and the phone is still at maximum; otherwise the app's level becomes the phone's level.
     */
    private fun syncVolumeFromSystem(keepBoost: Boolean) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            val maxVol = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val cur = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
            val systemPercent = (cur * 100f / maxVol).roundToInt().coerceIn(0, 100)
            if (!(keepBoost && volumePercent > 100 && systemPercent >= 100)) volumePercent = systemPercent
        } catch (_: Exception) { }
        if (::player.isInitialized) {
            player.volume = 1f   // the phone's media volume does the 0–100% work
            updateLoudness()
        }
    }

    private fun applyGestureVolume(percent: Int) {
        volumePercent = percent.coerceIn(0, 200)
        handler.removeCallbacks(saveVolumeRunnable)
        handler.postDelayed(saveVolumeRunnable, 400L)

        val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val maxVol = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)

        try {
            // 0–100% of the app maps directly to the phone's normal media-volume range.
            // App 100% therefore means the phone's media volume is exactly 100%.
            val systemPercent = volumePercent.coerceAtMost(100)
            val systemVolume = (maxVol * systemPercent / 100f).roundToInt().coerceIn(0, maxVol)
            audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, systemVolume, 0)

            updateLoudness()

            // System volume is the sole 0–100% control; keep the player at unity gain.
            player.volume = 1f
        } catch (_: Exception) {
            // Device restrictions fallback.
            player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
        }
    }

    private fun showSeekAmountDialog() {
        val values = intArrayOf(5, 10, 15, 20, 30)
        val labels = values.map { "$it seconds" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Double-tap seek amount")
            .setSingleChoiceItems(labels, values.indexOf(seekSeconds).coerceAtLeast(0)) { dialog, which ->
                seekSeconds = values[which]
                historyPrefs.edit().putInt("seek_seconds", seekSeconds).apply()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showGestureSensitivityDialog() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { "${it}×" }.toTypedArray()
        val selected = values.indexOfFirst { abs(it - gestureSensitivity) < 0.01f }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Gesture sensitivity")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                gestureSensitivity = values[which]
                historyPrefs.edit().putFloat("gesture_sensitivity", gestureSensitivity).apply()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSubtitleAppearanceDialog() {
        val sizes = floatArrayOf(0.04f, 0.0533f, 0.065f, 0.08f)
        val positions = floatArrayOf(0.03f, 0.08f, 0.14f, 0.22f)
        val labels = sizes.map { "${(it / 0.0533f * 100).roundToInt()}% size" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Subtitle size")
            .setSingleChoiceItems(labels, sizes.indexOfFirst { abs(it - subtitleSize) < 0.005f }.coerceAtLeast(0)) { dialog, which ->
                subtitleSize = sizes[which]
                historyPrefs.edit().putFloat("subtitle_size", subtitleSize).apply()
                applySubtitleStyle(); dialog.dismiss(); showSubtitlePositionDialog()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSubtitlePositionDialog() {
        val positions = floatArrayOf(0.03f, 0.08f, 0.14f, 0.22f)
        val labels = arrayOf("Near bottom", "Default", "Higher", "Much higher")
        AlertDialog.Builder(this).setTitle("Subtitle position")
            .setSingleChoiceItems(labels, positions.indexOfFirst { abs(it - subtitleBottom) < 0.01f }.coerceAtLeast(0)) { dialog, which ->
                subtitleBottom = positions[which]
                historyPrefs.edit().putFloat("subtitle_bottom", subtitleBottom).apply()
                applySubtitleStyle(); dialog.dismiss()
            }.setNegativeButton("Skip", null).show()
    }

    private fun showVolumeDialog() {
        syncVolumeFromSystem(keepBoost = true)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(8)) }
        val label = TextView(this).apply { text = "Volume: ${volumePercent}%"; setTextColor(Color.WHITE); textSize = 16f }
        val bar = SeekBar(this).apply { max = 200; progress = volumePercent }
        box.addView(label); box.addView(bar)
        val dialog = AlertDialog.Builder(this).setTitle("Amplified volume (up to 200%)").setView(box).setPositiveButton("Done", null).create()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                applyGestureVolume(progress)
                label.text = "Volume: ${volumePercent}%"
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        dialog.show()
    }

    private fun toggleVoiceClarity() = showVoiceClarityDialog()

    private val hideLevelRunnable = Runnable {
        if (!::brightnessPanel.isInitialized) return@Runnable
        listOf(brightnessPanel, volumePanel).forEach { v ->
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(200L).withEndAction { v.visibility = View.GONE }.start()
        }
    }

    private fun scheduleHideLevelIndicators(delayMs: Long) {
        handler.removeCallbacks(hideLevelRunnable)
        handler.postDelayed(hideLevelRunnable, delayMs)
    }

    /** Brightness shows on the left, volume on the right (the side you swipe). Volume above 100% turns the top part amber. */
    private fun showLevelIndicator(brightness: Boolean, percent: Int, fraction: Float) {
        val panel = if (brightness) brightnessPanel else volumePanel
        val other = if (brightness) volumePanel else brightnessPanel
        other.animate().cancel(); other.visibility = View.GONE
        if (brightness) {
            if (percent != lastBrightnessPct) { lastBrightnessPct = percent; brightnessPercent.text = "$percent%" }
        } else {
            if (percent != lastVolumePct) { lastVolumePct = percent; volumePercentText.text = "$percent%" }
        }
        (if (brightness) brightnessBar else volumeBar).setLevel(fraction, if (brightness) 1f else 0.5f)
        panel.animate().cancel(); panel.alpha = 1f; panel.visibility = View.VISIBLE
        handler.removeCallbacks(hideLevelRunnable) // stays while the finger is down; hidden shortly after release
    }

    private var hintCompact = false
    private var lastHintText: String? = null
    private var lastAppliedBrightness = -1f
    private var lastBrightnessPct = -1
    private var lastVolumePct = -1

    /** [compact] = small, see-through label (used for the speed readout so it does not cover the video). */
    private fun showGestureHint(text: String, compact: Boolean = false) {
        if (compact != hintCompact) {
            hintCompact = compact
            if (compact) {
                gestureHint.textSize = 13f
                gestureHint.setTextColor(0xCCFFFFFF.toInt())
                gestureHint.setPadding(dp(10), dp(3), dp(10), dp(3))
                gestureHint.background = roundedBackground(0x40000000, 14)
            } else {
                gestureHint.textSize = 22f
                gestureHint.setTextColor(Color.WHITE)
                gestureHint.setPadding(dp(22), dp(10), dp(22), dp(10))
                gestureHint.background = roundedBackground(0xB3000000.toInt(), 28)
            }
        }
        if (text != lastHintText) { lastHintText = text; gestureHint.text = text }   // no relayout when the text is unchanged
        gestureHint.visibility = View.VISIBLE
    }

    private fun toggleControls() = setControlsVisible(!controlsVisible)

    private fun speedBtnLabel(speed: Float) = speedLabel(speed).replace("×", "x")

    /** Icon/text button that renders itself through BtnState; icons are vector drawables. */
    private fun iconBtn(resId: Int, circle: Boolean, frac: Float = 0.5f): TextView = TextView(this).apply {
        text = ""
        setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        gravity = Gravity.CENTER
        includeFontPadding = false
        setPadding(0, 0, 0, 0)
        isClickable = true
        isFocusable = true
        stateListAnimator = null
        tag = BtnState(resId, false, circle, frac)
        renderButton(this)
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().cancel().also { v.alpha = 0.6f; v.scaleX = 0.92f; v.scaleY = 0.92f }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(110L).start()
            }
            false
        }
    }

    private fun renderButton(v: TextView) {
        val st = v.tag as? BtnState ?: return
        val circleOn = st.circle || st.active
        val circleColor = when {
            !circleOn -> 0
            st.color != 0 -> st.color
            st.active -> 0xFF6BAAFF.toInt()   // MX light blue, slightly deeper
            else -> 0xE6566569.toInt()        // MX translucent slate grey
        }
        if (st.res == 0) {
            v.setTextColor(Color.WHITE)
            val disc = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(circleColor)
            }
            // Same 0.44 radius as the icon circles (inset 6% per side) so the speed button matches the others.
            v.background = if (circleColor != 0) android.graphics.drawable.InsetDrawable(disc, 0.06f) else disc
        } else {
            v.background = IconDrawable(getDrawable(st.res)!!.mutate(), circleColor, st.frac, resources.displayMetrics.density, st.iconTint)
        }
    }

    private fun setIconRes(view: TextView, resId: Int) {
        val st = view.tag as? BtnState ?: return
        if (st.res == resId) return
        st.res = resId
        renderButton(view)
    }

    private fun setButtonActive(view: TextView, active: Boolean) {
        val st = view.tag as? BtnState ?: return
        if (st.active == active) return
        st.active = active
        renderButton(view)
    }

    private fun updateButtonStates() {
        if (::autoSkipButton.isInitialized) setButtonActive(autoSkipButton, autoSkipSilence)
        if (::speedButton.isInitialized) {
            val activeSpeed = if (temporarySpeedActive && ::player.isInitialized) player.playbackParameters.speed else selectedSpeed
            val label = speedBtnLabel(activeSpeed)
            if (label != lastSpeedLabel) { lastSpeedLabel = label; speedButton.text = label }
            setButtonActive(speedButton, activeSpeed != 1f)
        }
        if (::audioBoostButton.isInitialized) setButtonActive(audioBoostButton, voiceClarityEnabled)
        if (::orientationButton.isInitialized) setButtonActive(orientationButton, currentLandscapeOrientation == ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE)
        if (::fitButton.isInitialized) setButtonActive(fitButton, fitMode != 0)
        if (::backgroundButton.isInitialized) setButtonActive(backgroundButton, isBackgroundPlaybackActive())
        if (::pipButton.isInitialized) setButtonActive(pipButton, isInPictureInPictureMode)
    }

    private fun fadeTo(v: View, show: Boolean) {
        if (show) {
            v.animate().cancel()
            if (v.visibility != View.VISIBLE) { v.alpha = 0f; v.visibility = View.VISIBLE }
            v.animate().alpha(1f).setDuration(180L).setInterpolator(android.view.animation.DecelerateInterpolator()).withLayer().start()
        } else if (v.visibility == View.VISIBLE) {
            v.animate().cancel()
            v.animate().alpha(0f).setDuration(150L).setInterpolator(android.view.animation.AccelerateInterpolator()).withLayer()
                .withEndAction { if (v.alpha < 0.01f) v.visibility = View.GONE }.start()
        }
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible && !locked && !isInPictureInPictureMode
        if (player.mediaItemCount == 0) {
            topBar.visibility = View.VISIBLE
            topBar.alpha = 1f
            selectButton.visibility = View.VISIBLE
            speedButton.visibility = View.GONE
            clarityButton.visibility = View.GONE
            decoderButton.visibility = View.GONE
            subtitleButton.visibility = View.GONE
            autoSkipButton.visibility = View.GONE
            previousButton.visibility = View.GONE
            nextButton.visibility = View.GONE
            playPauseButton.visibility = View.GONE
            lockButton.visibility = View.GONE
            bottomBar.visibility = View.GONE
            fitButton.visibility = View.GONE
            fullscreenButton.visibility = View.GONE
            pipButton.visibility = View.GONE
            orientationButton.visibility = View.GONE
            audioBoostButton.visibility = View.GONE
            leftTools.visibility = View.GONE
        } else {
            selectButton.visibility = View.VISIBLE
            fitButton.visibility = View.GONE
            for (v in listOf(speedButton, decoderButton, subtitleButton, autoSkipButton, previousButton, nextButton,
                playPauseButton, orientationButton, audioBoostButton)) v.visibility = View.VISIBLE
            fadeTo(topBar, controlsVisible)
            fadeTo(bottomBar, controlsVisible)
            fadeTo(leftTools, controlsVisible)
            fadeTo(fullscreenButton, controlsVisible)
            fadeTo(pipButton, controlsVisible)
            // While locked the padlock is managed by flashLockButton().
            if (!locked) fadeTo(lockButton, controlsVisible)
        }
        updateCropButton()
        if (controlsVisible) {
            scheduleAutoHide(); ensureSeekTick()
            // Refresh immediately so the times are current the moment the controls appear.
            handler.removeCallbacks(updateRunnable); handler.post(updateRunnable)
        } else cancelAutoHide()
    }

    private fun showControlsTemporarily() { setControlsVisible(true) }
    private fun scheduleAutoHide() {
        cancelAutoHide()
        handler.postDelayed(autoHideRunnable, 3500)
    }
    private fun cancelAutoHide() { handler.removeCallbacks(autoHideRunnable) }
    private val autoHideRunnable = Runnable { if (!userSeeking && !locked && player.mediaItemCount > 0) setControlsVisible(false) }

    private fun syncPlaybackNotification() {
        if (userSeeking) return   // the brief pause while the seekbar is held must not rebuild the notification
        if (isBackgroundServiceRunning()) return
        if (!::player.isInitialized || player.mediaItemCount == 0) {
            if (notificationStarted) {
                try { stopService(Intent(this, PlaybackNotificationService::class.java)) } catch (_: Exception) {}
                notificationStarted = false
            }
            return
        }
        if (notificationSuppressed) {
            if (player.playWhenReady) notificationSuppressed = false else return
        }
        val playing = notificationPlayingState() ?: false
        val title = lastVideoTitle
        if (notificationStarted && lastNotificationPlaying == playing && lastNotificationTitle == title) return
        // Fast path: the service is already running, so change its notification in place. This also works while the
        // app is in the background or closed to PiP, where startForegroundService() may be refused by Android.
        if (PlaybackNotificationService.updateInPlace(title, playing)) {
            notificationStarted = true
            lastNotificationPlaying = playing
            lastNotificationTitle = title
            return
        }
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_UPDATE
            putExtra(PlaybackNotificationService.EXTRA_TITLE, title)
            putExtra(PlaybackNotificationService.EXTRA_PLAYING, playing)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            notificationStarted = true
            lastNotificationPlaying = playing
            lastNotificationTitle = title
        } catch (_: Exception) {}
    }

    private fun updateTitle() {
        if (::titleView.isInitialized) titleView.text = lastVideoTitle
    }

    /** Moves only the seekbar once per display frame while playing (60 times a second at 60 Hz), so the thumb glides instead of stepping 4×/s. */
    private val seekTickRunnable = object : Runnable {
        override fun run() {
            seekTickScheduled = false
            if (!::player.isInitialized || !controlsVisible || userSeeking || !player.isPlaying) return
            val d = player.duration
            if (d > 0 && d != C.TIME_UNSET) {
                val p = (max(0L, player.currentPosition) * SEEK_MAX / d).toInt().coerceIn(0, SEEK_MAX.toInt())
                if (p != seekBar.progress) seekBar.progress = p
            }
            seekTickScheduled = true
            seekBar.postOnAnimation(this)   // once per display frame (60/90/120 Hz): the thumb glides with the screen and never does extra work
        }
    }

    private fun ensureSeekTick() {
        if (seekTickScheduled || !::player.isInitialized || !controlsVisible || userSeeking || !player.isPlaying) return
        seekTickScheduled = true
        seekBar.postOnAnimation(seekTickRunnable)
    }

    private var lastShownPosSec = -2L
    private var lastShownRemSec = -2L
    private var lastShownEtaKey = -2L
    private var lastSpeedLabel: String? = null
    /** True between onStart and onStop. While the screen is not visible there is nothing to redraw. */
    private var uiStarted = false

    override fun onStart() {
        super.onStart()
        registerPipReceiver()
        uiStarted = true
        lastShownPosSec = -2L; lastShownRemSec = -2L; lastShownEtaKey = -2L
    }

    /** Time left at the current speed (video time left / speed: 2x => /2, 2.5x => /2.5) and the clock time playback will finish. */
    private fun showRemaining(positionMs: Long, durationMs: Long) {
        val valid = durationMs > 0 && durationMs != C.TIME_UNSET
        val speed = player.playbackParameters.speed.coerceAtLeast(0.01f)
        val adjusted = if (valid) (max(0L, durationMs - positionMs) / speed).roundToInt().toLong().coerceAtLeast(0L) else C.TIME_UNSET
        val remKey = if (adjusted == C.TIME_UNSET) -1L else adjusted / 1000L
        if (remKey != lastShownRemSec) {
            lastShownRemSec = remKey
            val s = formatMs(adjusted)
            durationText.text = if (adjusted != C.TIME_UNSET) "-$s" else s
            durationText.contentDescription = "Remaining $s"
        }
        // Finish time to the nearest minute, refreshed only when that minute changes.
        val etaKey = if (adjusted == C.TIME_UNSET) -1L else (System.currentTimeMillis() + adjusted + 30000L) / 60000L
        if (etaKey != lastShownEtaKey) {
            lastShownEtaKey = etaKey
            etaText.text = if (etaKey < 0L) "" else
                SimpleDateFormat("h.mm a", Locale.ENGLISH).format(etaKey * 60000L).lowercase(Locale.ENGLISH)
        }
    }

    private fun updateUi() {
        if (!::player.isInitialized) return
        if (!uiStarted) { syncPlaybackNotification(); return }
        val duration = player.duration
        val current = max(0L, player.currentPosition)
        val validDuration = duration > 0 && duration != C.TIME_UNSET
        if (timeLeftText.length() != 0) timeLeftText.text = ""
        // While a finger is on the seek bar the labels follow the dragged position (see onProgressChanged), not the player.
        if (!userSeeking) {
            // Format and set the clocks only when the displayed second changes (not on every 250 ms tick).
            val posSec = current / 1000L
            if (posSec != lastShownPosSec) {
                lastShownPosSec = posSec
                val s = formatMs(current)
                positionText.text = s
                positionText.contentDescription = "Elapsed $s"
            }
            showRemaining(current, duration)
        }
        if (!userSeeking) seekBar.progress = if (validDuration) (current * SEEK_MAX / duration).toInt().coerceIn(0, SEEK_MAX.toInt()) else 0
        updateExternalSubtitle()
        if (volumePercent > 100 && player.audioSessionId != loudnessSessionId) updateLoudness()
        setIconRes(playPauseButton, if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        updateButtonStates()
        syncPlaybackNotification()
        ensureSeekTick()
    }

    private val updateRunnable = object : Runnable {
        private var lastSave = 0L
        override fun run() {
            updateUi()
            val now = SystemClock.elapsedRealtime()
            if (now - lastSave >= 5000L) { lastSave = now; saveCurrentProgress() } // 5 s is plenty for resume; pause/stop also save, and it halves disk writes
            // Controls hidden and no external subtitles to time: no need to wake up four times a second.
            val needsFast = controlsVisible || externalSubtitleCues.isNotEmpty()
            handler.postDelayed(this, if (needsFast) 100L else 500L)
        }
    }

    private fun plainIconButton(textValue: String, sizeSp: Float) = TextView(this).apply {
        text = textValue
        textSize = sizeSp
        setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xE6000000.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(4), dp(6), dp(4))
        background = ColorDrawable(Color.TRANSPARENT)
        alpha = 1f
        isClickable = true
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.58f
                    v.scaleX = 0.94f
                    v.scaleY = 0.94f
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(90L).start()
                }
            }
            false
        }
        isFocusable = true
        stateListAnimator = null
    }

    private fun prepareSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Draw the video edge to edge, including around the camera punch-hole; controls are kept clear of it (see applyCutoutInsets).
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.setStatusBarContrastEnforced(false)
            window.setNavigationBarContrastEnforced(false)
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
    }

    /** Pushes the controls away from a camera cut-out on the left/right edge (landscape). */
    private fun applyCutoutInsets(left: Int, right: Int) {
        if (!::topBar.isInitialized) return
        val side = maxOf(left, right)
        topBar.setPadding(dp(16) + left, 0, dp(16) + right, 0)
        (leftTools.layoutParams as? FrameLayout.LayoutParams)?.let { it.leftMargin = dp(20) + left; leftTools.layoutParams = it }
        // Narrow (portrait phone) screens follow MX Player's portrait layout measured on this phone: the whole bottom block sits
        // 16 dp higher, the time boxes and buttons are nearer the screen edges, and prev / next are 55 dp from play (MX's wide
        // 98 dp spacing put Next on top of the screen-fit button). Wide screens keep the landscape geometry.
        val compact = resources.configuration.screenWidthDp < 480
        val lift = if (compact) 16 else 0
        val barSide = if (compact) 17 else 28
        val lockInset = if (compact) 3 else 28
        val pipInset = if (compact) 12 else 28
        val fitInset = if (compact) 66 else 82
        val transportWidth = if (compact) 55 else 98
        bottomBar.setPadding(dp(barSide) + side, 0, dp(barSide) + side, dp(lift))
        (bottomBar.layoutParams as? FrameLayout.LayoutParams)?.let { it.height = dp(110 + lift); bottomBar.layoutParams = it }
        (positionText.layoutParams as? LinearLayout.LayoutParams)?.let { it.width = dp(if (compact) 52 else 59); positionText.layoutParams = it }
        (lockButton.layoutParams as? FrameLayout.LayoutParams)?.let { it.leftMargin = dp(lockInset) + left; it.bottomMargin = dp(lift); lockButton.layoutParams = it }
        (fullscreenButton.layoutParams as? FrameLayout.LayoutParams)?.let { it.rightMargin = dp(fitInset) + right; it.bottomMargin = dp(lift); fullscreenButton.layoutParams = it }
        if (::pipButton.isInitialized) (pipButton.layoutParams as? FrameLayout.LayoutParams)?.let { it.rightMargin = dp(pipInset) + right; it.bottomMargin = dp(lift); pipButton.layoutParams = it }
        for (b in listOf(previousButton, playPauseButton, nextButton)) {
            (b.layoutParams as? LinearLayout.LayoutParams)?.let { it.width = dp(transportWidth); b.layoutParams = it }
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::root.isInitialized) root.requestApplyInsets()   // re-run applyCutoutInsets for the new width
    }

    /**
     * MIUI full-screen gestures treat a swipe that starts at the screen edge as "Back".
     * Exclude a strip at each edge (Android allows up to 200 dp per edge) so horizontal seek swipes and
     * seekbar drags that begin near the edge do not exit the video.
     */
    private fun installEdgeGestureExclusion() {
        if (Build.VERSION.SDK_INT < 29) return
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = r - l; val h = b - t
            if (w <= 0 || h <= 0) return@addOnLayoutChangeListener
            val edge = dp(28); val span = dp(200)
            val top = ((h - span) / 2).coerceAtLeast(0)
            val rects = listOf(android.graphics.Rect(0, top, edge, top + span), android.graphics.Rect(w - edge, top, w, top + span))
            if (root.systemGestureExclusionRects != rects) root.systemGestureExclusionRects = rects
        }
    }

    private fun showStatusBarTemporarily() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.show(WindowInsetsCompat.Type.statusBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        handler.removeCallbacks(hideStatusBarRunnable)
        handler.postDelayed(hideStatusBarRunnable, 4000L)
    }

    private fun hideStatusBarOnly() {
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.statusBars())
    }

    private fun toggleFullscreenBars() {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        val visible = WindowInsetsCompat.toWindowInsetsCompat(window.decorView.rootWindowInsets).isVisible(WindowInsetsCompat.Type.statusBars())
        if (visible) controller.hide(WindowInsetsCompat.Type.statusBars()) else controller.show(WindowInsetsCompat.Type.statusBars())
        haptic()
    }

    private fun iconButton(textValue: String, sizeSp: Float) = TextView(this).apply {
        text = textValue
        textSize = sizeSp
        setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xE6000000.toInt())
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(4), dp(6), dp(4))
        background = GradientDrawable().apply {
            setColor(0x44101010)
            cornerRadius = dp(28).toFloat()
            setStroke(dp(1), 0x44FFFFFF)
        }
        alpha = 1f
        isClickable = true
        isFocusable = true
        stateListAnimator = null
    }

    private fun button(textValue: String, primary: Boolean = false) = TextView(this).apply {
        text = textValue; textSize = 15f; setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8))
        background = roundedBackground(if (primary) 0xFF3D6FE0.toInt() else 0xFF303030.toInt(), 25); isClickable = true; isFocusable = true
    }
    private fun roundedBackground(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 12f; setTextColor(Color.WHITE)
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL))
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), 0xF0000000.toInt())
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
    }
    private val zeroDigit: Char by lazy { java.text.DecimalFormatSymbols.getInstance(Locale.getDefault()).zeroDigit }
    private fun appendNumber(sb: StringBuilder, n: Long, z: Char) {
        if (n >= 10L) appendNumber(sb, n / 10L, z)
        sb.append(z + (n % 10L).toInt())
    }
    /** h:mm:ss or m:ss without String.format (which is slow and ran several times per scrub frame). Same digits as before. */
    private fun formatMs(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0L) return "—"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        val z = zeroDigit
        val sb = StringBuilder(8)
        if (hours > 0) { appendNumber(sb, hours, z); sb.append(':'); sb.append(z + (minutes / 10).toInt()).append(z + (minutes % 10).toInt()) }
        else appendNumber(sb, minutes, z)
        sb.append(':').append(z + (seconds / 10).toInt()).append(z + (seconds % 10).toInt())
        return sb.toString()
    }
    private fun updateScreenAwake(isPlaying: Boolean) {
        if (isPlaying) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Leaving the app enters PiP automatically unless the user explicitly
        // selected Background Play. Background Play owns playback outside the UI.
        if (autoPictureInPicture && !isBackgroundPlaybackActive() && Build.VERSION.SDK_INT >= 26 &&
            ::player.isInitialized && player.mediaItemCount > 0 &&
            !isInPictureInPictureMode) {   // also when paused
            enterPip()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        updateButtonStates()
        if (isInPictureInPictureMode) {
            registerPipReceiver()
            // enterPictureInPictureMode() already carried the params; no second update during the transition.
            setControlsVisible(false)
        } else {
            lastPipParamsKey = null
            // Closed with the X: the activity is stopped (CREATED). Expanding to full screen leaves it STARTED/RESUMED.
            // Without this the hidden activity kept playing audio after the PiP window was closed.
            if (lifecycle.currentState == androidx.lifecycle.Lifecycle.State.CREATED &&
                ::player.isInitialized && !isChangingConfigurations && !isBackgroundPlaybackActive()) {
                if (player.playWhenReady) player.pause()
                saveCurrentProgress()
            }
            updatePictureInPictureParamsForAutoEntry()
        }
    }

    override fun onStop() {
        uiStarted = false
        saveCurrentProgress()
        handler.removeCallbacks(updateRunnable)
        handler.removeCallbacks(seekTickRunnable)
        seekBar.removeCallbacks(seekTickRunnable)
        seekTickScheduled = false
        // Fallback when neither Background Play nor Picture-in-Picture is taking over:
        // pause instead of silently playing on with no visible player.
        if (::player.isInitialized && player.isPlaying && !isBackgroundPlaybackActive() &&
            !isInPictureInPictureMode && !isChangingConfigurations) {
            player.pause()
        }
        super.onStop()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Dialogs and app switching can bring the system bars back; keep playback fullscreen.
        if (hasFocus) hideSystemBars()
    }

    override fun onResume() {
        super.onResume()
        reclaimFromBackgroundService()
        syncVolumeFromSystem(keepBoost = true)
        handler.removeCallbacks(updateRunnable)
        handler.post(updateRunnable)
    }

    override fun onPause() {
        endTemporarySpeed()
        handOffToBackgroundService()

        saveCurrentProgress()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    private fun togglePlaybackFromNotification(): Boolean {
        if (!::player.isInitialized || player.mediaItemCount == 0) return false
        notificationSuppressed = false
        // Decide from playWhenReady (what the user sees as "playing"), not isPlaying, which lags while buffering.
        if (player.playWhenReady && player.playbackState != Player.STATE_ENDED) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition()
            player.play()
        }
        updateUi()
        syncPlaybackNotification()
        return true
    }

    /** "Playing" as the notification shows it: follows playWhenReady so it flips the instant a button is tapped, even while buffering. */
    private fun notificationPlayingState(): Boolean? {
        if (!::player.isInitialized || player.mediaItemCount == 0) return null
        return player.playWhenReady && player.playbackState != Player.STATE_ENDED && player.playbackState != Player.STATE_IDLE
    }

    private fun stopPlaybackFromNotification(): Boolean {
        if (!::player.isInitialized) return false
        player.pause()
        saveCurrentProgress()
        notificationSuppressed = true
        notificationStarted = false
        lastNotificationPlaying = null
        lastNotificationTitle = null
        updateUi()
        return true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == PlaybackNotificationService.ACTION_TOGGLE) {
            togglePlaybackFromNotification()
            intent.action = null
        } else {
            handleIncomingIntent(intent)
        }
    }

    override fun onDestroy() {
        unregisterPipReceiver()
        landscapeOrientationListener?.disable()
        landscapeOrientationListener = null
        if (activeInstance?.get() === this) activeInstance = null
        saveCurrentProgress()
        if (handoffPending && ::player.isInitialized) {
            // The screen is going away mid hand-off: let the service take over now instead of leaving it silent.
            BackgroundPlaybackService.resumeAt(player.currentPosition.coerceAtLeast(0L))
            handoffPending = false
        }
        handler.removeCallbacksAndMessages(null)
        cancelAutoHide()
        volumeBoostEnhancer?.release()
        volumeBoostEnhancer = null
        subtitleExecutor.shutdownNow()
        ioExecutor.shutdown()
        if (notificationStarted) {
            try { stopService(Intent(this, PlaybackNotificationService::class.java)) } catch (_: Exception) {}
            notificationStarted = false
        }
        releaseScreenSession()
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

/**
 * What the media session sees: the real player with in-item seeking and the real duration, so the system media
 * controls (notification panel, lock screen) show a seek bar you can drag. The separate rewind / fast-forward
 * buttons stay hidden so the notification keeps its normal previous / play / next layout.
 */
private class ScreenSessionPlayer(player: Player) : androidx.media3.common.ForwardingPlayer(player) {
    private val hidden = intArrayOf(
        Player.COMMAND_SEEK_BACK,
        Player.COMMAND_SEEK_FORWARD
    )
    override fun getAvailableCommands(): Player.Commands =
        super.getAvailableCommands().buildUpon().removeAll(*hidden).build()
    override fun isCommandAvailable(command: Int): Boolean =
        command !in hidden && super.isCommandAvailable(command)
}

/** Crop base transform meaning "no crop" (shared, so pinch zoom allocates nothing per frame). */
private val NO_CROP = Triple(1f, 0f, 0f)

/** Draggable crop box over the video picture: drag inside to move, drag an edge or corner to resize. */
private class CropOverlayView(
    context: android.content.Context,
    private val bounds: android.graphics.RectF,
    initial: android.graphics.RectF
) : android.view.View(context) {
    val rect = android.graphics.RectF(initial)
    private val density = resources.displayMetrics.density
    private val dimPaint = android.graphics.Paint().apply { color = 0xB3000000.toInt() }
    private val linePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = android.graphics.Paint.Style.STROKE; strokeWidth = 2f * density
    }
    private val gridPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66FFFFFF; style = android.graphics.Paint.Style.STROKE; strokeWidth = 1f * density
    }
    private val handlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val handleEdgePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF000000.toInt(); style = android.graphics.Paint.Style.STROKE; strokeWidth = 1.5f * density
    }
    private val touch = 40f * density
    private val minSize = 56f * density
    private var mode = 0 // bits: 1 left, 2 right, 4 top, 8 bottom, 16 move
    private var lastX = 0f
    private var lastY = 0f

    override fun onDraw(canvas: android.graphics.Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.drawRect(0f, 0f, w, rect.top, dimPaint)
        canvas.drawRect(0f, rect.bottom, w, h, dimPaint)
        canvas.drawRect(0f, rect.top, rect.left, rect.bottom, dimPaint)
        canvas.drawRect(rect.right, rect.top, w, rect.bottom, dimPaint)
        for (i in 1..2) {
            val x = rect.left + rect.width() * i / 3f
            val y = rect.top + rect.height() * i / 3f
            canvas.drawLine(x, rect.top, x, rect.bottom, gridPaint)
            canvas.drawLine(rect.left, y, rect.right, y, gridPaint)
        }
        canvas.drawRect(rect, linePaint)
        val xs = floatArrayOf(rect.left, (rect.left + rect.right) / 2f, rect.right)
        val ys = floatArrayOf(rect.top, (rect.top + rect.bottom) / 2f, rect.bottom)
        val radius = 7f * density
        for (xi in 0..2) for (yi in 0..2) {
            if (xi == 1 && yi == 1) continue
            canvas.drawCircle(xs[xi], ys[yi], radius, handlePaint)
            canvas.drawCircle(xs[xi], ys[yi], radius, handleEdgePaint)
        }
    }

    private fun hit(x: Float, y: Float): Int {
        val dl = abs(x - rect.left)
        val dr = abs(x - rect.right)
        val dt = abs(y - rect.top)
        val db = abs(y - rect.bottom)
        val inY = y > rect.top - touch && y < rect.bottom + touch
        val inX = x > rect.left - touch && x < rect.right + touch
        var m = 0
        if (inY) { if (dl < touch && dl <= dr) m = m or 1 else if (dr < touch) m = m or 2 }
        if (inX) { if (dt < touch && dt <= db) m = m or 4 else if (db < touch) m = m or 8 }
        if (m == 0 && rect.contains(x, y)) m = 16
        return m
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y; mode = hit(e.x, e.y) }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 0) return true
                val dx = e.x - lastX
                val dy = e.y - lastY
                lastX = e.x; lastY = e.y
                if (mode == 16) {
                    rect.offset(dx.coerceIn(bounds.left - rect.left, bounds.right - rect.right), dy.coerceIn(bounds.top - rect.top, bounds.bottom - rect.bottom))
                } else {
                    if ((mode and 1) != 0) rect.left = (rect.left + dx).coerceIn(bounds.left, maxOf(bounds.left, rect.right - minSize))
                    if ((mode and 2) != 0) rect.right = (rect.right + dx).coerceIn(minOf(bounds.right, rect.left + minSize), bounds.right)
                    if ((mode and 4) != 0) rect.top = (rect.top + dy).coerceIn(bounds.top, maxOf(bounds.top, rect.bottom - minSize))
                    if ((mode and 8) != 0) rect.bottom = (rect.bottom + dy).coerceIn(minOf(bounds.bottom, rect.top + minSize), bounds.bottom)
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }
}

/** A white vector icon with a dark outline (the icon drawn dark at eight small offsets, then white on top). */
private class OutlinedIconView(context: android.content.Context, resId: Int) : android.view.View(context) {
    private val base = context.getDrawable(resId)!!
    private val dark = base.constantState!!.newDrawable().mutate().also { it.setTint(Color.BLACK) }
    private val light = base.constantState!!.newDrawable().mutate()

    override fun onDraw(canvas: android.graphics.Canvas) {
        val d = (0.8f * resources.displayMetrics.density).toInt().coerceAtLeast(1)
        val w = width
        val h = height
        for (dx in -1..1) for (dy in -1..1) {
            if (dx == 0 && dy == 0) continue
            dark.setBounds(d + dx * d, d + dy * d, w - d + dx * d, h - d + dy * d)
            dark.draw(canvas)
        }
        light.setBounds(d, d, w - d, h - d)
        light.draw(canvas)
    }
}

/** TextView that draws its text with a solid outline, so it stays readable over any video frame without a backing box. */
private class OutlinedTextView(context: android.content.Context) : TextView(context) {
    private val strokePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    var outlinePx = 0f
        set(value) { field = value; invalidate() }

    override fun onDraw(canvas: android.graphics.Canvas) {
        if (outlinePx <= 0f) { super.onDraw(canvas); return }
        val t = text?.toString() ?: return
        strokePaint.set(paint)
        strokePaint.textAlign = android.graphics.Paint.Align.CENTER
        val x = (width + paddingLeft - paddingRight) / 2f
        val y = (height + paddingTop - paddingBottom) / 2f - (strokePaint.descent() + strokePaint.ascent()) / 2f
        strokePaint.style = android.graphics.Paint.Style.STROKE
        strokePaint.strokeWidth = outlinePx * 2f
        strokePaint.strokeJoin = android.graphics.Paint.Join.ROUND
        strokePaint.color = Color.BLACK
        canvas.drawText(t, x, y, strokePaint)
        strokePaint.style = android.graphics.Paint.Style.FILL
        strokePaint.color = Color.WHITE
        canvas.drawText(t, x, y, strokePaint)
    }
}

/** Visual state of an MX-style button: vector icon (res == 0 means text), optional circle, tint colours. */
private class BtnState(var res: Int, var active: Boolean, var circle: Boolean, var frac: Float, var color: Int = 0, var iconTint: Int = 0xFFFFFFFF.toInt())

/** Draws an optional circle plus a white vector icon with a soft shadow so it reads on any video frame. */
private class IconDrawable(
    private val icon: android.graphics.drawable.Drawable,
    private val circleColor: Int,
    private val frac: Float,
    private val density: Float,
    private val iconTint: Int = 0xFFFFFFFF.toInt()
) : android.graphics.drawable.Drawable() {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: android.graphics.Canvas) {
        val s = minOf(bounds.width(), bounds.height()).toFloat()
        if (s <= 0f) return
        val cx = bounds.exactCenterX()
        val cy = bounds.exactCenterY()
        if (circleColor != 0) {
            paint.style = android.graphics.Paint.Style.FILL
            paint.color = circleColor
            canvas.drawCircle(cx, cy, s * 0.44f, paint)
            if (circleColor == 0xFFFFFFFF.toInt()) {   // white "locked" disc keeps a hairline so it reads on white slides
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = density
                paint.color = 0x66000000
                canvas.drawCircle(cx, cy, s * 0.44f - density * 0.5f, paint)
            }
        }
        val half = (s * frac / 2f).toInt().coerceAtLeast(1)
        val l = (cx - half).toInt(); val t = (cy - half).toInt()
        val r = (cx + half).toInt(); val b = (cy + half).toInt()
        icon.setBounds(l, t, r, b)
        icon.setTint(iconTint)
        icon.draw(canvas)
    }

    override fun setAlpha(alpha: Int) { icon.alpha = alpha }
    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) { icon.colorFilter = colorFilter }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}
