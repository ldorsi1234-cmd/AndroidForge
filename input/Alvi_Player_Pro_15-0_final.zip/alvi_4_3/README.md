# Alvi Player Pro 15.0

## 15.0 final (build 82)

- Crop is now a real cut. Before, the picture was only zoomed and moved so the box was centred, so on the side where the box is smaller than the screen you saw a strip of the part you had cropped away. Now everything outside the box is hidden, and you get black bars when the box and the screen differ in shape. The cut follows the pinch zoom, the pan and the horizontal flip, and it is accurate to about one pixel. It still works in Fit mode only.
- Pinch zoom and pan on a cropped video no longer allocate objects per frame (the crop box and clip are reused).
- The phone's decoder list is read on a side thread while the screen is being built, so the first video starts sooner after the app opens.
- The background-play player now has a 128 MB buffer cap like the screen player (it had none). While Background play takes over, both players hold buffers at the same time, so this protects very high-bitrate videos from running the app out of memory. Normal lecture videos are not affected.
- Refresh rate: the app no longer asks Android for the display's highest refresh rate (120 Hz on the POCO X3). It follows the phone's own setting, so a phone set to 60 Hz stays at 60 Hz. The seek bar thumb and the controls still update once per display frame, so they run at 60 per second there.
- Nothing else changed in playback: the 15.0 settings below (2 to 5 minute read-ahead, 256 MB cap, hardware decoding with fallback, async codec queueing, steady CPU request, TextureView surface) are unchanged.
- Not compiled or device-tested in the authoring environment.

## 15.0: smoother and faster (performance over battery and memory)

- Playback buffer: 2 to 5 minutes read ahead (was 1 to 3), 2 minutes kept behind (was 1), restart after a seek in 200 ms (was 300 ms). Capped at 256 MB so a very high-bitrate video cannot crash the app.
- Seek bar thumb updates once per display frame (was 30 times a second) and the time labels refresh every 100 ms (was 250 ms) while the controls are visible.
- The UI thread runs at higher priority, and the app asks for steady CPU speed.
- Pinch zoom allocates nothing per frame when there is no crop.
- Seekbar scrubbing now works like MX Player: the whole video frame follows your finger (no thumbnail box). The elapsed and remaining times beside the seekbar follow your finger while you drag (no centre readout). The video stays paused while the seekbar is held and plays again on release if it was playing.
- Scrub seeks are fast keyframe seeks sent frame-paced (next seek as soon as the previous frame is on screen, at least 30 ms apart; measured from a screen recording of MX Player). The swipe-seek gesture uses the same logic. The thumbnail decoding, cache and background strip were removed.
- Faster time text (no String.format), labels rebuilt only when the displayed second changes, seekbar thumb moves once per display frame, no per-tick string allocation for external subtitles, no notification rebuild while scrubbing.
- Everything below was added since 14.0 and is included in 15.0.

## Since 14.0: finish time, crop, portrait layout and more

- The expected finish clock time (for example "4.30 pm") now shows just below the time left, on the right. It is based on the speed-adjusted time left, so it updates when you change speed or seek.
- Top round tool buttons are 7 dp closer together (6 dp gap, was 13 dp).
- Next / previous now work in the same folder: the app asks for video access (and notifications) on first launch. When you open any video, the other videos in its folder (not subfolders) are queued around it in natural name order (Lecture 2 before Lecture 10) without interrupting playback. Without the permission the app behaves as before; "Videos in saved folder" still works.
- Adding a subtitle no longer drops the folder queue.
- Performance first: the app asks Android for steady (non-throttled) CPU speed where the phone supports it. Playback was already tuned (hardware decoding with fallback, async codec queueing, large read-ahead buffer, large heap).
- The video is drawn on a TextureView (res/layout/alvi_player_view.xml) so zoom and pan move in the same frame as your fingers. It uses more GPU and battery than the default surface, which is intended (performance over battery). To go back, replace the inflate call in MainActivity with PlayerView(this).
- Brightness / volume indicators are readable on white slides: the percent text and icon have a thin dark outline and the bar has a soft dark edge.
- The skip indicator (arrows and seconds) has a dark outline around the original-size white arrows and text, so it is readable on white slides.
- Brightness / volume: the percent number is regular weight (not bold) and the bar is slimmer (2.5 dp, was 4 dp).
- The skip "10s" text is 16sp regular, the same size as the volume / brightness number (was 20sp).
- Crop button (square crop icon, last of the round tool buttons): tap it and drag a box over the part of the picture to keep, then APPLY (CANCEL leaves things as they were); the picture is zoomed so the box fills the screen on its limiting side, everything outside the box is hidden (black bars on the other side), and the button turns blue. Tap the blue button to undo the crop. The crop is saved for that exact video only (recognised by file name + size, so it comes back however the video is opened) until you undo it. Works in Fit mode (other screen-fit modes show the full picture until you return to Fit). Pinch zoom works on top of the crop, double-tap resets only the zoom.
- Pinch zoom now zooms around your fingers (the spot you pinch stays under them) instead of the middle of the screen, and a two-finger drag moves the zoomed picture smoothly.
- Pinch zoom no longer shakes the picture: touches are now read in fixed screen coordinates instead of the coordinates of the view being zoomed.
- Screen fit button: a tap now cycles Fit, Stretch, Crop/Zoom, Fit with black bars and shows the name briefly. A long press opens the list (and the horizontal flip switch).
- Orientation follows the video: a portrait video opens in portrait, a landscape video in landscape (the rotate button still overrides it). The app also starts in the shape of the last video.
- Speed panel in portrait: [−] 2.1x [+] on top and all speed boxes (0.5x to 3.0x) in a row below.
- If the app reopens a video it can no longer read, it now shows the home panel (Open video / Open folder / Recent) instead of a black screen with an error. A one-time file-manager grant that expired is replaced by the video's permanent address when it is known.
- Folder queue skips empty or missing files, and if a queued neighbour still fails to play it is skipped instead of stopping playback with an error.
- The speed button label uses a lower-case x (2.4x, was 2.4X).
- Speed panel: the + button was pushed off the screen in portrait. The speed chips now scroll between − and +, so both are always visible.
- Portrait bottom controls follow MX Player's portrait layout (measured from a screenshot on the POCO X3): the timeline and buttons sit 16 dp higher, time boxes and lock / screen-fit / PiP are nearer the edges, and Previous / Play / Next are 55 dp apart, so Next no longer overlaps the screen-fit button. Landscape and wide screens keep the original geometry.
- Turning Background play on shows the system "always allow in background" prompt once, so battery saver is less likely to kill background audio.
- Seek bar circle is now one solid, fully opaque circle: no translucent halo layer and no see-through gap cut into the track around it (same size as before).
- While you drag the seek bar, elapsed time, time left and finish time all follow the dragged position (before, elapsed time jumped back to the playing position every second). The finish time is rounded to the nearest minute.

## 14.0: level indicator tidy-up (earlier in 14.0)

- Brightness and volume indicators no longer have a background box.
- Percentage text is smaller (16sp bold, was 18sp); bar and icon unchanged.
- Top round buttons are 4 dp closer together (13 dp gap, was 17 dp); the speed label (2X) is now bold.

A fast, study-focused Android video player built on AndroidX Media3 1.5.1.

## Earphone controls (Bluetooth, wired, car)
- Earphone play/pause key: 1 press = play/pause, 2 presses = next video, 3 presses = previous video.
- Next / Previous keys: skip video (if there is none, jump by the seek amount); hold to keep seeking.
- Fast-forward / Rewind keys seek by the seek amount; Play, Pause and Stop keys do what they say.
- Works in the app, in PiP, in background play and with the screen off.
- Menu → Playback → Earphone controls: On (default) or Off to fall back to the system's default button handling.

## 11.0 final: play/pause reliability
- PiP play/pause button and the notification button share one toggle path decided from playWhenReady, so a tap works while buffering and replays when the video has ended.
- PiP button icon updates the instant playback state changes (no stale icon).
- Closing the PiP window with X now pauses playback instead of leaving hidden audio running.
- Media session on the on-screen player: headset, Bluetooth and car play/pause/next/previous buttons control it in the app, in PiP and with the screen off; the notification uses the media style.
- The foreground notification is updated in place, so it stays correct even when the app is in the background or PiP was closed.

## UI / playback changes in 2.5
- MX-style compact top control bar and large center play/previous/next controls.
- Bottom control surface reduced to a thin seek bar only; no bottom +/- seek buttons.
- Playback speed is a clock-style top button (◷).
- Voice Clarity has its own top control (CL).
- Auto Skip Silence has its own top control (AS) with Off / Mild / Strong modes.
- Horizontal seeking also changes speed in 0.5x steps: left slows down, right speeds up, with an on-screen hint.
- Folder playlists expose previous/next playback in-app and through the Android media notification.
- Background playback uses Media3 MediaSessionService. The system media controls automatically expose pause and next/previous when a playlist is available.

## Auto Skip Silence
Media3's PCM silence processor is configured directly in the audio sink for two practical modes:
- Mild: trims only longer quiet gaps while preserving more natural pauses.
- Strong: trims shorter/larger silent gaps for tighter lecture/podcast playback.

This detects low-level audio silence, not semantic human speech. It does not use cloud/AI processing.

## Notification controls
Background playback uses a MediaSessionService. When playing a folder playlist, Android's media controls can expose pause and next/previous actions from the active playlist. This follows Media3's recommended background playback architecture.

## Build
- compileSdk / targetSdk: 35
- minSdk: 23
- Java/Kotlin target: 17
- Media3: 1.5.1
- No FFmpeg Maven dependency is included.

This package is source code. APK/device validation must be performed in an Android build environment.


## MX-style long-press speed
Press and hold the video surface to temporarily play at 2× speed. Release immediately restores the user-selected speed. Horizontal swipe remains seek-only. This mirrors the familiar MX Player long-press fast-forward interaction.



## 3.3 MX-style control placement
- Playback OSD follows the supplied MX Player reference layout rather than using a generic control arrangement.
- Top bar: back/title on the left; audio tracks, subtitles, decoder and More on the right.
- Left-side playback cluster: Voice Clarity, Landscape/Portrait, playback speed and Auto Skip Silence.
- Speed button remains tap-to-select and hold + left/right drag for temporary speed, releasing back to the previously selected speed.
- Bottom: elapsed time at left, thin seekbar, remaining time at right; centered previous/play-pause/next controls; lock at lower left; aspect-ratio and fullscreen controls at lower right.
- Horizontal flip remains available; vertical flip remains excluded.
- Lock and playback icons use plain monochrome glyphs.
- Auto Skip Silence remains icon-only with Off/Mild/Strong modes.
- Noise Reduction is not part of the playback OSD.


## 3.4 volume and OSD refinement
- Top and bottom playback OSD panels use a more transparent MX-style black overlay.
- App volume 0–100% maps directly to the Android media-volume range: app 100% equals phone media volume 100%.
- App volume 100–200% keeps the phone at maximum and applies LoudnessEnhancer only to the excess.
- Temporary hold speed uses horizontal left/right drag, matching the requested MX-style interaction.

## 3.7 UI and seek preview improvements
- Refined MX-style top/bottom OSD opacity and spacing.
- Rebuilt the playback seekbar with a cleaner thin track and circular thumb.
- Seek thumbnails use one-second cache buckets and a larger 64-frame cache.
- Preview extraction uses scaled frame decoding on Android 8.1+ and closest-sync extraction to reduce decode latency.
- Cached thumbnails appear immediately while a new frame is decoded in the background.


## 3.9 notification control
- Notification Play/Pause is a service action and does not launch MainActivity.
- A single tap toggles the active foreground player directly and refreshes the notification state.
- Tapping the notification body still opens Alvi Player.


## 4.0 — MX-style player UI/interaction refinement
- Playback overlay reorganized to closely mirror MX Player: top action bar, vertical left tool rail, bottom timeline/transport strip, bottom-corner lock/aspect/fullscreen controls.
- Transparent black gradient overlays replace flat bars for a closer MX-style presentation.
- Playback gestures retained: single tap show/hide controls, double-tap left/right seek, double-tap center play/pause, vertical brightness/volume, pinch zoom/pan, and temporary 2× speed.
- Notification Play/Pause remains a service action and does not open the player.
- This is an MX-style implementation; MX Player proprietary artwork/branding is not copied.


## 4.1 interaction refinements
- Temporary speed hold/drag uses 0.5× steps.
- PiP and Background Playback are visible top-bar buttons.
- Remaining time is estimated at playback speed: 2× /2, 2.5× /3, 3× /4.
- Active toggle buttons change to a white active state.
- Bottom-left has one lock control; resize/aspect remains one dedicated control.
- Status-bar clock/battery can remain visible over the video with transparent system bars.


### 4.2 behavior refinement
- Leaving Alvi Player automatically enters picture-in-picture while a video is playing, unless Background Play has been explicitly enabled.
- Background Play therefore takes priority over automatic PiP.
- Clock/battery status information is hidden during normal playback; a touch starting at the top edge temporarily reveals the Android status bar, then it hides again.


## 4.3 orientation behavior
- Playback remains landscape-only.
- The orientation sensor switches between landscape-left and landscape-right when the phone is rotated.
- Portrait is never selected automatically.


## 4.5 Pro refinement
- Added always-visible top-bar Picture-in-Picture and Background Play buttons.
- Background Play takes priority over automatic PiP when leaving the app.
- Landscape-only sensor rotation now uses a dead-zone to avoid accidental rapid flips through portrait.
- Speed hold/drag remains in 0.5× steps and the active speed is reflected in the control.
- Remaining wall-clock playback time is adjusted by the requested speed mapping (2×→÷2, 2.5×→÷3, 3×→÷4).
- Controls have a subtle pressed animation and active controls use a white selected state.
- Top-edge status-bar reveal remains temporary; clock/battery stay hidden during normal playback.


## 4.6 Landscape rotation direction fix
- Corrected the landscape sensor mapping so rotating the phone toward the user selects the expected landscape side instead of the opposite side.


## Version 4.9 — Automatic PiP fix
- Enabled PiP support on the MainActivity manifest entry (required by Android).
- Automatic PiP is enabled by default and uses Android 12+ auto-enter parameters, with onUserLeaveHint fallback.
- Background Play still takes priority over PiP.


## Version 5.1 — Orientation behavior correction
- Sensor-driven mapping: 90° selects the corrected landscape side; 270° selects the opposite landscape side.
- Orientation button toggles Portrait and sensor-driven Landscape.
- Landscape sensor listener is disabled in Portrait and re-enabled when returning to Landscape.


## Version 5.2 — Clear playback overlays
- Top and bottom playback bars use under 5% black opacity so the video remains clearly visible beneath them.


## Version 5.3 — Smoother Seeking
- Reduced seek-preview debounce for more responsive thumbnail scrubbing.
- Uses nearest decodable sync frame for fast seeking when Fast Seeking is enabled.
- Hides the blocking buffering spinner during playback; this improves visual continuity but cannot eliminate actual source/decoder buffering for every video.


## Version 5.4 — Reliable Auto PiP / Background Play Priority
- Synchronizes Android 12+ automatic PiP entry with actual playback state.
- Automatic PiP is suppressed while Background Play is enabled.
- Updates PiP parameters when playback starts/pauses and when either mode is toggled.
- Keeps the leave-app fallback for supported Android versions.


## Version 5.6 — Fullscreen button now opens screen-fit options
- The far-right fullscreen icon now opens the same screen-fit/aspect-ratio menu as the screen-fit control.
- Immersive fullscreen is still available through the app's other fullscreen/orientation behavior.


## Version 5.7 — MX-style icon contrast
- Increased icon/text weight and added dark shadows for visibility over bright and white video frames.
- Kept button backgrounds relatively subtle while strengthening white icon contrast.


## Version 5.8 — MX-style Roboto typography
- Standardized playback UI text on Android Roboto (`sans-serif`) and medium-weight Roboto (`sans-serif-medium`) for controls and titles.
- Preserves the high-contrast white icons and dark text shadows from version 5.7.


## Version 5.9 — Background play, lock icon, speed hold-and-drag
- Removed the extra "↔" button at the bottom right; the far-right button still opens Screen Fit.
- Removed the "✓" suffix from the voice-clarity star (it wrapped and showed as a stray mark); the white highlighted background already shows it is on.
- Lock button is now a drawn padlock: open on a dark circle when unlocked, closed on a red circle when locked (shown for ~1.8 s after locking and on every tap while locked).
- Background Play is now a setting: switching it on/off no longer pauses the video. Playback is handed to the background service only when the app is paused/left, and taken back (same position) when you return.
- Hold-and-drag speed: hold the video (or the speed button) and drag right/left to change speed in 0.5× steps (10% of screen width per step); releasing returns to the default speed.
- Not compiled or device-tested in the authoring environment.


## Version 6.0 — MX Player-style interface
- All control icons are now crisp vector drawables (back, audio, subtitles, PiP, background play, more, rotate, skip silence, voice clarity, lock, previous/play/pause/next, screen fit) instead of text glyphs, drawn white with a soft shadow so they stay visible on bright frames.
- MX-style layout: top bar with larger Roboto Medium title, a tool row below it (rotate, speed "2X", skip silence, voice clarity) with dark circles that turn blue when active, larger timecodes on both sides of the seekbar, big transport controls, lock bottom-left, screen fit bottom-right.
- Locked state: red circle with a closed padlock; unlocked is a plain open padlock.
- Smoother feel: controls fade in/out as groups, the seekbar has 10× finer resolution and updates 4× per second, button presses scale/fade, and subtle top/bottom gradients replace flat overlays.
- Previous/Next are always shown (Next toasts when there is no next video).
- Not compiled or device-tested in the authoring environment.


## Version 6.1 — Background play crash/pause fix
- The background service now calls startForeground() immediately (same id/channel as Media3's notification) and registers its MediaSession with addSession(), so Android no longer kills the app or stops playback after leaving the app with Background Play on.
- Added the standard MediaSessionService intent filter to the manifest.
- Not compiled or device-tested in the authoring environment.


## Version 6.2 — Stability and smoothness pass
- Video file name is cached; progress saving no longer queries the content resolver on the UI thread every second.
- Playback history keeps one entry per video (max 50) instead of adding a new entry on every launch.
- A video that is within 5 s of the end (or finished) restarts from the beginning next time; controls appear when playback ends.
- The UI refresh loop (4×/s) runs only while the app is visible, saving battery.
- PiP window uses the real video aspect ratio (was always 16:9) and updates when the video size is known.
- With Background Play off and PiP not active, leaving the app now pauses playback instead of playing on invisibly.
- Updated the speed hold-and-drag help text; all pending handler callbacks are cleared on destroy.
- Not compiled or device-tested in the authoring environment.


## Version 6.3 — PiP play/pause and cleaner More menu
- The Picture-in-Picture window now has a Play/Pause button that follows the playback state.
- More menu: rows show the title on the left and the current value on the right, items close the menu when tapped (so toggles never show stale labels), darker rounded dialog.
- Removed the "Speed hold + drag" entry from the More menu (the gesture itself is unchanged).
- Not compiled or device-tested in the authoring environment.


## Version 7.0 — Final polish and stability
- Decoder switching keeps the whole folder playlist and position (it used to collapse to one video).
- Opening a single video clears any old folder queue; Background Play hand-off uses the correct playlist.
- Back is ignored while locked (the red padlock flashes instead); fullscreen is re-applied whenever the window regains focus, and touching the top edge no longer brings the status bar back.
- Folder video lists are sorted by name.
- Subtitle files with a byte-order mark or Windows-1252 text now display correctly.
- Track picker marks the currently selected track.
- Looks: consistent dark rounded dialogs app-wide (new Theme.Alvi), black window background (no white flash), larger gesture hint at the top centre, refreshed home screen with a primary "Open video" button.
- Not compiled or device-tested in the authoring environment.


## Version 7.1 — Clarity, smoother seeking, tighter MX layout
- Voice Clarity now has levels (Off / Light / Balanced / Strong). Tap the button to cycle, hold it (or use More) to pick. The EQ curve is interpolated smoothly from the device's own bands, with a little headroom to avoid clipping. Old on/off setting migrates to "Balanced".
- Icons swapped: Voice Clarity uses the waveform icon; Auto Skip Silence has a new icon (sound bars with a fast-forward jump across the gap).
- Seekbar sits closer to the bottom edge (48 dp, was 64 dp): timeline 34 dp + transport row 48 dp; lock/fit buttons realigned to the transport row.
- Smoother seekbar: 100,000-step resolution, thumb refreshed ~30×/s while playing (was 4×/s), halo on the thumb while dragging.
- Seek thumbnails: much smaller (76 dp tall, follows your finger, shows the time), decoded at ~200 px, latest-position-wins decoding (no queue of stale frames), byte-limited cache, neighbour frame shown instantly while the exact one decodes.
- MX layout: the headphones (Background play) button moved from the top bar into the tool row, first on the left, as in MX Player.
- Not compiled or device-tested in the authoring environment.


## Version 7.2 — Seamless background play
- Hand-off no longer pauses the video first. The screen player keeps playing while the background service prepares (audio only, video decoding disabled); once the service is ready it continues from the live position and only then does the screen player pause.
- Returning to the app works the same way in reverse: the service keeps playing until the screen player is actually playing again, then stops.
- If you come back before the hand-off finishes, nothing is interrupted; if the service cannot get ready within ~8 s, playback simply stays in the app.
- Not compiled or device-tested in the authoring environment.


## Version 8.0 — Final polish (no new features)
- Playback buffering tuned for lectures: 30–60 s buffered ahead, playback restarts after 0.4 s (1.5 s after a stall), so seeking and 2x playback recover faster. Same settings in the background service.
- Control fades run on hardware layers for smoother show/hide.
- Includes everything from 7.1 (clarity levels, new icons, tighter seekbar, smooth thumb, fast small thumbnails, MX tool row) and 7.2 (seamless background play).
- Not compiled or device-tested in the authoring environment.


## Version 8.1 — Cleaner More menu
- Removed the sleep timer.
- Removed More-menu entries that duplicate on-screen buttons (Auto Skip Silence, Voice Clarity, Screen fit, Orientation, Decoder, Audio/subtitle tracks, Picture-in-picture, Background play) and rarely needed ones (Resume current video, Reset volume, Pinch zoom reset).
- Menu is now Playback, Display & audio, Library.
- Not compiled or device-tested in the authoring environment.


## Version 8.2
- Remaining time (e.g. 1:49:06) stays on one line.
- Hold-and-drag speed is about 2.2× more sensitive (one 0.5× step per ~4.5% of screen width; 32 dp on the speed button).
- The speed you end a hold on is saved; the next hold starts at that speed, and releasing returns to your normal speed.
- Not compiled or device-tested in the authoring environment.


## Version 9.0 — Final
- Lock: the locked state is now a solid white disc with a dark padlock (no red); unlocked stays a plain white padlock.
- Poco X3 NFC / MIUI 14: video draws edge to edge around the camera punch-hole and the controls are moved clear of it; edge strips are excluded from MIUI's swipe-back gesture so horizontal seeks and seekbar drags near the screen edge no longer exit the video; turning on Background play on a Xiaomi/Poco/Redmi phone shows how to exempt the app from MIUI's battery saver.
- Includes everything from 7.1–8.2.
- Not compiled or device-tested in the authoring environment.


## 10.0
- Voice Clarity retuned for 2x lectures: louder (more make-up gain), stronger consonant presence, a downward expander so pauses and room noise are not boosted, and a 1.5 ms look-ahead limiter (ceiling about -1 dBFS) instead of the old soft clipper, so loud speech stays clear without crackle.
- Changing Auto Skip Silence no longer drops the folder playlist or resets volume; it now shares one rebuild path with the decoder switch.
- If the HW decoder fails, the player switches to HW+ automatically and resumes.
- Buffering decided by time rather than byte thresholds for steadier playback.
- Seek bar and active-button blue made stronger; button circles slightly smaller.

## 10.1
- Remaining time now divides by the playback speed at every speed (2.5x => /2.5, 3x => /3); it previously over-divided above 2x.

## 10.2
- Remaining time refreshes immediately when the speed changes, at every speed (previously it waited for the next UI tick).

## 10.3
- Speed picker: no backing box; every speed is white text with a black outline, the current speed bold.
- Seek bar matched to MX Player (measured from a screenshot): #66BAFF line and thumb, about 3.5dp track, 15dp thumb.

## 10.4
- Active-button circles back to MX pale blue (#92C2FF).

## 10.5
- One shared pale blue (#6BAAFF, a little deeper than MX) for active-button circles, seek line, thumb and halo.

## 10.6
- Speed label ("1X", "2X") restyled like MX Player: about 17sp semi-bold; long labels like 0.25X auto-shrink to fit the button.

## 10.7
- Seek thumb no longer shows a halo while dragging.
- The speed button circle (2X) now has the same size as the other button circles.

## 10.8
- Seek preview no longer starts black: about a second after playback begins, a strip of up to 64 small thumbnails across the whole video is built in the background (coarse frames first, one every 120 ms so playback stays smooth) and the thumbnail source is opened ahead of time. The first touch shows the nearest strip frame at once; the exact frame replaces it as soon as it is decoded.

## 10.9
- Performance first (memory and storage are not a concern): thumbnail cache is now a quarter of the app heap, up to 240 background thumbnails across the video at 320 px (every 1 s cache buckets), warm-up starts 0.3 s after playback is ready, and `largeHeap` is on.
- Player buffers: 2 minutes minimum / 5 minutes maximum ahead, 2 minutes kept behind (foreground and background player), decided by time rather than bytes.
- New launcher icon: clock removed; blue progress ring with a thumb dot, play triangle and a 2x badge.

## 11.0 - Final: reliable notification controls
- Background play: the service now builds its own notification from the live player state (Previous / Play-Pause / Next / Stop) instead of relying on Media3's automatic one, so the buttons always match what is playing. Before, the automatic notification could show "paused" while audio was still playing, and could be replaced by a control-less placeholder when you left the app a second time.
- Pause/Play or Stop pressed in the notification while background play is still taking over is now respected (it used to be overridden when the hand-off finished, and Stop left the video playing in the app).
- Stop in the notification now really stops playback, in both foreground and background mode (the foreground version only removed the notification). Returning to the app after Stop opens paused at the spot where audio stopped.
- Play/Pause button follows the player's play state immediately (no wait while buffering) and refreshes on every change, not only on the 4x/s UI tick.
- If the screen is closed in the middle of the hand-off, the service takes over at once instead of staying silent.
- Notification services are no longer restarted empty by the system after the app is killed.
- Launcher icon: back to the earlier design (progress ring, play triangle, 2x badge) with the clock removed; ring and badge use the in-app blue #6BAAFF.
- Status-bar notification icon is now the app logo (ring + play) in a single-colour version, as Android requires for status-bar icons.
- Background notification shows a progress bar and the remaining time at the current speed, refreshed once a second while playing.
- Smoothness pass (no features added or removed): the on-screen clocks, speed label and brightness/volume read-outs are only rewritten when their value actually changes (they used to be reformatted and re-laid-out on every 250 ms tick or every touch event); brightness is only pushed to the window when it really changes; the screen UI is not redrawn while the app is not visible.
- Buffering for local files is now 60 s minimum / 180 s maximum ahead with a 60 s back buffer (was 120 s / 300 s / 120 s) in both players: a local file gains nothing from a larger buffer, and the old minimum could exhaust memory on high-bitrate video and crash the app.
- Not compiled or device-tested in the authoring environment.
