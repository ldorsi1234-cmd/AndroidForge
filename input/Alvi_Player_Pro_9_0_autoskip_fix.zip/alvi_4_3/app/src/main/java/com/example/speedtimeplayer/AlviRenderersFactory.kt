package com.example.speedtimeplayer

import android.content.Context
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.common.util.UnstableApi

/** Renderer configuration for Alvi Player. Silence skipping is controlled by
 * ExoPlayer.setSkipSilenceEnabled(), which uses Media3's default audio sink
 * and its built-in SilenceSkippingAudioProcessor. */
@UnstableApi
class AlviRenderersFactory(
    context: Context,
    decoderMode: Int,
    @Suppress("UNUSED_PARAMETER") silenceMode: Int
) : DefaultRenderersFactory(context) {

    init {
        setEnableDecoderFallback(decoderMode == 1)
        setExtensionRendererMode(
            when (decoderMode) {
                2 -> EXTENSION_RENDERER_MODE_PREFER
                1 -> EXTENSION_RENDERER_MODE_ON
                else -> EXTENSION_RENDERER_MODE_OFF
            }
        )
        // Useful on API 23–30 and harmless on newer Android versions.
        forceEnableMediaCodecAsynchronousQueueing()
    }
}
