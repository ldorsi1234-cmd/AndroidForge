package com.example.speedtimeplayer

import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.audio.AudioProcessorChain
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor

/**
 * Same job as Media3's DefaultAudioProcessorChain (silence skipper, then speed), If [forceSkip] is true the skipper is switched on here
 * regardless of what ExoPlayer signals.
 */
@UnstableApi
class AlviAudioChain(
    private val silence: SilenceSkippingAudioProcessor,
    private val forceSkip: Boolean
) : AudioProcessorChain {

    private val sonic = SonicAudioProcessor()

    @Volatile private var sampleRate = 44100
    private var lastSkipped = 0L
    private var totalSkippedFrames = 0L
    private val processors: Array<AudioProcessor> = arrayOf(RateTap { sampleRate = it }, silence, sonic)

    init {
        silence.setEnabled(forceSkip)
    }

    override fun getAudioProcessors(): Array<AudioProcessor> = processors

    override fun applyPlaybackParameters(playbackParameters: PlaybackParameters): PlaybackParameters {
        sonic.setSpeed(playbackParameters.speed)
        sonic.setPitch(playbackParameters.pitch)
        return playbackParameters
    }

    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean): Boolean {
        val on = forceSkip || skipSilenceEnabled
        silence.setEnabled(on)
        return on
    }

    override fun getMediaDuration(playoutDuration: Long): Long =
        if (sonic.isActive) sonic.getMediaDuration(playoutDuration) else playoutDuration

    // The skipper's own counter can restart (for example after a seek), so add up the
    // increases ourselves to get a running total of skipped audio.
    private fun accumulate() = synchronized(this) {
        val cur = silence.skippedFrames
        totalSkippedFrames += if (cur >= lastSkipped) cur - lastSkipped else cur
        lastSkipped = cur
    }

    override fun getSkippedOutputFrameCount(): Long {
        accumulate()
        return silence.skippedFrames
    }

    /** Total audio removed by silence skipping since this player was created, in ms. */
    fun savedMs(): Long {
        accumulate()
        return synchronized(this) { totalSkippedFrames * 1000L / sampleRate.coerceAtLeast(1) }
    }
}
