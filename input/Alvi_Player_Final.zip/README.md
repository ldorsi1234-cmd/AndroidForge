# Alvi Player

Alvi Player is a study-focused Android video player built with Kotlin, AndroidX and Media3/ExoPlayer 1.5.1.

## Main features

- Local video opening through Android's Storage Access Framework.
- `Open with` / `Share` video intents.
- Automatic reopening of the last video when the app starts without a new incoming video.
- Per-video resume position, saved periodically and on lifecycle changes.
- Playback history stored separately from resume positions.
- Clearing playback history does **not** delete `pos_<video>` resume data or `last_uri`.
- Independent clearing of saved resume positions.
- Playback speeds: **0.25×, 0.5×, 1×, 1.5×, 2×, 2.5×, 3×**.
- Fresh-install default speed: **2×**; saved user speed is preserved across updates.
- Configurable hold-to-speed gesture.
- Double-tap: left −10 s, right +10 s, center pause/resume.
- Horizontal swipe seeking.
- Left vertical swipe brightness and right vertical swipe media volume.
- Screen lock mode.
- Responsive seek bar with asynchronous-safe thumbnail extraction from the selected video URI.
- Fit, Stretch and Crop/Zoom display modes.
- Audio/subtitle track selection and external SRT/VTT/SSA/ASS subtitle loading where Media3 supports them.
- Optional loudness amplification up to 200% where the Android device supports `LoudnessEnhancer`.
- Decoder fallback and a single safe retry with audio disabled when a renderer/audio codec cannot be decoded.
- Immersive fullscreen and landscape playback.
- Screen stays awake while playback is actively running and may sleep when playback is stopped or the activity is left.

## Build requirements

- Android Studio / Android SDK with API 35.
- JDK 17.
- Gradle 8.9.
- Android Gradle Plugin 8.7.3.

The project intentionally keeps the existing package name and Media3 1.5.1 dependency set.

## GitHub Actions — phone-friendly APK build

The repository contains `.github/workflows/build-android.yml`.

1. Create a GitHub repository.
2. Upload the **contents of this project ZIP** so `build.gradle.kts`, `settings.gradle.kts`, `app/`, and `.github/` are at the repository root. Do not place them inside an extra project subfolder.
3. Open the repository's **Actions** tab.
4. Select **Build Alvi Player APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and its **Artifacts** section.
8. Download `Alvi-Player-debug-apk`, unzip it, and install `app-debug.apk` on the Android phone.

If GitHub's mobile web interface does not allow convenient multi-file/folder upload, use GitHub's web editor or a GitHub-compatible mobile Git client to upload the extracted project contents while preserving the directory structure.

## Important limitations

- Actual playback/decoder support still depends on the Android device and its hardware/software codecs. Media3 cannot guarantee every video/audio codec on every phone.
- Thumbnail extraction uses `MediaMetadataRetriever`; some protected, unusual, or unsupported files will not provide previews.
- Folder browsing lists video files directly inside the selected folder; it does not recursively crawl subfolders.
- External subtitle support depends on the subtitle format and Media3 decoder support.
- Audio delay is exposed as a setting but is not applied to decoder timing; it is intentionally not presented as a guaranteed A/V synchronization feature.
- Background playback service is not included because background playback was not a requirement.

## Package

`com.example.speedtimeplayer`

## Version

1.1 (debug build configuration)
