package com.example.speedtimeplayer

import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.audiofx.LoudnessEnhancer
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

@UnstableApi
class MainActivity : ComponentActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var speedButton: TextView
    private lateinit var voiceClarityButton: TextView
    private var voiceEnhancer: LoudnessEnhancer? = null
    private var voiceClarityEnabled = false
    private var selectedSpeed = 2f
    private var holdSpeed = 2f
    private lateinit var holdSpeedButton: TextView
    private var holdSpeedActive = false
    private var speedBeforeHold = 2f
    private lateinit var timeLeftText: TextView
    private lateinit var playPauseButton: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var volumeButton: TextView
    private lateinit var previewImage: ImageView
    private val previewExecutor = Executors.newSingleThreadExecutor()
    private var previewRequestId = 0L
    private val previewLock = Any()
    private var pendingPreviewPositionMs = 0L
    private var volumePercent = 100
    private lateinit var selectButton: TextView
    private lateinit var lockButton: TextView
    private lateinit var gestureHint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var controlsVisible = false
    private var locked = false
    private var userSeeking = false
    private var brightnessBeforeGesture = -1f
    private val speeds = listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 2.5f, 3f)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartPosition = 0L
    private var gestureMode = 0 // 0 unknown, 1 seek, 2 brightness, 3 volume
    private var fitMode = 0
    private val fitModes = listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FIT)
    private val fitModeNames = listOf("Fit", "Stretch", "Crop/Zoom", "Fit with black bars")
    private val historyPrefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }
    private var currentUri: Uri? = null
    private var resumePosition = 0L
    private var subtitleUri: Uri? = null
    private var audioDelayMs = 0

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            openVideo(uri, true)
        }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            attachSubtitle(uri)
        }
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
            historyPrefs.edit().putString("folder_uri", uri.toString()).apply()
            Toast.makeText(this, "Folder access saved. Use Folder videos in More to browse files.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemBars()
        buildUi()
        selectedSpeed = historyPrefs.getFloat("selected_speed", 2f)
        holdSpeed = historyPrefs.getFloat("hold_speed", 2f)
        fitMode = historyPrefs.getInt("fit_mode", 0).coerceIn(0, fitModes.lastIndex)
        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(this)
            .setEnableDecoderFallback(true)
        player = ExoPlayer.Builder(this, renderersFactory).build()
        playerView.player = player
        playerView.useController = false
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { updateUi() }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                updateScreenAwake(isPlaying)
                updateUi()
            }
            override fun onPlaybackStateChanged(playbackState: Int) { updateUi() }
            override fun onPlayerError(error: PlaybackException) {
                // If the device cannot decode an audio stream (commonly E-AC-3), retry video muted.
                if (error is androidx.media3.exoplayer.ExoPlaybackException && error.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER) {
                    try {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
                        player.prepare(); player.playWhenReady = true
                        Toast.makeText(this@MainActivity, "Audio codec unsupported on this device; retrying video without audio", Toast.LENGTH_LONG).show()
                    } catch (_: Exception) { Toast.makeText(this@MainActivity, "This video codec is not supported by the device", Toast.LENGTH_LONG).show() }
                } else Toast.makeText(this@MainActivity, "Cannot play this video format", Toast.LENGTH_LONG).show()
            }
        })
        playPauseButton.setOnClickListener { if (player.isPlaying) player.pause() else player.play(); updateUi(); showControlsTemporarily() }
        selectButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        lockButton.setOnClickListener {
            locked = !locked
            lockButton.text = if (locked) "Unlock" else "Lock"
            setControlsVisible(!locked)
            Toast.makeText(this, if (locked) "Screen locked" else "Screen unlocked", Toast.LENGTH_SHORT).show()
        }
        speedButton.setOnClickListener { showSpeedDialog() }
        holdSpeedButton.setOnClickListener { showHoldSpeedDialog() }
        voiceClarityButton.setOnClickListener { showVolumeDialog() }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true; cancelAutoHide(); previewImage.visibility = View.VISIBLE }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && player.duration > 0 && player.duration != C.TIME_UNSET) {
                    val target = player.duration * progress / 1000L
                    positionText.text = formatMs((target / player.playbackParameters.speed).toLong())
                    showSeekPreview(target)
                }
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (player.duration > 0 && player.duration != C.TIME_UNSET) player.seekTo(player.duration * (seekBar?.progress ?: 0) / 1000L)
                userSeeking = false
                previewImage.visibility = View.GONE
                showControlsTemporarily()
            }
        })
        installGestures()
        speedButton.text = "Speed ${speedLabel(selectedSpeed)}"
        holdSpeedButton.text = "Hold speed ${speedLabel(holdSpeed)}"
        playerView.resizeMode = fitModes[fitMode]
        val handledIncoming = handleIncomingIntent(intent)
        if (!handledIncoming) {
            val last = historyPrefs.getString("last_uri", null)
            if (!last.isNullOrBlank()) {
                try {
                    openVideo(Uri.parse(last), true)
                } catch (_: Exception) {
                    Toast.makeText(this, "The last video is no longer accessible", Toast.LENGTH_LONG).show()
                }
            }
        }
        handler.post(updateRunnable)
        setControlsVisible(false)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setBackgroundColor(0xD91A1A1A.toInt())
        }
        selectButton = button("Select video")
        topBar.addView(selectButton)
        speedButton = button("Speed 1×")
        topBar.addView(speedButton)
        holdSpeedButton = button("Hold speed 2×")
        topBar.addView(holdSpeedButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        voiceClarityButton = button("Volume 100%")
        topBar.addView(voiceClarityButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        val moreButton = button("More")
        topBar.addView(moreButton, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        moreButton.setOnClickListener { showMoreDialog() }
        lockButton = button("Lock")
        val lockParams = LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12) }
        topBar.addView(lockButton, lockParams)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(6), dp(12), dp(8))
            setBackgroundColor(0xD91A1A1A.toInt())
        }
        val seekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        positionText = label("0:00")
        durationText = label("0:00")
        seekBar = SeekBar(this).apply { max = 1000; progress = 0 }
        seekRow.addView(positionText, LinearLayout.LayoutParams(dp(56), -2))
        seekRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(34), 1f))
        seekRow.addView(durationText, LinearLayout.LayoutParams(dp(56), -2))
        bottomBar.addView(seekRow)
        val controlsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        playPauseButton = button("Ⅱ")
        controlsRow.addView(playPauseButton)
        timeLeftText = label("")
        timeLeftText.textSize = 15f
        timeLeftText.visibility = View.GONE
        timeLeftText.gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        timeLeftText.setPadding(dp(8), 0, dp(4), 0)
        controlsRow.addView(timeLeftText, LinearLayout.LayoutParams(0, dp(42), 1f))
        volumeButton = button("Volume 100%")
        volumeButton.setOnClickListener { showVolumeDialog() }
        controlsRow.addView(volumeButton)
        bottomBar.addView(controlsRow)
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        previewImage = ImageView(this).apply { visibility = View.GONE; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xEE111111.toInt()) }
        root.addView(previewImage, FrameLayout.LayoutParams(dp(180), dp(102), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(72) })
        gestureHint = TextView(this).apply {
            text = ""
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setBackgroundColor(0xB8000000.toInt())
            visibility = View.GONE
        }
        root.addView(gestureHint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(root)
    }


    /**
     * Fast ±10-second gesture seek. CLOSEST_SYNC lets Media3 land on a nearby
     * keyframe instead of waiting for an exact frame; this can reduce seek delay,
     * but exact zero-buffer seeking cannot be guaranteed for every file/source.
     */
    private fun seekFast(targetMs: Long) {
        val duration = player.duration
        val safeTarget = if (duration > 0 && duration != C.TIME_UNSET) targetMs.coerceAtMost(duration) else targetMs
        player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        player.seekTo(safeTarget)
        handler.removeCallbacks(restoreSeekParametersRunnable)
        handler.postDelayed(restoreSeekParametersRunnable, 700L)
    }

    private val restoreSeekParametersRunnable = Runnable {
        if (::player.isInitialized) player.setSeekParameters(SeekParameters.DEFAULT)
    }

    private fun installGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                if (locked || player.mediaItemCount == 0 || holdSpeedActive) return
                holdSpeedActive = true
                speedBeforeHold = player.playbackParameters.speed
                player.setPlaybackSpeed(holdSpeed)
                showGestureHint("${holdSpeed}× — release to restore")
                cancelAutoHide()
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    lockButton.visibility = View.VISIBLE
                    handler.postDelayed({ if (locked) lockButton.visibility = View.GONE }, 1600)
                } else toggleControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (e.x < root.width * 0.35f) seekFast(max(0L, player.currentPosition - 10_000L))
                else if (e.x > root.width * 0.65f) seekFast(player.currentPosition + 10_000L)
                else if (player.isPlaying) player.pause() else player.play()
                // Double-tap actions (pause / ±10 seconds) must not reveal the full UI.
                return true
            }
        })
        playerView.setOnTouchListener { _, event ->
            detector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureStartX = event.x; gestureStartY = event.y
                    gestureStartPosition = player.currentPosition
                    gestureMode = 0
                    brightnessBeforeGesture = window.attributes.screenBrightness
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (locked) return@setOnTouchListener true
                    val dx = event.x - gestureStartX
                    val dy = event.y - gestureStartY
                    if (gestureMode == 0 && (abs(dx) > dp(18) || abs(dy) > dp(18))) {
                        gestureMode = if (abs(dx) > abs(dy)) 1 else if (gestureStartX < root.width / 2f) 2 else 3
                        cancelAutoHide()
                    }
                    when (gestureMode) {
                        1 -> {
                            val delta = (dx / root.width * 120_000L).toLong()
                            val target = max(0L, gestureStartPosition + delta)
                            player.seekTo(if (player.duration > 0 && player.duration != C.TIME_UNSET) target.coerceAtMost(player.duration) else target)
                            showGestureHint("${if (delta >= 0) "+" else "−"}${formatMs(abs(delta))}")
                        }
                        2 -> {
                            val value = (0.75f - dy / root.height).coerceIn(0.05f, 1f)
                            val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                            showGestureHint("Brightness ${(value * 100).roundToInt()}%")
                        }
                        3 -> {
                            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                            val maxVol = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                            val current = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                            val change = (-dy / root.height * maxVol * 2).roundToInt()
                            audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (current + change).coerceIn(0, maxVol), 0)
                            showGestureHint("Volume ${(audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / maxVol)}%")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (holdSpeedActive) {
                        holdSpeedActive = false
                        player.setPlaybackSpeed(speedBeforeHold)
                        gestureHint.visibility = View.GONE
                        updateUi()
                    }
                    if (gestureMode != 0) {
                        gestureHint.visibility = View.GONE
                        showControlsTemporarily()
                    }
                    gestureMode = 0
                    true
                }
                else -> true
            }
        }
    }

    private fun handleIncomingIntent(incoming: Intent?): Boolean {
        val uri = incoming?.data ?: if (android.os.Build.VERSION.SDK_INT >= 33) {
            incoming?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") incoming?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (uri == null) return false
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        openVideo(uri, true)
        return true
    }

    private fun openVideo(uri: Uri, resume: Boolean) {
        saveCurrentProgress()
        currentUri = uri
        val item = MediaItem.fromUri(uri)
        player.setMediaItem(item)
        player.prepare()
        val saved = if (resume) historyPrefs.getLong("pos_${uri}", 0L) else 0L
        player.seekTo(saved)
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        historyPrefs.edit().putString("last_uri", uri.toString())
            .putString("history_${System.currentTimeMillis()}", uri.toString())
            .putString("name_${uri}", displayName(uri)).apply()
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateUi()
    }

    private fun saveCurrentProgress() {
        if (!::player.isInitialized) return
        val uri = currentUri ?: return
        historyPrefs.edit().putLong("pos_${uri}", max(0L, player.currentPosition))
            .putString("name_${uri}", displayName(uri)).putString("last_uri", uri.toString()).apply()
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "Video"
        try { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (_: Exception) { }
        return name
    }

    private fun attachSubtitle(uri: Uri) {
        val video = currentUri
        if (video == null) { Toast.makeText(this, "Open a video first", Toast.LENGTH_SHORT).show(); return }
        subtitleUri = uri
        val subtitle = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(when (uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase(Locale.ROOT)) {
                "srt" -> MimeTypes.APPLICATION_SUBRIP
                "vtt" -> MimeTypes.TEXT_VTT
                "ssa", "ass" -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            })
            .setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        player.setMediaItem(MediaItem.Builder().setUri(video).setSubtitleConfigurations(listOf(subtitle)).build())
        player.prepare(); player.seekTo(pos); player.playWhenReady = wasPlaying
        Toast.makeText(this, "Subtitle loaded", Toast.LENGTH_SHORT).show()
    }

    private val previewRunnable = Runnable {
        val uri = currentUri ?: return@Runnable
        val requestId = ++previewRequestId
        val target = pendingPreviewPositionMs
        previewExecutor.execute {
            var retriever: MediaMetadataRetriever? = null
            try {
                retriever = MediaMetadataRetriever()
                contentResolver.openFileDescriptor(uri, "r")?.use { retriever!!.setDataSource(it.fileDescriptor) }
                    ?: throw IllegalStateException("Unable to open video")
                val bitmap = retriever!!.getFrameAtTime(target * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                handler.post {
                    if (requestId == previewRequestId && userSeeking && bitmap != null) {
                        previewImage.setImageBitmap(bitmap)
                        previewImage.visibility = View.VISIBLE
                    }
                }
            } catch (_: Exception) {
                handler.post { if (requestId == previewRequestId) previewImage.visibility = View.GONE }
            } finally {
                try { retriever?.release() } catch (_: Exception) { }
            }
        }
    }

    private fun showSeekPreview(positionMs: Long) {
        pendingPreviewPositionMs = positionMs.coerceAtLeast(0L)
        handler.removeCallbacks(previewRunnable)
        handler.postDelayed(previewRunnable, 90L)
    }

    private fun showMoreDialog() {
        val options = arrayOf("Resume current video", "Playback history", "Delete playback history", "Clear saved resume positions", "Load subtitle file", "Audio / subtitle tracks", "Screen fit: ${fitModeNames[fitMode]}", "Audio delay: ${audioDelayMs} ms", "Choose video folder", "Videos in saved folder", "Background audio help")
        AlertDialog.Builder(this).setTitle("Alvi Player")
            .setItems(options) { _, which -> when (which) {
                0 -> { val uri = currentUri; if (uri != null) player.seekTo(historyPrefs.getLong("pos_${uri}", player.currentPosition)) else Toast.makeText(this, "No current video", Toast.LENGTH_SHORT).show() }
                1 -> showHistoryDialog()
                2 -> confirmDeleteHistory()
                3 -> confirmClearResumePositions()
                4 -> pickSubtitle.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "application/octet-stream"))
                5 -> showTrackDialog()
                6 -> { fitMode = (fitMode + 1) % fitModes.size; playerView.resizeMode = fitModes[fitMode]; historyPrefs.edit().putInt("fit_mode", fitMode).apply(); Toast.makeText(this, fitModeNames[fitMode], Toast.LENGTH_SHORT).show() }
                7 -> showAudioDelayDialog()
                8 -> pickFolder.launch(null)
                9 -> showFolderVideos()
                10 -> Toast.makeText(this, "Continuous background playback requires a media playback service; this build keeps playback in the player activity.", Toast.LENGTH_LONG).show()
            } }.show()
    }

    private fun confirmDeleteHistory() {
        AlertDialog.Builder(this).setTitle("Delete playback history?")
            .setMessage("This removes only the playback history list. Saved resume positions and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val editor = historyPrefs.edit()
                historyPrefs.all.keys.filter { it.startsWith("history_") || it.startsWith("name_") }.forEach { editor.remove(it) }
                editor.apply()
                Toast.makeText(this, "Playback history deleted", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun confirmClearResumePositions() {
        AlertDialog.Builder(this).setTitle("Clear saved resume positions?")
            .setMessage("This removes saved playback positions only. Playback history and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                historyPrefs.edit().apply {
                    historyPrefs.all.keys.filter { it.startsWith("pos_") }.forEach { remove(it) }
                    apply()
                }
                Toast.makeText(this, "Saved resume positions cleared", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showHistoryDialog() {
        val history = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }
            .distinctBy { it.toString() }
            .take(30)
        if (history.isEmpty()) {
            // Backward compatibility with older builds that stored name_<uri>.
            val legacy = historyPrefs.all.keys.filter { it.startsWith("name_") }.map { Uri.parse(it.removePrefix("name_")) }.distinct().take(30)
            if (legacy.isEmpty()) { Toast.makeText(this, "No playback history yet", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("Playback history").setItems(legacy.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(legacy[index], true) }.setNegativeButton("Close", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Playback history")
            .setItems(history.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(history[index], true) }
            .setNegativeButton("Close", null).show()
    }

    private fun showTrackDialog() {
        if (!::player.isInitialized) return
        val tracks = player.currentTracks.groups
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        for (group in tracks) {
            val type = group.type
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val typeName = if (type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                val language = format.language ?: "und"
                options.add("$typeName · $language${if (format.label != null) " · ${format.label}" else ""}")
                actions.add {
                    val builder = player.trackSelectionParameters.buildUpon()
                    builder.setTrackTypeDisabled(type, false)
                    builder.setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(i)))
                    player.trackSelectionParameters = builder.build()
                }
            }
        }
        if (options.isEmpty()) { Toast.makeText(this, "No alternate audio or subtitle tracks in this video", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Available tracks").setItems(options.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNeutralButton("Disable subtitles") { _, _ -> player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }
            .setNegativeButton("Close", null).show()
    }

    private fun showAudioDelayDialog() {
        val values = intArrayOf(-500, -250, -100, 0, 100, 250, 500)
        val labels = values.map { if (it > 0) "+${it} ms" else "$it ms" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Audio delay")
            .setSingleChoiceItems(labels, values.indexOf(audioDelayMs).coerceAtLeast(0)) { dialog, which ->
                audioDelayMs = values[which]
                Toast.makeText(this, "Delay setting saved as ${audioDelayMs} ms. Actual synchronization adjustment depends on device/decoder support.", Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showFolderVideos() {
        val folder = historyPrefs.getString("folder_uri", null)?.let(Uri::parse)
        if (folder == null) { Toast.makeText(this, "Choose a folder first", Toast.LENGTH_SHORT).show(); pickFolder.launch(null); return }
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, DocumentsContract.getTreeDocumentId(folder))
            val found = mutableListOf<Pair<String, Uri>>()
            contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0); val name = c.getString(1) ?: "Video"; val mime = c.getString(2) ?: ""
                    if (mime.startsWith("video/")) found.add(name to DocumentsContract.buildDocumentUriUsingTree(folder, id))
                }
            }
            if (found.isEmpty()) { Toast.makeText(this, "No videos found directly in this folder", Toast.LENGTH_LONG).show(); return }
            AlertDialog.Builder(this).setTitle("Folder videos").setItems(found.map { it.first }.toTypedArray()) { _, index -> openVideo(found[index].second, true) }.show()
        } catch (_: Exception) { Toast.makeText(this, "Could not read this folder", Toast.LENGTH_SHORT).show() }
    }

    private fun speedLabel(speed: Float) = if (speed % 1f == 0f) "${speed.toInt()}×" else "${speed}×"

    private fun showHoldSpeedDialog() {
        val labels = speeds.map { if (it % 1f == 0f) "${it.toInt()}×" else "${it}×" }.toTypedArray()
        val selected = speeds.indexOf(holdSpeed).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Speed while holding the screen")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                holdSpeed = speeds[which]
                historyPrefs.edit().putFloat("hold_speed", holdSpeed).apply()
                holdSpeedButton.text = "Hold speed ${labels[which]}"
                dialog.dismiss()
                showControlsTemporarily()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSpeedDialog() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        val dialog = AlertDialog.Builder(this).setTitle("Playback speed").setView(scroll).setNegativeButton("Close", null).create()
        speeds.forEach { value ->
            val b = button("${value}×")
            b.setPadding(dp(12), dp(12), dp(12), dp(12))
            if (value == selectedSpeed) b.setBackgroundColor(0xFF1769AA.toInt())
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            b.setOnClickListener {
                selectedSpeed = value
                historyPrefs.edit().putFloat("selected_speed", selectedSpeed).apply()
                if (::player.isInitialized) player.setPlaybackSpeed(selectedSpeed)
                speedButton.text = "Speed ${speedLabel(value)}"
                updateUi(); dialog.dismiss(); showControlsTemporarily()
            }
        }
        dialog.show()
    }

    private fun showVolumeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(8)) }
        val label = TextView(this).apply { text = "Volume: ${volumePercent}%"; setTextColor(Color.WHITE); textSize = 16f }
        val bar = SeekBar(this).apply { max = 200; progress = volumePercent }
        box.addView(label); box.addView(bar)
        val dialog = AlertDialog.Builder(this).setTitle("Amplified volume (up to 200%)").setView(box).setPositiveButton("Done", null).create()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                volumePercent = progress.coerceIn(0, 200); label.text = "Volume: ${volumePercent}%"
                try {
                    if (player.audioSessionId != 0) {
                        voiceEnhancer?.release()
                        voiceEnhancer = LoudnessEnhancer(player.audioSessionId).apply {
                            setTargetGain(if (volumePercent <= 100) 0 else ((volumePercent / 100.0).let { 20000.0 * kotlin.math.log10(it) }).roundToInt())
                            enabled = true
                        }
                        player.volume = (volumePercent.coerceAtMost(100) / 100f)
                    }
                } catch (_: Exception) { Toast.makeText(this@MainActivity, "Volume amplification is not supported on this device", Toast.LENGTH_SHORT).show() }
                voiceClarityButton.text = "Volume ${volumePercent}%"; volumeButton.text = "Volume ${volumePercent}%"
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        dialog.show()
    }

    private fun toggleVoiceClarity() {
        if (!::player.isInitialized || player.audioSessionId == 0) {
            Toast.makeText(this, "Play a video first to enable voice clarity", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            if (!voiceClarityEnabled) {
                voiceEnhancer?.release()
                voiceEnhancer = LoudnessEnhancer(player.audioSessionId).apply { setTargetGain(500); enabled = true }
                voiceClarityEnabled = true
                voiceClarityButton.text = "Voice clarity: On"
                Toast.makeText(this, "Voice clarity enabled (speech loudness boost)", Toast.LENGTH_SHORT).show()
            } else {
                voiceEnhancer?.enabled = false
                voiceEnhancer?.release()
                voiceEnhancer = null
                voiceClarityEnabled = false
                voiceClarityButton.text = "Voice clarity: Off"
            }
        } catch (_: Exception) {
            voiceClarityEnabled = false
            voiceClarityButton.text = "Voice clarity: Off"
            Toast.makeText(this, "Voice clarity is not supported on this device", Toast.LENGTH_LONG).show()
        }
        showControlsTemporarily()
    }

    private fun showGestureHint(text: String) {
        gestureHint.text = text
        gestureHint.visibility = View.VISIBLE
    }

    private fun toggleControls() = setControlsVisible(!controlsVisible)

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible && !locked
        topBar.visibility = if (controlsVisible) View.VISIBLE else View.GONE
        bottomBar.visibility = if (controlsVisible) View.VISIBLE else View.GONE
        if (player.mediaItemCount == 0) {
            topBar.visibility = View.VISIBLE
            selectButton.visibility = View.VISIBLE
            speedButton.visibility = View.GONE
            voiceClarityButton.visibility = View.GONE
            lockButton.visibility = View.GONE
            bottomBar.visibility = View.GONE
        } else {
            selectButton.visibility = View.GONE
            speedButton.visibility = if (controlsVisible) View.VISIBLE else View.GONE
            voiceClarityButton.visibility = if (controlsVisible) View.VISIBLE else View.GONE
            lockButton.visibility = if (controlsVisible || locked) View.VISIBLE else View.GONE
        }
        if (controlsVisible) scheduleAutoHide() else cancelAutoHide()
    }

    private fun showControlsTemporarily() { setControlsVisible(true) }
    private fun scheduleAutoHide() {
        cancelAutoHide()
        handler.postDelayed(autoHideRunnable, 3500)
    }
    private fun cancelAutoHide() { handler.removeCallbacks(autoHideRunnable) }
    private val autoHideRunnable = Runnable { if (!userSeeking && !locked && player.mediaItemCount > 0) setControlsVisible(false) }

    private fun updateUi() {
        if (!::player.isInitialized) return
        val duration = player.duration
        val current = max(0L, player.currentPosition)
        val validDuration = duration > 0 && duration != C.TIME_UNSET
        val remaining = if (validDuration) max(0L, duration - current) else C.TIME_UNSET
        val actualRemaining = if (remaining != C.TIME_UNSET) (remaining / player.playbackParameters.speed).toLong() else C.TIME_UNSET
        timeLeftText.text = ""
        positionText.text = formatMs((current / player.playbackParameters.speed).toLong())
        durationText.text = formatMs(actualRemaining)
        positionText.contentDescription = "Viewing time elapsed ${formatMs((current / player.playbackParameters.speed).toLong())}; video position ${formatMs(current)}"
        durationText.contentDescription = "Viewing time remaining ${formatMs(actualRemaining)}; video content remaining ${formatMs(remaining)}"
        if (!userSeeking) seekBar.progress = if (validDuration) (current * 1000L / duration).toInt().coerceIn(0, 1000) else 0
        playPauseButton.text = if (player.isPlaying) "Ⅱ" else "▶"
        if (validDuration) {
            val finish = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(System.currentTimeMillis() + actualRemaining))
            durationText.contentDescription = "Actual time left ${formatMs(actualRemaining)}, estimated finish $finish"
        }
    }

    private val updateRunnable = object : Runnable {
        override fun run() { updateUi(); saveCurrentProgress(); handler.postDelayed(this, 1000) }
    }

    private fun button(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 14f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8))
        setBackgroundColor(0xFF303030.toInt()); isClickable = true
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 12f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
    }
    private fun formatMs(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0L) return "—"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
    private fun updateScreenAwake(isPlaying: Boolean) {
        if (isPlaying) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onPause() {
        saveCurrentProgress()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onDestroy() {
        saveCurrentProgress()
        handler.removeCallbacks(updateRunnable)
        cancelAutoHide()
        if (holdSpeedActive && ::player.isInitialized) {
            holdSpeedActive = false
            player.setPlaybackSpeed(speedBeforeHold)
        }
        voiceEnhancer?.release()
        voiceEnhancer = null
        handler.removeCallbacks(previewRunnable)
        previewRequestId++
        previewExecutor.shutdownNow()
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
