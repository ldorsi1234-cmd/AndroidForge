# Speed Time Player (Android)

Native Android source project for a local video player with speed-adjusted remaining time.

## Features
- Pick a local video using Android's system document picker.
- Playback speeds: 1×, 1.5×, 2×, 2.5×, 3×.
- Landscape immersive playback.
- Tap the player to show adjusted remaining time for 3 seconds; tap again to hide it.
- Actual remaining time, original video remaining time, estimated finish time, and playback speed.
- Media3/ExoPlayer playback controls for pause, resume, and seeking.

## Build the APK
This environment did not include the Android SDK or Gradle, so an APK was not compiled here. To build it:
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Allow Gradle sync and install any prompted SDK components.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your phone and install it. Android may ask you to allow installation from that source.

## Notes
- Requires Android 6.0 or newer (minSdk 23).
- Common formats supported by the device's Media3 decoders should play.
- The app requests landscape orientation and hides system bars during playback.
