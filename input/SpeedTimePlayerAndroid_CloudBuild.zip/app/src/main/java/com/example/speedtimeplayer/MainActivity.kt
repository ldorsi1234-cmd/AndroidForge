package com.example.speedtimeplayer

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@UnstableApi
class MainActivity : ComponentActivity() {
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var overlay: TextView
    private lateinit var statusText: TextView
    private lateinit var speedSpinner: Spinner
    private lateinit var pickButton: TextView
    private lateinit var statsPanel: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var overlayVisible = false
    private var hideRunnable: Runnable? = null
    private val speeds = listOf(1f, 1.5f, 2f, 2.5f, 3f)

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = true
            statusText.text = "Playing"
            updateStats()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()
        buildUi()
        player = ExoPlayer.Builder(this).build()
        playerView.player = player
        playerView.useController = true
        playerView.controllerAutoShow = true
        playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                statusText.text = if (isPlaying) "Playing" else "Paused"
                updateStats()
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                updateStats()
            }
            override fun onPlayerError(error: PlaybackException) {
                statusText.text = "Cannot play this file format"
            }
        })
        playerView.setOnClickListener { toggleCountdown() }
        handler.post(updateRunnable)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
        }

        playerView = PlayerView(this).apply {
            useController = true
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0x99000000.toInt())
        }
        pickButton = TextView(this).apply {
            text = "Select video"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFF263445.toInt())
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        }
        topBar.addView(pickButton)

        speedSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                speeds.map { if (it % 1f == 0f) "${it.toInt()}×" else "${it}×" }
            )
            setSelection(0)
            setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (::player.isInitialized) {
                        player.setPlaybackSpeed(speeds[position])
                        updateStats()
                    }
                }
            })
        }
        val speedLabel = TextView(this).apply {
            text = "Speed"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), 0, dp(4), 0)
        }
        topBar.addView(speedLabel)
        topBar.addView(speedSpinner)

        statusText = TextView(this).apply {
            text = "Choose a video"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), 0, 0, 0)
        }
        topBar.addView(statusText)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP))

        statsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setBackgroundColor(0xAA000000.toInt())
        }
        root.addView(statsPanel, FrameLayout.LayoutParams(-1, dp(52), Gravity.BOTTOM))
        overlay = TextView(this).apply {
            text = "—"
            textSize = 38f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(10), dp(22), dp(10))
            setBackgroundColor(0xB8000000.toInt())
            visibility = View.GONE
            isClickable = false
            isFocusable = false
        }
        root.addView(overlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        ))

        setContentView(root)
        updateStats()
    }

    private fun makeStat(label: String, value: String): TextView {
        return TextView(this).apply {
            text = "$label\n$value"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            maxLines = 2
        }
    }

    private fun updateStats() {
        if (!::statsPanel.isInitialized || !::player.isInitialized) return
        statsPanel.removeAllViews()
        val duration = player.duration
        val current = max(0L, player.currentPosition)
        val left = if (duration > 0L && duration != androidx.media3.common.C.TIME_UNSET) max(0L, duration - current) else androidx.media3.common.C.TIME_UNSET
        val speed = player.playbackParameters.speed
        val actual = if (left != androidx.media3.common.C.TIME_UNSET) (left / speed).toLong() else androidx.media3.common.C.TIME_UNSET
        val finish = if (actual != androidx.media3.common.C.TIME_UNSET) {
            java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date(System.currentTimeMillis() + actual))
        } else "—"
        statsPanel.addView(makeStat("ACTUAL TIME LEFT", formatMs(actual)), LinearLayout.LayoutParams(0, -1, 1f))
        statsPanel.addView(makeStat("FINISH TIME", finish), LinearLayout.LayoutParams(0, -1, 1f))
        statsPanel.addView(makeStat("VIDEO LEFT", formatMs(left)), LinearLayout.LayoutParams(0, -1, 1f))
        statsPanel.addView(makeStat("SPEED", "${speed}×"), LinearLayout.LayoutParams(0, -1, 1f))
        if (overlayVisible) overlay.text = formatMs(actual)
    }

    private fun toggleCountdown() {
        if (overlayVisible) {
            hideCountdown()
        } else {
            overlayVisible = true
            overlay.text = currentActualRemaining()
            overlay.visibility = View.VISIBLE
            hideRunnable?.let { handler.removeCallbacks(it) }
            hideRunnable = Runnable { hideCountdown() }
            handler.postDelayed(hideRunnable!!, 3000)
        }
    }

    private fun currentActualRemaining(): String {
        if (!::player.isInitialized) return "—"
        val duration = player.duration
        if (duration == androidx.media3.common.C.TIME_UNSET || duration <= 0L) return "—"
        val left = max(0L, duration - player.currentPosition)
        return formatMs((left / player.playbackParameters.speed).toLong())
    }

    private fun hideCountdown() {
        overlayVisible = false
        overlay.visibility = View.GONE
        hideRunnable?.let { handler.removeCallbacks(it) }
        hideRunnable = null
    }

    private val updateRunnable = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 500)
        }
    }

    private fun formatMs(ms: Long): String {
        if (ms == androidx.media3.common.C.TIME_UNSET || ms < 0L) return "—"
        val totalSeconds = (ms / 1000.0).roundToInt()
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        handler.removeCallbacks(updateRunnable)
        hideRunnable?.let { handler.removeCallbacks(it) }
        if (::player.isInitialized) {
            player.release()
        }
        super.onDestroy()
    }
}
