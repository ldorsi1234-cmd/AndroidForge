package com.example.speedtimeplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.MediaStyleNotificationHelper
import kotlin.math.abs

/**
 * Background (audio-only) playback.
 *
 * 11.0: this service now owns its notification instead of relying on Media3's automatic one.
 * The notification is rebuilt from the real player state on every change, so Play/Pause, Previous/Next
 * and Stop always match what is actually happening, including during the screen-to-background hand-off.
 */
@UnstableApi
class BackgroundPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private var earphoneControls: EarphoneControls? = null
    private val prefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }

    private var foregroundStarted = false
    private var stopping = false
    private var lastTitle = "Alvi Player"
    private var sessionPendingIntent: PendingIntent? = null
    private val handler = Handler(Looper.getMainLooper())
    private var tickScheduled = false
    private val tick = Runnable { tickScheduled = false; refreshNotification() }

    private fun formatTime(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        val h = total / 3600; val m = (total % 3600) / 60; val sec = total % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    /**
     * True while the screen player is still playing and this player is only preparing (hand-off in progress).
     * The notification shows "playing" during this time, because audio really is playing.
     */
    @Volatile private var deferredStart = false
    /** The user pressed Pause/Play in the notification while the hand-off was still in progress. */
    @Volatile private var userTookControl = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        createChannel()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val decoderMode = prefs.getInt("decoder_mode", 1).coerceIn(0, 2)
        val silenceMode = prefs.getInt("auto_skip_mode", if (prefs.getBoolean("auto_skip_silence", false)) 1 else 0).coerceIn(0, 2)
        val factory = AlviRenderersFactory(this, decoderMode, silenceMode)
        player = ExoPlayer.Builder(this, factory)
            .setLoadControl(DefaultLoadControl.Builder()
            // Buffer more ahead and restart quickly after seeks: smoother 2x lecture playback, fewer stalls.
            .setBufferDurationsMs(60_000, 180_000, 300, 1_000)
            // Keep 1 minute already played so skipping back needs no re-read or re-decode wait.
            .setBackBuffer(60_000, true)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build())
            .setSkipSilenceEnabled(silenceMode > 0)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            // Keeps the CPU awake while playing with the screen off, so phones with aggressive battery saving do not stutter.
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
            .also {
                it.repeatMode = Player.REPEAT_MODE_OFF
                // Audio only: no video decoding in the background means a faster start and less work.
                it.trackSelectionParameters = it.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
            }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 1201, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        sessionPendingIntent = pendingIntent
        // The session sees a wrapper without seek commands or duration, so Android 13+ draws no seek bar.
        // The real player (and the in-app controls) are untouched.
        val noSeekPlayer = object : androidx.media3.common.ForwardingPlayer(player!!) {
            private val seekCommands = intArrayOf(
                Player.COMMAND_SEEK_IN_CURRENT_MEDIA_ITEM,
                Player.COMMAND_SEEK_TO_DEFAULT_POSITION,
                Player.COMMAND_SEEK_TO_PREVIOUS,
                Player.COMMAND_SEEK_TO_NEXT,
                Player.COMMAND_SEEK_BACK,
                Player.COMMAND_SEEK_FORWARD
            )
            override fun getAvailableCommands(): Player.Commands =
                super.getAvailableCommands().buildUpon().removeAll(*seekCommands).build()
            override fun isCommandAvailable(command: Int): Boolean =
                command !in seekCommands && super.isCommandAvailable(command)
            override fun getDuration(): Long = C.TIME_UNSET
        }
        // Earphone / Bluetooth / car buttons (same behavior as in the app); read from prefs so the menu toggle applies live.
        val controls = EarphoneControls(
            player = { player },
            seekAmountMs = { prefs.getInt("seek_seconds", 10).coerceIn(5, 30) * 1000L },
            enabled = { prefs.getBoolean("earphone_controls", true) }
        )
        earphoneControls = controls
        mediaSession = MediaSession.Builder(this, noSeekPlayer)
            .setSessionActivity(pendingIntent)
            .setCallback(controls)
            .build()

        // Keep the notification in step with the player: any state change rebuilds it from the real state.
        player!!.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = refreshNotification()
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = refreshNotification()
            override fun onPlaybackStateChanged(playbackState: Int) = refreshNotification()
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refreshNotification()
        })

        // No MediaController ever connects to this session, so register it ourselves.
        try { addSession(mediaSession!!) } catch (_: Exception) {}
    }

    /** Media3 would post its own notification here; this service posts its own (see refreshNotification). */
    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        if (foregroundStarted) refreshNotification()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Background playback", NotificationManager.IMPORTANCE_LOW).apply {
                        description = "Playback controls while Alvi Player plays in the background"
                        setShowBadge(false)
                    }
                )
            }
        }
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getService(
            this, requestCode,
            Intent(this, BackgroundPlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun isShownPlaying(p: ExoPlayer): Boolean = deferredStart ||
        (p.playWhenReady && p.playbackState != Player.STATE_ENDED && p.playbackState != Player.STATE_IDLE)

    private fun buildNotification(p: ExoPlayer, session: MediaSession): Notification {
        val playing = isShownPlaying(p)
        val title = p.currentMediaItem?.mediaMetadata?.title?.toString()?.takeIf { it.isNotBlank() } ?: lastTitle
        val hasQueue = p.mediaItemCount > 1

        // Remaining wall-clock time at the current speed (same rule as the in-app timer); not shown during hand-off.
        val duration = p.duration
        val known = !deferredStart && duration > 0L && duration != C.TIME_UNSET
        val position = p.currentPosition.coerceAtLeast(0L)
        val speed = p.playbackParameters.speed.coerceAtLeast(0.1f)
        val statusText = (if (playing) "Playing" else "Paused") +
            if (known) " \u00b7 -" + formatTime(((duration - position).coerceAtLeast(0L) / speed).toLong()) else ""

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_alvi)
            .setContentTitle(title)
            .setContentText(statusText)
            .setOngoing(playing)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(sessionPendingIntent)

        val compact = ArrayList<Int>()
        var index = 0
        if (hasQueue) {
            builder.addAction(android.R.drawable.ic_media_previous, "Previous", actionIntent(ACTION_PREV, 1301))
            compact.add(index++)
        }
        builder.addAction(
            if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
            if (playing) "Pause" else "Play",
            actionIntent(ACTION_TOGGLE, 1302)
        )
        compact.add(index++)
        if (hasQueue) {
            builder.addAction(android.R.drawable.ic_media_next, "Next", actionIntent(ACTION_NEXT, 1303))
            compact.add(index++)
        }
        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", actionIntent(ACTION_STOP, 1304))
        if (!hasQueue) compact.add(index) // two buttons: Play/Pause and Stop

        // No seek bar in the notification: only Play/Pause and Stop are shown.

        builder.setStyle(
            MediaStyleNotificationHelper.MediaStyle(session)
                .setShowActionsInCompactView(*compact.toIntArray())
        )
        return builder.build()
    }

    /** Rebuilds the notification from the live player state. Main thread only. */
    private fun refreshNotification(forceForeground: Boolean = false) {
        if (stopping) return
        val p = player ?: return
        val session = mediaSession ?: return
        val notification = try { buildNotification(p, session) } catch (_: Exception) { return }
        // While playing, refresh once a second so the bar and the remaining time move.
        if (isShownPlaying(p) && !tickScheduled) { tickScheduled = true; handler.postDelayed(tick, 1000L) }
        if (forceForeground || !foregroundStarted) {
            try {
                ServiceCompat.startForeground(
                    this, NOTIFICATION_ID, notification,
                    if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
                )
                foregroundStarted = true
            } catch (_: Exception) {
                // If this is refused the service still runs; the activity keeps its own player in that case.
            }
        } else {
            try {
                getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification)
            } catch (_: Exception) {}
        }
    }

    private fun togglePlayback() {
        val p = player ?: return
        when {
            // Hand-off still running: the notification showed "playing" (the screen player is), so a tap means pause.
            deferredStart -> {
                userTookControl = true
                deferredStart = false
                p.playWhenReady = false
            }
            p.playbackState == Player.STATE_ENDED -> {
                p.seekToDefaultPosition()
                p.playWhenReady = true
            }
            else -> {
                if (p.playbackState == Player.STATE_IDLE && p.mediaItemCount > 0) p.prepare()
                p.playWhenReady = !p.playWhenReady
            }
        }
        refreshNotification()
    }

    @Suppress("DEPRECATION")
    private fun stopPlaybackAndService() {
        val p = player
        if (p != null) {
            if (deferredStart) {
                // The screen player is still playing: tell it to stop too.
                stopRequested = true
            } else {
                val uri = p.currentMediaItem?.localConfiguration?.uri
                if (uri != null) {
                    prefs.edit()
                        .putString(KEY_STOP_URI, uri.toString())
                        .putLong(KEY_STOP_POS, p.currentPosition.coerceAtLeast(0L))
                        .apply()
                }
            }
            p.playWhenReady = false
        }
        deferredStart = false
        stopping = true
        prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
        stopForeground(true)
        stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent == null) {
            // Restarted by the system with nothing to play: satisfy the foreground rule, then stop.
            refreshNotification(forceForeground = true)
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_STOP -> { stopPlaybackAndService(); return START_NOT_STICKY }
            ACTION_TOGGLE -> { togglePlayback(); return START_NOT_STICKY }
            ACTION_PREV -> { if (!deferredStart) player?.seekToPreviousMediaItem(); refreshNotification(); return START_NOT_STICKY }
            ACTION_NEXT -> { if (!deferredStart) player?.seekToNextMediaItem(); refreshNotification(); return START_NOT_STICKY }
        }

        intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() }?.let { lastTitle = it }

        val uriString = intent.getStringExtra(EXTRA_URI)
        if (!uriString.isNullOrBlank()) {
            val uri = Uri.parse(uriString)
            val position = intent.getLongExtra(EXTRA_POSITION, 0L).coerceAtLeast(0L)
            val speed = intent.getFloatExtra(EXTRA_SPEED, 1f).coerceIn(0.1f, 4f)
            val title = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "Alvi Player"
            val repeat = intent.getIntExtra(EXTRA_REPEAT, Player.REPEAT_MODE_OFF).coerceIn(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL)
            val playlist = intent.getStringArrayListExtra(EXTRA_PLAYLIST)?.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }.orEmpty().ifEmpty { listOf(uri) }
            val startIndex = intent.getIntExtra(EXTRA_START_INDEX, playlist.indexOf(uri).takeIf { it >= 0 } ?: 0).coerceIn(0, playlist.lastIndex)
            val items = playlist.map { itemUri ->
                MediaItem.Builder().setUri(itemUri).setMediaMetadata(
                    MediaMetadata.Builder().setTitle(itemUri.lastPathSegment ?: title).build()
                ).build()
            }
            val defer = intent.getBooleanExtra(EXTRA_DEFER_START, false)
            stopRequested = false
            userTookControl = false
            deferredStart = false
            player?.apply {
                repeatMode = repeat
                setPlaybackSpeed(speed)
                setMediaItems(items, startIndex, position)
                prepare()
                // With DEFER the activity keeps playing until this player is ready, then calls resumeAt().
                playWhenReady = !defer
            }
            deferredStart = defer
            prefs.edit()
                .putBoolean(KEY_ACTIVE, true)
                .putString("last_uri", uri.toString())
                .putLong("pos_${uri}", position)
                .apply()
        }
        // startForegroundService() requires startForeground() promptly: post the real notification right away.
        refreshNotification(forceForeground = true)
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (player?.isPlaying == true || deferredStart) return
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        player?.let {
            val uri = it.currentMediaItem?.localConfiguration?.uri
            if (uri != null) {
                prefs.edit()
                    .putLong("pos_${uri}", it.currentPosition.coerceAtLeast(0L))
                    .putString("last_uri", uri.toString())
                    .putBoolean(KEY_ACTIVE, false)
                    .apply()
            }
            it.release()
        }
        player = null
        if (instance === this) instance = null
        earphoneControls?.release()
        earphoneControls = null
        mediaSession?.release()
        mediaSession = null
        prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
        super.onDestroy()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    companion object {
        @Volatile private var instance: BackgroundPlaybackService? = null
        /** Set when Stop was pressed in the notification while the screen player was still playing. */
        @Volatile private var stopRequested = false

        data class Snapshot(val uri: String, val positionMs: Long, val playing: Boolean)

        /** Current service playback state; call from the main thread. Null if the service is not running. */
        fun snapshot(): Snapshot? {
            val p = instance?.player ?: return null
            val uri = p.currentMediaItem?.localConfiguration?.uri?.toString() ?: return null
            return Snapshot(uri, p.currentPosition.coerceAtLeast(0L), p.playWhenReady)
        }

        /** True once the service player has buffered enough to start instantly. */
        fun isReady(): Boolean = instance?.player?.playbackState == Player.STATE_READY

        /** Continues from the given position (the activity's live position) and starts playing. Main thread only. */
        fun resumeAt(positionMs: Long) {
            val s = instance ?: return
            s.deferredStart = false
            s.player?.apply {
                // Exact seek (this player never uses keyframe-snapped seeks) so audio is neither repeated nor skipped.
                if (abs(currentPosition - positionMs) > 40L) seekTo(positionMs)
                playWhenReady = true
            }
            s.refreshNotification()
        }

        /** Pauses the service player and returns its exact position, or null if the service is not running. Main thread only. */
        fun pauseAndGetPosition(): Long? {
            val s = instance ?: return null
            val p = s.player ?: return null
            s.deferredStart = false
            p.playWhenReady = false
            return p.currentPosition.coerceAtLeast(0L)
        }

        /**
         * True if the user pressed Pause/Play in the notification while the hand-off was still running.
         * The activity then pauses its own player instead of overriding what the user just did.
         */
        fun consumeUserControl(): Boolean {
            val s = instance ?: return false
            val taken = s.userTookControl || (s.deferredStart && s.player?.playWhenReady == true)
            if (taken) {
                s.userTookControl = false
                s.deferredStart = false
            }
            return taken
        }

        /** True (once) if Stop was pressed in the notification while the screen player was still playing. */
        fun consumeStopRequest(): Boolean {
            val taken = stopRequested
            stopRequested = false
            return taken
        }

        /** Moves the service player to the given position (used when the user took control during the hand-off). */
        fun seekExact(positionMs: Long) {
            val s = instance ?: return
            s.player?.let { if (abs(it.currentPosition - positionMs) > 40L) it.seekTo(positionMs) }
            s.refreshNotification()
        }

        const val EXTRA_DEFER_START = "extra_defer_start"
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_POSITION = "extra_position"
        const val EXTRA_SPEED = "extra_speed"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_REPEAT = "extra_repeat"
        const val EXTRA_PLAYLIST = "extra_playlist"
        const val EXTRA_START_INDEX = "extra_start_index"
        const val ACTION_STOP = "com.example.speedtimeplayer.action.STOP_BACKGROUND"
        const val ACTION_TOGGLE = "com.example.speedtimeplayer.action.TOGGLE_BACKGROUND"
        const val ACTION_PREV = "com.example.speedtimeplayer.action.PREV_BACKGROUND"
        const val ACTION_NEXT = "com.example.speedtimeplayer.action.NEXT_BACKGROUND"
        const val KEY_ACTIVE = "background_playback_active"
        const val KEY_STOP_URI = "background_stop_uri"
        const val KEY_STOP_POS = "background_stop_pos"
        private const val CHANNEL_ID = "alvi_background_playback"
        private const val NOTIFICATION_ID = 1001
    }
}
