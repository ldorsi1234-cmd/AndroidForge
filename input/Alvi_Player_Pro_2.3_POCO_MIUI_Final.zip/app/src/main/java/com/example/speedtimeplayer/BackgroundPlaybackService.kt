package com.example.speedtimeplayer

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.MediaMetadata
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.common.util.UnstableApi

@UnstableApi
class BackgroundPlaybackService : MediaSessionService() {
    private var player: ExoPlayer? = null
    private var mediaSession: MediaSession? = null
    private val prefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        player = ExoPlayer.Builder(this)
            .setSkipSilenceEnabled(prefs.getBoolean("auto_skip_silence", false))
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .also { it.repeatMode = Player.REPEAT_MODE_OFF }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 1201, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        mediaSession = MediaSession.Builder(this, player!!)
            .setSessionActivity(pendingIntent)
            .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
            stopSelf()
            return START_NOT_STICKY
        }

        val uriString = intent?.getStringExtra(EXTRA_URI)
        if (!uriString.isNullOrBlank()) {
            val uri = Uri.parse(uriString)
            val position = intent.getLongExtra(EXTRA_POSITION, 0L).coerceAtLeast(0L)
            val speed = intent.getFloatExtra(EXTRA_SPEED, 1f).coerceIn(0.25f, 3f)
            val title = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "Alvi Player"
            val repeat = intent.getIntExtra(EXTRA_REPEAT, Player.REPEAT_MODE_OFF).coerceIn(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL)
            val sameItem = player?.currentMediaItem?.localConfiguration?.uri == uri
            player?.apply {
                repeatMode = repeat
                setPlaybackSpeed(speed)
                if (!sameItem) {
                    val item = MediaItem.Builder()
                        .setUri(uri)
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
                        .build()
                    setMediaItem(item)
                    prepare()
                    seekTo(position)
                } else if (position > 0L && kotlin.math.abs(currentPosition - position) > 1500L) {
                    seekTo(position)
                }
                playWhenReady = true
            }
            prefs.edit()
                .putBoolean(KEY_ACTIVE, true)
                .putString("last_uri", uri.toString())
                .putLong("pos_${uri}", position)
                .apply()
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep explicit background playback alive when the task is dismissed.
        if (player?.isPlaying == true) return
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        player?.let {
            val uri = it.currentMediaItem?.localConfiguration?.uri
            if (uri != null) {
                prefs.edit()
                    .putLong("pos_${uri}", it.currentPosition.coerceAtLeast(0L))
                    .putString("last_uri", uri.toString())
                    .putBoolean(KEY_ACTIVE, false)
                    .apply()
            }
            it.release()
        }
        player = null
        mediaSession?.release()
        mediaSession = null
        prefs.edit().putBoolean(KEY_ACTIVE, false).apply()
        super.onDestroy()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    companion object {
        const val EXTRA_URI = "extra_uri"
        const val EXTRA_POSITION = "extra_position"
        const val EXTRA_SPEED = "extra_speed"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_REPEAT = "extra_repeat"
        const val ACTION_STOP = "com.example.speedtimeplayer.action.STOP_BACKGROUND"
        const val KEY_ACTIVE = "background_playback_active"
    }
}
