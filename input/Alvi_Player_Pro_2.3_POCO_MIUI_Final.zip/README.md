# Alvi Player 2.3

A fast, local-first Android video player focused on smooth playback, study-friendly speed control, precise seeking, subtitles, gestures, and a clean dark UI.

## Highlights

### Playback
- Default playback speed: 2×
- 0.25× / 0.5× / 1× / 1.5× / 2× / 2.5× / 3×
- Hold-to-speed
- Configurable double-tap seek: 5 / 10 / 15 / 20 / 30 seconds
- Fast keyframe-assisted seeking
- Per-video resume positions
- Automatic resume of the last video
- Adjusted viewing-time display at playback speed
- Screen stays awake only during active playback
- Handles audio becoming noisy by pausing playback when an output device disconnects
- Auto Skip Silence
- Fast seeking toggle (near-keyframe vs exact seeking)
- Repeat Off / One / All
- Folder playlist playback with per-video resume
- Expanded technical video/audio information: optional podcast-style automatic skipping of detected silent audio segments during playback

### Gestures and display
- Left/right double-tap seek
- Center double-tap pause/play
- Pinch zoom up to 4×
- Two-finger pan while zoomed
- Double-tap center resets zoom when zoomed
- Vertical brightness gesture
- Vertical volume gesture up to 200%
- Smooth control fade animations
- Fit / Stretch / Crop / Fit with black bars
- Sensor / Landscape / Portrait / Auto orientation
- Haptic feedback
- Screen lock with tap-to-reveal unlock control
- Picture-in-picture, including optional automatic PiP

### Audio
- Auto Skip Silence
- Fast seeking toggle (near-keyframe vs exact seeking)
- Repeat Off / One / All
- Folder playlist playback with per-video resume
- Expanded technical video/audio information uses Media3's real-time silence detector; it targets low-level audio silence, not semantic speech detection.
- Normal player volume control
- Optional amplified volume up to 200% using Android LoudnessEnhancer where supported
- Voice Clarity mode using an adaptive Android Equalizer speech-focused curve where the device exposes a compatible effect
- Audio track selection
- Audio delay preference

Voice Clarity is an enhancement, not a studio-grade voice separator or AI denoiser. Device audio-effect support varies by manufacturer.

### Subtitles
- Embedded subtitle tracks
- External SRT / VTT subtitles
- External SSA / ASS subtitles through Media3
- Remembered external subtitle per video
- Subtitle size and position controls
- External SRT/VTT subtitle synchronization from -5000 ms to +5000 ms
- Background parsing for external subtitles so the UI remains responsive

The custom synchronization control applies to external SRT/VTT subtitles. Media3-rendered embedded/SSA/ASS subtitles continue to use the decoder's native timing.

### Seeking preview
- Thumbnail preview above the seekbar
- Background frame extraction
- 250 ms thumbnail cache buckets
- Request cancellation/debouncing to prevent stale previews
- LRU thumbnail cache

### Decoder
- HW: hardware decoder only
- HW+: hardware with decoder fallback
- SW: software/FFmpeg extension preferred

Software/FFmpeg mode depends on the codecs included by the Media3 FFmpeg extension and the input format.

### File handling
- Android document picker
- Open with / Share video intents
- Persisted URI access where supported
- Saved video folder access
- Folder video browsing
- Graceful handling of inaccessible previous files
- Playback history kept separate from resume positions
- Independent history deletion and resume-position clearing

## Build

The project uses Kotlin, AndroidX, and Media3. CI is configured under `.github/workflows/build-android.yml`.

The local environment used to prepare this source did not contain a complete Android/Gradle build toolchain, so the project was not device-tested here. The source structure and archive were checked locally, but an APK build must be verified in Android Studio or GitHub Actions before production release.

## Production checklist

Before publishing to Google Play or distributing an APK, verify on representative devices:

1. H.264/H.265/VP9/AV1 files and unusual containers.
2. Hardware, fallback, and FFmpeg decoder modes.
3. Audio effects on Samsung, Xiaomi/Redmi, Pixel, and other target devices.
4. SRT/VTT/ASS subtitle rendering and synchronization.
5. Android 13–16 file picker and URI permission behavior.
6. Rotation, PiP, lock screen, Bluetooth/headphone disconnect, and app backgrounding.
7. Large 4K files and long videos.
8. Battery, memory, and thermal behavior during extended playback.

Media3's official documentation recommends ExoPlayer for playback and documents PlayerView, audio attributes, and MediaSession architecture for production media applications.

## Background playback
Alvi Player Pro 2.1 now provides two separate ways to leave the video screen:
- **Picture-in-picture:** keeps the video visible in a floating Android window.
- **Background play:** switches to audio-only playback through a Media3 `MediaSessionService`, allowing playback while the screen is off or another app is in the foreground. The system media notification/headset/media controls can control playback.

Background play is explicitly user initiated from **More → Audio & subtitles → Background play**. Reopening Alvi Player stops the background session and restores the video from the saved position.


## Xiaomi / POCO MIUI reliability
The target device profile is POCO X3 NFC on MIUI Global 14.0.1. Background playback is implemented with Media3 `MediaSessionService` and a media-playback foreground service. This is the Android-recommended architecture for continuing audio while the app is not visible.

For MIUI devices, if background playback is stopped after the player is swiped away or the screen is locked, check the system's per-app battery/background controls and allow Alvi Player to run in the background. Xiaomi exposes Background autostart and battery-management controls that can otherwise restrict background apps. The app does not request intrusive permanent battery-exemption permission automatically.

## Final stability changes in 2.3
- Background service no longer unnecessarily reloads the same video when receiving a duplicate start command.
- Background notification receives the actual video title.
- Background playback preserves the selected repeat mode and speed.
- Added an explicit stop command to avoid stale background sessions.
- Android 13+ notification permission is requested so media controls can be shown reliably.
- Background playback uses explicit media audio attributes and automatic audio-focus handling.
- Service lifecycle avoids leaving a phantom playback session after an explicit stop.
- Existing resume/history data remains separate.

Android's Media3 documentation recommends keeping the player and `MediaSession` inside `MediaSessionService` for background playback, and using a media-playback foreground service. citeturn0search0turn0search1
