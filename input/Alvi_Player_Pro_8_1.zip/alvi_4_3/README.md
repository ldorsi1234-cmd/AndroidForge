# Alvi Player Pro 2.6

A fast, study-focused Android video player built on AndroidX Media3 1.5.1.

## UI / playback changes in 2.5
- MX-style compact top control bar and large center play/previous/next controls.
- Bottom control surface reduced to a thin seek bar only; no bottom +/- seek buttons.
- Playback speed is a clock-style top button (◷).
- Voice Clarity has its own top control (CL).
- Auto Skip Silence has its own top control (AS) with Off / Mild / Strong modes.
- Horizontal seeking also changes speed in 0.5x steps: left slows down, right speeds up, with an on-screen hint.
- Folder playlists expose previous/next playback in-app and through the Android media notification.
- Background playback uses Media3 MediaSessionService. The system media controls automatically expose pause and next/previous when a playlist is available.

## Auto Skip Silence
Media3's PCM silence processor is configured directly in the audio sink for two practical modes:
- Mild: trims only longer quiet gaps while preserving more natural pauses.
- Strong: trims shorter/larger silent gaps for tighter lecture/podcast playback.

This detects low-level audio silence, not semantic human speech. It does not use cloud/AI processing.

## Notification controls
Background playback uses a MediaSessionService. When playing a folder playlist, Android's media controls can expose pause and next/previous actions from the active playlist. This follows Media3's recommended background playback architecture.

## Build
- compileSdk / targetSdk: 35
- minSdk: 23
- Java/Kotlin target: 17
- Media3: 1.5.1
- No FFmpeg Maven dependency is included.

This package is source code. APK/device validation must be performed in an Android build environment.


## MX-style long-press speed
Press and hold the video surface to temporarily play at 2× speed. Release immediately restores the user-selected speed. Horizontal swipe remains seek-only. This mirrors the familiar MX Player long-press fast-forward interaction.



## 3.3 MX-style control placement
- Playback OSD follows the supplied MX Player reference layout rather than using a generic control arrangement.
- Top bar: back/title on the left; audio tracks, subtitles, decoder and More on the right.
- Left-side playback cluster: Voice Clarity, Landscape/Portrait, playback speed and Auto Skip Silence.
- Speed button remains tap-to-select and hold + left/right drag for temporary speed, releasing back to the previously selected speed.
- Bottom: elapsed time at left, thin seekbar, remaining time at right; centered previous/play-pause/next controls; lock at lower left; aspect-ratio and fullscreen controls at lower right.
- Horizontal flip remains available; vertical flip remains excluded.
- Lock and playback icons use plain monochrome glyphs.
- Auto Skip Silence remains icon-only with Off/Mild/Strong modes.
- Noise Reduction is not part of the playback OSD.


## 3.4 volume and OSD refinement
- Top and bottom playback OSD panels use a more transparent MX-style black overlay.
- App volume 0–100% maps directly to the Android media-volume range: app 100% equals phone media volume 100%.
- App volume 100–200% keeps the phone at maximum and applies LoudnessEnhancer only to the excess.
- Temporary hold speed uses horizontal left/right drag, matching the requested MX-style interaction.

## 3.7 UI and seek preview improvements
- Refined MX-style top/bottom OSD opacity and spacing.
- Rebuilt the playback seekbar with a cleaner thin track and circular thumb.
- Seek thumbnails use one-second cache buckets and a larger 64-frame cache.
- Preview extraction uses scaled frame decoding on Android 8.1+ and closest-sync extraction to reduce decode latency.
- Cached thumbnails appear immediately while a new frame is decoded in the background.


## 3.9 notification control
- Notification Play/Pause is a service action and does not launch MainActivity.
- A single tap toggles the active foreground player directly and refreshes the notification state.
- Tapping the notification body still opens Alvi Player.


## 4.0 — MX-style player UI/interaction refinement
- Playback overlay reorganized to closely mirror MX Player: top action bar, vertical left tool rail, bottom timeline/transport strip, bottom-corner lock/aspect/fullscreen controls.
- Transparent black gradient overlays replace flat bars for a closer MX-style presentation.
- Playback gestures retained: single tap show/hide controls, double-tap left/right seek, double-tap center play/pause, vertical brightness/volume, pinch zoom/pan, and temporary 2× speed.
- Notification Play/Pause remains a service action and does not open the player.
- This is an MX-style implementation; MX Player proprietary artwork/branding is not copied.


## 4.1 interaction refinements
- Temporary speed hold/drag uses 0.5× steps.
- PiP and Background Playback are visible top-bar buttons.
- Remaining time is estimated at playback speed: 2× /2, 2.5× /3, 3× /4.
- Active toggle buttons change to a white active state.
- Bottom-left has one lock control; resize/aspect remains one dedicated control.
- Status-bar clock/battery can remain visible over the video with transparent system bars.


### 4.2 behavior refinement
- Leaving Alvi Player automatically enters picture-in-picture while a video is playing, unless Background Play has been explicitly enabled.
- Background Play therefore takes priority over automatic PiP.
- Clock/battery status information is hidden during normal playback; a touch starting at the top edge temporarily reveals the Android status bar, then it hides again.


## 4.3 orientation behavior
- Playback remains landscape-only.
- The orientation sensor switches between landscape-left and landscape-right when the phone is rotated.
- Portrait is never selected automatically.


## 4.5 Pro refinement
- Added always-visible top-bar Picture-in-Picture and Background Play buttons.
- Background Play takes priority over automatic PiP when leaving the app.
- Landscape-only sensor rotation now uses a dead-zone to avoid accidental rapid flips through portrait.
- Speed hold/drag remains in 0.5× steps and the active speed is reflected in the control.
- Remaining wall-clock playback time is adjusted by the requested speed mapping (2×→÷2, 2.5×→÷3, 3×→÷4).
- Controls have a subtle pressed animation and active controls use a white selected state.
- Top-edge status-bar reveal remains temporary; clock/battery stay hidden during normal playback.


## 4.6 Landscape rotation direction fix
- Corrected the landscape sensor mapping so rotating the phone toward the user selects the expected landscape side instead of the opposite side.


## Version 4.9 — Automatic PiP fix
- Enabled PiP support on the MainActivity manifest entry (required by Android).
- Automatic PiP is enabled by default and uses Android 12+ auto-enter parameters, with onUserLeaveHint fallback.
- Background Play still takes priority over PiP.


## Version 5.1 — Orientation behavior correction
- Sensor-driven mapping: 90° selects the corrected landscape side; 270° selects the opposite landscape side.
- Orientation button toggles Portrait and sensor-driven Landscape.
- Landscape sensor listener is disabled in Portrait and re-enabled when returning to Landscape.


## Version 5.2 — Clear playback overlays
- Top and bottom playback bars use under 5% black opacity so the video remains clearly visible beneath them.


## Version 5.3 — Smoother Seeking
- Reduced seek-preview debounce for more responsive thumbnail scrubbing.
- Uses nearest decodable sync frame for fast seeking when Fast Seeking is enabled.
- Hides the blocking buffering spinner during playback; this improves visual continuity but cannot eliminate actual source/decoder buffering for every video.


## Version 5.4 — Reliable Auto PiP / Background Play Priority
- Synchronizes Android 12+ automatic PiP entry with actual playback state.
- Automatic PiP is suppressed while Background Play is enabled.
- Updates PiP parameters when playback starts/pauses and when either mode is toggled.
- Keeps the leave-app fallback for supported Android versions.


## Version 5.6 — Fullscreen button now opens screen-fit options
- The far-right fullscreen icon now opens the same screen-fit/aspect-ratio menu as the screen-fit control.
- Immersive fullscreen is still available through the app's other fullscreen/orientation behavior.


## Version 5.7 — MX-style icon contrast
- Increased icon/text weight and added dark shadows for visibility over bright and white video frames.
- Kept button backgrounds relatively subtle while strengthening white icon contrast.


## Version 5.8 — MX-style Roboto typography
- Standardized playback UI text on Android Roboto (`sans-serif`) and medium-weight Roboto (`sans-serif-medium`) for controls and titles.
- Preserves the high-contrast white icons and dark text shadows from version 5.7.


## Version 5.9 — Background play, lock icon, speed hold-and-drag
- Removed the extra "↔" button at the bottom right; the far-right button still opens Screen Fit.
- Removed the "✓" suffix from the voice-clarity star (it wrapped and showed as a stray mark); the white highlighted background already shows it is on.
- Lock button is now a drawn padlock: open on a dark circle when unlocked, closed on a red circle when locked (shown for ~1.8 s after locking and on every tap while locked).
- Background Play is now a setting: switching it on/off no longer pauses the video. Playback is handed to the background service only when the app is paused/left, and taken back (same position) when you return.
- Hold-and-drag speed: hold the video (or the speed button) and drag right/left to change speed in 0.5× steps (10% of screen width per step); releasing returns to the default speed.
- Not compiled or device-tested in the authoring environment.


## Version 6.0 — MX Player-style interface
- All control icons are now crisp vector drawables (back, audio, subtitles, PiP, background play, more, rotate, skip silence, voice clarity, lock, previous/play/pause/next, screen fit) instead of text glyphs, drawn white with a soft shadow so they stay visible on bright frames.
- MX-style layout: top bar with larger Roboto Medium title, a tool row below it (rotate, speed "2X", skip silence, voice clarity) with dark circles that turn blue when active, larger timecodes on both sides of the seekbar, big transport controls, lock bottom-left, screen fit bottom-right.
- Locked state: red circle with a closed padlock; unlocked is a plain open padlock.
- Smoother feel: controls fade in/out as groups, the seekbar has 10× finer resolution and updates 4× per second, button presses scale/fade, and subtle top/bottom gradients replace flat overlays.
- Previous/Next are always shown (Next toasts when there is no next video).
- Not compiled or device-tested in the authoring environment.


## Version 6.1 — Background play crash/pause fix
- The background service now calls startForeground() immediately (same id/channel as Media3's notification) and registers its MediaSession with addSession(), so Android no longer kills the app or stops playback after leaving the app with Background Play on.
- Added the standard MediaSessionService intent filter to the manifest.
- Not compiled or device-tested in the authoring environment.


## Version 6.2 — Stability and smoothness pass
- Video file name is cached; progress saving no longer queries the content resolver on the UI thread every second.
- Playback history keeps one entry per video (max 50) instead of adding a new entry on every launch.
- A video that is within 5 s of the end (or finished) restarts from the beginning next time; controls appear when playback ends.
- The UI refresh loop (4×/s) runs only while the app is visible, saving battery.
- PiP window uses the real video aspect ratio (was always 16:9) and updates when the video size is known.
- With Background Play off and PiP not active, leaving the app now pauses playback instead of playing on invisibly.
- Updated the speed hold-and-drag help text; all pending handler callbacks are cleared on destroy.
- Not compiled or device-tested in the authoring environment.


## Version 6.3 — PiP play/pause and cleaner More menu
- The Picture-in-Picture window now has a Play/Pause button that follows the playback state.
- More menu: rows show the title on the left and the current value on the right, items close the menu when tapped (so toggles never show stale labels), darker rounded dialog.
- Removed the "Speed hold + drag" entry from the More menu (the gesture itself is unchanged).
- Not compiled or device-tested in the authoring environment.


## Version 7.0 — Final polish and stability
- Decoder switching keeps the whole folder playlist and position (it used to collapse to one video).
- Opening a single video clears any old folder queue; Background Play hand-off uses the correct playlist.
- Back is ignored while locked (the red padlock flashes instead); fullscreen is re-applied whenever the window regains focus, and touching the top edge no longer brings the status bar back.
- Folder video lists are sorted by name.
- Subtitle files with a byte-order mark or Windows-1252 text now display correctly.
- Track picker marks the currently selected track.
- Looks: consistent dark rounded dialogs app-wide (new Theme.Alvi), black window background (no white flash), larger gesture hint at the top centre, refreshed home screen with a primary "Open video" button.
- Not compiled or device-tested in the authoring environment.


## Version 7.1 — Clarity, smoother seeking, tighter MX layout
- Voice Clarity now has levels (Off / Light / Balanced / Strong). Tap the button to cycle, hold it (or use More) to pick. The EQ curve is interpolated smoothly from the device's own bands, with a little headroom to avoid clipping. Old on/off setting migrates to "Balanced".
- Icons swapped: Voice Clarity uses the waveform icon; Auto Skip Silence has a new icon (sound bars with a fast-forward jump across the gap).
- Seekbar sits closer to the bottom edge (48 dp, was 64 dp): timeline 34 dp + transport row 48 dp; lock/fit buttons realigned to the transport row.
- Smoother seekbar: 100,000-step resolution, thumb refreshed ~30×/s while playing (was 4×/s), halo on the thumb while dragging.
- Seek thumbnails: much smaller (76 dp tall, follows your finger, shows the time), decoded at ~200 px, latest-position-wins decoding (no queue of stale frames), byte-limited cache, neighbour frame shown instantly while the exact one decodes.
- MX layout: the headphones (Background play) button moved from the top bar into the tool row, first on the left, as in MX Player.
- Not compiled or device-tested in the authoring environment.


## Version 7.2 — Seamless background play
- Hand-off no longer pauses the video first. The screen player keeps playing while the background service prepares (audio only, video decoding disabled); once the service is ready it continues from the live position and only then does the screen player pause.
- Returning to the app works the same way in reverse: the service keeps playing until the screen player is actually playing again, then stops.
- If you come back before the hand-off finishes, nothing is interrupted; if the service cannot get ready within ~8 s, playback simply stays in the app.
- Not compiled or device-tested in the authoring environment.


## Version 8.0 — Final polish (no new features)
- Playback buffering tuned for lectures: 30–60 s buffered ahead, playback restarts after 0.4 s (1.5 s after a stall), so seeking and 2x playback recover faster. Same settings in the background service.
- Control fades run on hardware layers for smoother show/hide.
- Includes everything from 7.1 (clarity levels, new icons, tighter seekbar, smooth thumb, fast small thumbnails, MX tool row) and 7.2 (seamless background play).
- Not compiled or device-tested in the authoring environment.


## Version 8.1 — Cleaner More menu
- Removed the sleep timer.
- Removed More-menu entries that duplicate on-screen buttons (Auto Skip Silence, Voice Clarity, Screen fit, Orientation, Decoder, Audio/subtitle tracks, Picture-in-picture, Background play) and rarely needed ones (Resume current video, Reset volume, Pinch zoom reset).
- Menu is now Playback, Display & audio, Library.
- Not compiled or device-tested in the authoring environment.
