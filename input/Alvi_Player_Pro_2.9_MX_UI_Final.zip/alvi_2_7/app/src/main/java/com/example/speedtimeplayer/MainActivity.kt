package com.example.speedtimeplayer

import android.content.Intent
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Equalizer
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.widget.ImageView
import android.widget.HorizontalScrollView
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.Build
import android.app.PictureInPictureParams
import android.view.ViewConfiguration
import android.util.Rational
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.ScaleGestureDetector
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.graphics.Typeface
import android.widget.Toast
import android.util.LruCache
import android.util.TypedValue
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackGroup
import androidx.media3.common.Tracks
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.log10

@UnstableApi
class MainActivity : ComponentActivity() {
    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var orientationButton: TextView
    private lateinit var leftTools: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var speedButton: TextView
    private lateinit var decoderButton: TextView
    private lateinit var subtitleButton: TextView
    private var volumeBoostEnhancer: LoudnessEnhancer? = null
    private var voiceClarityEqualizer: Equalizer? = null
    private var voiceClarityEnabled = false
    private var voiceClarityAppliedSessionId = 0
    private var selectedSpeed = 2f
    private lateinit var clarityButton: TextView
    private lateinit var autoSkipButton: TextView
    private var autoSkipMode = 0 // 0=off, 1=mild, 2=strong
    private var temporarySpeedActive = false
    private var temporarySpeedPrevious = 1f
    private var longPressSpeedMode = false
    private var longPressStartY = 0f
    private var longPressRunnable: Runnable? = null
    private val endTemporarySpeedRunnable = Runnable { endTemporarySpeed() }
    private lateinit var timeLeftText: TextView
    private lateinit var playPauseButton: TextView
    private lateinit var previousButton: TextView
    private lateinit var nextButton: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var previewImage: ImageView
    private val previewExecutor = Executors.newSingleThreadExecutor()
    private var previewRequestId = 0L
    private val previewLock = Any()
    private var pendingPreviewPositionMs = 0L
    private var previewFuture: Future<*>? = null
    private var previewRetriever: MediaMetadataRetriever? = null
    private val previewCache = object : LruCache<String, Bitmap>(24) { override fun sizeOf(key: String, value: Bitmap) = 1 }
    private var previewRetrieverUri: Uri? = null
    private var volumePercent = 100
    private var gestureSensitivity = 1.0f
    private var seekSeconds = 10
    private var subtitleSize = 0.0533f
    private var subtitleBottom = 0.08f
    private var gestureStartVolumePercent = 100
    private var gestureStartSystemVolume = 0
    private var gestureStartSystemMax = 1
    private lateinit var selectButton: TextView
    private lateinit var lockButton: TextView
    private lateinit var fitButton: TextView
    private lateinit var gestureHint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var controlsVisible = false
    private var locked = false
    private var userSeeking = false
    private var brightnessBeforeGesture = -1f
    private val speeds = listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 2.5f, 3f)
    private data class SubtitleCue(val startMs: Long, val endMs: Long, val text: String)
    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureStartPosition = 0L
    private var gestureMode = 0 // 0 unknown, 1 seek, 2 brightness, 3 volume
    private var fitMode = 0
    private val fitModes = listOf(AspectRatioFrameLayout.RESIZE_MODE_FIT, AspectRatioFrameLayout.RESIZE_MODE_FILL, AspectRatioFrameLayout.RESIZE_MODE_ZOOM, AspectRatioFrameLayout.RESIZE_MODE_FIT)
    private val fitModeNames = listOf("Fit", "Stretch", "Crop/Zoom", "Fit with black bars")
    private val historyPrefs by lazy { getSharedPreferences("alvi_player", MODE_PRIVATE) }
    private var currentUri: Uri? = null
    private var resumePosition = 0L
    private var subtitleUri: Uri? = null
    private var audioDelayMs = 0
    private var subtitleSyncMs = 0
    private var decoderMode = 1 // 0=HW, 1=HW+, 2=SW
    private var orientationMode = 1 // 1=Landscape, 2=Portrait; playback defaults to landscape
    private var zoomScale = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastVideoTitle = "Alvi Player"
    private var hapticsEnabled = true
    private var autoPictureInPicture = false
    private var autoSkipSilence = false
    private var fastSeekEnabled = true
    private var repeatMode = Player.REPEAT_MODE_OFF
    private var notificationStarted = false
    private var lastNotificationPlaying: Boolean? = null
    private var lastNotificationTitle: String? = null
    private var queuedFolderUris: List<Uri> = emptyList()
    private var externalSubtitleCues: List<SubtitleCue> = emptyList()
    private var subtitleExecutor = Executors.newSingleThreadExecutor()
    private lateinit var externalSubtitleView: TextView

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            openVideo(uri, true)
        }
    }
    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            attachSubtitle(uri)
        }
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) { }
            historyPrefs.edit().putString("folder_uri", uri.toString()).apply()
            Toast.makeText(this, "Folder access saved. Use Folder videos in More to browse files.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        hideSystemBars()
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        selectedSpeed = historyPrefs.getFloat("selected_speed", 2f)
        volumePercent = historyPrefs.getInt("volume_percent", 100).coerceIn(0, 200)
        gestureSensitivity = historyPrefs.getFloat("gesture_sensitivity", 1.0f).coerceIn(0.5f, 2.0f)
        seekSeconds = historyPrefs.getInt("seek_seconds", 10).coerceIn(5, 30)
        subtitleSize = historyPrefs.getFloat("subtitle_size", 0.0533f).coerceIn(0.03f, 0.10f)
        subtitleBottom = historyPrefs.getFloat("subtitle_bottom", 0.08f).coerceIn(0f, 0.30f)
        fitMode = historyPrefs.getInt("fit_mode", 0).coerceIn(0, fitModes.lastIndex)
        decoderMode = historyPrefs.getInt("decoder_mode", 1).coerceIn(0, 2)
        orientationMode = historyPrefs.getInt("orientation_mode", 1).coerceIn(1, 2)
        hapticsEnabled = historyPrefs.getBoolean("haptics", true)
        autoPictureInPicture = historyPrefs.getBoolean("auto_pip", false)
        autoSkipMode = historyPrefs.getInt("auto_skip_mode", if (historyPrefs.getBoolean("auto_skip_silence", false)) 1 else 0).coerceIn(0, 2)
        autoSkipSilence = autoSkipMode > 0
        fastSeekEnabled = historyPrefs.getBoolean("fast_seek", true)
        repeatMode = historyPrefs.getInt("repeat_mode", Player.REPEAT_MODE_OFF).coerceIn(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ALL)
        voiceClarityEnabled = historyPrefs.getBoolean("voice_clarity", false)
        subtitleSyncMs = historyPrefs.getInt("subtitle_sync_ms", 0).coerceIn(-5000, 5000)
        applyOrientationMode()
        applySubtitleStyle()
        buildPlayer()
        player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
        handler.postDelayed({ if (::player.isInitialized) applyGestureVolume(volumePercent) }, 350L)
        playPauseButton.setOnClickListener { if (player.isPlaying) player.pause() else player.play(); updateUi(); showControlsTemporarily() }
        selectButton.setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        lockButton.setOnClickListener {
            if (locked) unlockScreen() else lockScreen()
        }
        speedButton.setOnClickListener { showSpeedDialog() }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true; cancelAutoHide(); previewImage.visibility = View.VISIBLE }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && player.duration > 0 && player.duration != C.TIME_UNSET) {
                    val target = player.duration * progress / 1000L
                    positionText.text = formatMs(target)
                    showSeekPreview(target)
                }
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                if (player.duration > 0 && player.duration != C.TIME_UNSET) player.seekTo(player.duration * (seekBar?.progress ?: 0) / 1000L)
                userSeeking = false
                previewImage.visibility = View.GONE
                showControlsTemporarily()
            }
        })
        installGestures()
        speedButton.text = speedLabel(selectedSpeed)
        clarityButton.text = if (voiceClarityEnabled) "✦✓" else "✦"
        autoSkipButton.text = autoSkipIcon()
        playerView.resizeMode = fitModes[fitMode]
        fitButton.contentDescription = "Screen fit: ${fitModeNames[fitMode]}"
        applyZoom()
        val handledIncoming = handleIncomingIntent(intent)
        if (!handledIncoming && historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)) {
            stopService(Intent(this, BackgroundPlaybackService::class.java).apply { action = BackgroundPlaybackService.ACTION_STOP })
            historyPrefs.edit().putBoolean(BackgroundPlaybackService.KEY_ACTIVE, false).apply()
        }
        if (!handledIncoming) {
            val last = historyPrefs.getString("last_uri", null)
            if (!last.isNullOrBlank()) {
                try {
                    openVideo(Uri.parse(last), true)
                } catch (_: Exception) {
                    Toast.makeText(this, "The last video is no longer accessible", Toast.LENGTH_LONG).show()
                    showHomePanel()
                }
            } else {
                showHomePanel()
            }
        }
        handler.post(updateRunnable)
        setControlsVisible(false)
    }

    private fun showHomePanel() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(24), dp(28), dp(24)); background = roundedBackground(0xEE171717.toInt(), 24)
        }
        val title = TextView(this).apply { text = "ALVI PLAYER"; textSize = 28f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val sub = TextView(this).apply { text = "Fast, focused video playback"; textSize = 14f; setTextColor(0xFFBDBDBD.toInt()); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(18)) }
        panel.addView(title); panel.addView(sub)
        val open = button("Open video")
        val folder = button("Open folder")
        panel.addView(open, LinearLayout.LayoutParams(dp(220), dp(50)).apply { bottomMargin = dp(8) })
        panel.addView(folder, LinearLayout.LayoutParams(dp(220), dp(50)).apply { bottomMargin = dp(16) })
        open.setOnClickListener { pickVideo.launch(arrayOf("video/*")); panel.visibility = View.GONE }
        folder.setOnClickListener { pickFolder.launch(null); panel.visibility = View.GONE }
        val recent = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }.distinctBy { it.toString() }.take(3)
        if (recent.isNotEmpty()) {
            val recentTitle = TextView(this).apply { text = "Recent"; textSize = 13f; setTextColor(0xFF8AB4F8.toInt()); gravity = Gravity.LEFT; setPadding(0, 0, 0, dp(8)) }
            panel.addView(recentTitle, LinearLayout.LayoutParams(-1, -2))
            recent.forEach { uri ->
                val item = TextView(this).apply { text = displayName(uri); textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(10), 0); background = roundedBackground(0xFF252525.toInt(), 12); isClickable = true }
                item.setOnClickListener { openVideo(uri, true); panel.visibility = View.GONE }
                panel.addView(item, LinearLayout.LayoutParams(dp(280), dp(44)).apply { bottomMargin = dp(6) })
            }
        }
        root.addView(panel, FrameLayout.LayoutParams(dp(330), -2, Gravity.CENTER))
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        playerView = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
            setBackgroundColor(Color.BLACK)
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))

        externalSubtitleView = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT; gravity = Gravity.CENTER
            setPadding(dp(18), dp(4), dp(18), dp(4)); setShadowLayer(dp(3).toFloat(), 0f, dp(2).toFloat(), Color.BLACK)
            visibility = View.GONE; maxLines = 4; includeFontPadding = true
        }
        root.addView(externalSubtitleView, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            leftMargin = dp(18); rightMargin = dp(18); bottomMargin = dp(118)
        })

        // MX-inspired top command bar: title/back on the left, compact playback tools on the right.
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setBackgroundColor(0xB8000000.toInt())
        }
        selectButton = iconButton("‹", 30f)
        selectButton.contentDescription = "Back"
        topBar.addView(selectButton, LinearLayout.LayoutParams(dp(48), dp(46)))

        titleView = TextView(this).apply {
            text = lastVideoTitle
            textSize = 16f
            setTextColor(Color.WHITE)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(4), 0, dp(8), 0)
        }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, dp(46), 1f))

        val topAudio = iconButton("♪", 25f)
        topAudio.contentDescription = "Audio tracks"
        topBar.addView(topAudio, LinearLayout.LayoutParams(dp(46), dp(46)))
        topAudio.setOnClickListener { showTrackDialog() }

        val topSubtitle = iconButton("▤", 22f)
        topSubtitle.contentDescription = "Subtitles"
        subtitleButton = topSubtitle
        topBar.addView(topSubtitle, LinearLayout.LayoutParams(dp(46), dp(46)))
        topSubtitle.setOnClickListener { showTrackDialog() }

        decoderButton = iconButton(decoderShortLabel(), 14f)
        decoderButton.contentDescription = "Decoder: ${decoderName()}"
        topBar.addView(decoderButton, LinearLayout.LayoutParams(dp(58), dp(46)))

        autoSkipButton = iconButton(autoSkipIcon(), 18f)
        autoSkipButton.contentDescription = "Auto Skip Silence"
        topBar.addView(autoSkipButton, LinearLayout.LayoutParams(dp(48), dp(46)))

        val moreButton = iconButton("⋮", 28f)
        moreButton.contentDescription = "More options"
        topBar.addView(moreButton, LinearLayout.LayoutParams(dp(42), dp(46)))
        moreButton.setOnClickListener { showMoreDialog() }
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(54), Gravity.TOP))

        // Left floating controls closely follow the reference layout: clarity, orientation, speed, audio.
        leftTools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(2), dp(10), dp(2))
        }
        clarityButton = iconButton(if (voiceClarityEnabled) "✦✓" else "✦", 20f)
        clarityButton.contentDescription = "Voice clarity"
        leftTools.addView(clarityButton, LinearLayout.LayoutParams(dp(58), dp(58)))

        orientationButton = iconButton("⟳", 25f)
        orientationButton.contentDescription = "Change landscape or portrait"
        leftTools.addView(orientationButton, LinearLayout.LayoutParams(dp(58), dp(58)).apply { leftMargin = dp(4) })

        speedButton = iconButton(speedLabel(selectedSpeed), 15f)
        speedButton.contentDescription = "Playback speed"
        leftTools.addView(speedButton, LinearLayout.LayoutParams(dp(62), dp(58)).apply { leftMargin = dp(4) })

        val audioBoostButton = iconButton("▥", 20f)
        audioBoostButton.contentDescription = "Audio boost"
        leftTools.addView(audioBoostButton, LinearLayout.LayoutParams(dp(58), dp(58)).apply { leftMargin = dp(4) })
        audioBoostButton.setOnClickListener { showVolumeDialog() }

        root.addView(leftTools, FrameLayout.LayoutParams(-2, dp(64), Gravity.TOP or Gravity.LEFT).apply {
            topMargin = dp(68)
        })

        selectButton.setOnClickListener {
            if (player.mediaItemCount > 0) onBackPressedDispatcher.onBackPressed()
            else pickVideo.launch(arrayOf("video/*"))
        }
        speedButton.setOnClickListener { showSpeedDialog() }
        clarityButton.setOnClickListener { showVoiceClarityDialog() }
        decoderButton.setOnClickListener { showDecoderDialog() }
        autoSkipButton.setOnClickListener { showAutoSkipSilenceDialog() }
        orientationButton.setOnClickListener { toggleOrientation() }

        // Bottom: only numeric elapsed/remaining time, thin scrubber, and large transport controls.
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(4))
            setBackgroundColor(0xB8000000.toInt())
        }
        val timelineRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        positionText = label("0:00").apply { textSize = 13f; gravity = Gravity.CENTER }
        durationText = label("0:00").apply { textSize = 13f; gravity = Gravity.CENTER }
        seekBar = SeekBar(this).apply { max = 1000; progress = 0; minimumHeight = dp(20) }
        timelineRow.addView(positionText, LinearLayout.LayoutParams(dp(78), dp(28)))
        timelineRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(28), 1f))
        timelineRow.addView(durationText, LinearLayout.LayoutParams(dp(78), dp(28)))
        bottomBar.addView(timelineRow, LinearLayout.LayoutParams(-1, dp(32)))

        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        previousButton = iconButton("|◀", 25f); previousButton.contentDescription = "Previous"
        playPauseButton = iconButton("Ⅱ", 30f); playPauseButton.contentDescription = "Play or pause"
        nextButton = iconButton("▶|", 25f); nextButton.contentDescription = "Next"
        transport.addView(previousButton, LinearLayout.LayoutParams(dp(76), dp(58)))
        transport.addView(playPauseButton, LinearLayout.LayoutParams(dp(86), dp(62)))
        transport.addView(nextButton, LinearLayout.LayoutParams(dp(76), dp(58)))
        bottomBar.addView(transport, LinearLayout.LayoutParams(-1, dp(66)))
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(108), Gravity.BOTTOM))

        lockButton = iconButton("▣", 25f)
        lockButton.contentDescription = "Screen lock"
        root.addView(lockButton, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(10); bottomMargin = dp(18)
        })

        fitButton = iconButton("⛶", 24f)
        fitButton.contentDescription = "Screen fit"
        root.addView(fitButton, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(10); bottomMargin = dp(18)
        })
        fitButton.setOnClickListener { showFitOptions() }

        gestureHint = TextView(this).apply {
            text = ""; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10)); background = roundedBackground(0xDD111111.toInt(), 18); visibility = View.GONE
        }
        root.addView(gestureHint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        previewImage = ImageView(this).apply { visibility = View.GONE; scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(0xEE111111.toInt()) }
        root.addView(previewImage, FrameLayout.LayoutParams(dp(220), dp(124), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(110) })

        timeLeftText = label("").apply { visibility = View.GONE }
        setContentView(root)

        playPauseButton.setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
            updateUi(); showControlsTemporarily()
        }
        previousButton.setOnClickListener {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else seekFast(max(0L, player.currentPosition - seekSeconds * 1000L))
            showControlsTemporarily()
        }
        nextButton.setOnClickListener {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem() else Toast.makeText(this, "No next video", Toast.LENGTH_SHORT).show()
            showControlsTemporarily()
        }
        lockButton.setOnClickListener { if (locked) unlockScreen() else lockScreen() }
    }


    /**
     * Fast ±10-second gesture seek. CLOSEST_SYNC lets Media3 land on a nearby
     * keyframe instead of waiting for an exact frame; this can reduce seek delay,
     * but exact zero-buffer seeking cannot be guaranteed for every file/source.
     */
    private fun seekFast(targetMs: Long) {
        val duration = player.duration
        val safeTarget = if (duration > 0 && duration != C.TIME_UNSET) targetMs.coerceAtMost(duration) else targetMs
        if (fastSeekEnabled) {
            player.setSeekParameters(SeekParameters.CLOSEST_SYNC)
            player.seekTo(safeTarget)
            handler.removeCallbacks(restoreSeekParametersRunnable)
            handler.postDelayed(restoreSeekParametersRunnable, 700L)
        } else {
            player.setSeekParameters(SeekParameters.EXACT)
            player.seekTo(safeTarget)
        }
    }

    private val restoreSeekParametersRunnable = Runnable {
        if (::player.isInitialized) player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
    }

    private fun lockScreen() {
        locked = true
        lockButton.text = "🔓"
        lockButton.visibility = View.GONE
        setControlsVisible(false)
        Toast.makeText(this, "Screen locked", Toast.LENGTH_SHORT).show()
    }

    private fun unlockScreen() {
        locked = false
        lockButton.text = "🔒"
        lockButton.alpha = 1f
        setControlsVisible(true)
        Toast.makeText(this, "Screen unlocked", Toast.LENGTH_SHORT).show()
    }

    /** MX-style hold-and-drag speed control. Hold the video, then move vertically. */
    private fun startTemporarySpeed(startY: Float) {
        if (temporarySpeedActive || !::player.isInitialized || player.mediaItemCount == 0) return
        temporarySpeedPrevious = selectedSpeed
        longPressStartY = startY
        temporarySpeedActive = true
        longPressSpeedMode = true
        player.setPlaybackSpeed(2f)
        showGestureHint("2×")
        haptic()
    }

    private fun endTemporarySpeed() {
        longPressRunnable?.let { handler.removeCallbacks(it) }
        longPressRunnable = null
        if (!temporarySpeedActive || !::player.isInitialized) return
        temporarySpeedActive = false
        longPressSpeedMode = false
        player.setPlaybackSpeed(temporarySpeedPrevious)
        gestureHint.visibility = View.GONE
    }

    private fun installGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                longPressRunnable?.let { handler.removeCallbacks(it) }
                longPressRunnable = Runnable {
                    if (!locked && player.mediaItemCount > 0 && gestureMode == 0) startTemporarySpeed(e.y)
                }
                handler.postDelayed(longPressRunnable!!, ViewConfiguration.getLongPressTimeout().toLong())
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) {
                    lockButton.text = "▣"; lockButton.alpha = 0f; lockButton.visibility = View.VISIBLE
                    lockButton.animate().alpha(1f).setDuration(160L).start()
                    handler.postDelayed({ if (locked) lockButton.animate().alpha(0f).setDuration(180L).withEndAction { lockButton.visibility = View.GONE }.start() }, 1800)
                } else toggleControls()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                if (e.x < root.width * 0.35f) seekFast(max(0L, player.currentPosition - seekSeconds * 1000L))
                else if (e.x > root.width * 0.65f) seekFast(player.currentPosition + seekSeconds * 1000L)
                else if (zoomScale > 1.01f) resetZoom() else if (player.isPlaying) player.pause() else player.play()
                haptic(); return true
            }
        })
        val scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                if (locked || player.mediaItemCount == 0) return true
                longPressRunnable?.let { handler.removeCallbacks(it) }
                zoomScale = (zoomScale * detector.scaleFactor).coerceIn(1f, 4f)
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT; applyZoom(); return true
            }
        })
        playerView.setOnTouchListener { _, event ->
            scaleDetector.onTouchEvent(event); detector.onTouchEvent(event)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    gestureStartX = event.x; gestureStartY = event.y; gestureStartPosition = player.currentPosition; gestureMode = 0
                    longPressStartY = event.y
                    brightnessBeforeGesture = window.attributes.screenBrightness
                    if (brightnessBeforeGesture < 0f) brightnessBeforeGesture = 0.5f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (locked) return@setOnTouchListener true
                    if (longPressSpeedMode) {
                        val dy = event.y - longPressStartY
                        val speed = (2f - dy / root.height * 3f).coerceIn(0.25f, 3f)
                        player.setPlaybackSpeed(speed); showGestureHint(speedLabel(speed)); return@setOnTouchListener true
                    }
                    if (event.pointerCount >= 2 && zoomScale > 1.01f) {
                        longPressRunnable?.let { handler.removeCallbacks(it) }
                        panX += event.x - gestureStartX; panY += event.y - gestureStartY; gestureStartX = event.x; gestureStartY = event.y; applyZoom()
                        return@setOnTouchListener true
                    }
                    val dx = event.x - gestureStartX; val dy = event.y - gestureStartY
                    if (gestureMode == 0 && (abs(dx) > dp(18) || abs(dy) > dp(18))) {
                        longPressRunnable?.let { handler.removeCallbacks(it) }
                        gestureMode = if (abs(dx) > abs(dy)) 1 else if (gestureStartX < root.width / 2f) 2 else 3
                        if (gestureMode == 3) {
                            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
                            gestureStartSystemVolume = audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                            gestureStartSystemMax = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                            gestureStartVolumePercent = volumePercent
                        }
                        cancelAutoHide()
                    }
                    when (gestureMode) {
                        1 -> {
                            val delta = (dx / root.width * 120_000L * gestureSensitivity).toLong(); val target = max(0L, gestureStartPosition + delta)
                            player.seekTo(if (player.duration > 0 && player.duration != C.TIME_UNSET) target.coerceAtMost(player.duration) else target)
                            showGestureHint("${if (delta >= 0) "+" else "−"}${formatMs(abs(delta))}")
                        }
                        2 -> {
                            val value = (brightnessBeforeGesture - (dy / root.height) * gestureSensitivity).coerceIn(0f, 1f)
                            val attrs = window.attributes; attrs.screenBrightness = value; window.attributes = attrs
                            showGestureHint("Brightness ${(value * 100).roundToInt()}%")
                        }
                        3 -> {
                            val deltaPercent = (-dy / root.height * 200f * gestureSensitivity).roundToInt()
                            applyGestureVolume((gestureStartVolumePercent + deltaPercent).coerceIn(0, 200)); showGestureHint("Volume $volumePercent%")
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    longPressRunnable?.let { handler.removeCallbacks(it) }; longPressRunnable = null
                    if (temporarySpeedActive) endTemporarySpeed()
                    if (gestureMode != 0) { gestureHint.visibility = View.GONE; showControlsTemporarily() }
                    gestureMode = 0; true
                }
                else -> true
            }
        }
    }

    private fun handleIncomingIntent(incoming: Intent?): Boolean {
        val uri = incoming?.data ?: if (android.os.Build.VERSION.SDK_INT >= 33) {
            incoming?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION") incoming?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        }
        if (uri == null) return false
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        openVideo(uri, true)
        return true
    }

    private fun openVideo(uri: Uri, resume: Boolean) {
        saveCurrentProgress()
        currentUri = uri
        lastVideoTitle = displayName(uri)
        val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
        subtitleUri = savedSubtitle
        externalSubtitleCues = emptyList()
        externalSubtitleView.text = ""
        externalSubtitleView.visibility = View.GONE
        val item = if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri)
        player.setMediaItem(item)
        player.prepare()
        if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
        val saved = if (resume) historyPrefs.getLong("pos_${uri}", 0L) else 0L
        player.seekTo(saved)
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        historyPrefs.edit().putString("last_uri", uri.toString())
            .putString("history_${System.currentTimeMillis()}", uri.toString())
            .putString("name_${uri}", displayName(uri)).apply()
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateUi()
    }

    private fun saveCurrentProgress() {
        if (!::player.isInitialized) return
        val uri = currentUri ?: return
        historyPrefs.edit().putLong("pos_${uri}", max(0L, player.currentPosition))
            .putString("name_${uri}", displayName(uri)).putString("last_uri", uri.toString()).apply()
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "Video"
        try { contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: name } } catch (_: Exception) { }
        return name
    }

    private fun subtitleExtension(uri: Uri): String =
        uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase(Locale.ROOT) ?: ""

    private fun isCustomSubtitle(uri: Uri): Boolean =
        subtitleExtension(uri) == "srt" || subtitleExtension(uri) == "vtt"

    private fun buildVideoItem(video: Uri, subtitle: Uri): MediaItem {
        if (isCustomSubtitle(subtitle)) return MediaItem.fromUri(video)
        val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(subtitle)
            .setMimeType(when (subtitleExtension(subtitle)) {
                "srt" -> MimeTypes.APPLICATION_SUBRIP
                "vtt" -> MimeTypes.TEXT_VTT
                "ssa", "ass" -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            })
            .setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        return MediaItem.Builder().setUri(video).setSubtitleConfigurations(listOf(subtitleConfig)).build()
    }

    private fun applySubtitleStyle() {
        playerView.subtitleView?.apply {
            setFractionalTextSize(subtitleSize)
            setBottomPaddingFraction(subtitleBottom)
        }
        if (::externalSubtitleView.isInitialized) {
            externalSubtitleView.textSize = (subtitleSize * 100f * 0.34f).coerceIn(14f, 34f)
            (externalSubtitleView.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
                lp.bottomMargin = dp((82 + subtitleBottom * 260f).roundToInt())
                externalSubtitleView.layoutParams = lp
            }
        }
    }

    private fun attachSubtitle(uri: Uri) {
        val video = currentUri
        if (video == null) { Toast.makeText(this, "Open a video first", Toast.LENGTH_SHORT).show(); return }
        subtitleUri = uri
        historyPrefs.edit().putString("subtitle_${video}", uri.toString()).apply()
        val pos = player.currentPosition
        val wasPlaying = player.playWhenReady
        externalSubtitleCues = emptyList()
        externalSubtitleView.text = ""
        externalSubtitleView.visibility = View.GONE
        player.setMediaItem(buildVideoItem(video, uri))
        applySubtitleStyle()
        player.prepare(); player.seekTo(pos); player.playWhenReady = wasPlaying
        if (isCustomSubtitle(uri)) loadExternalSubtitle(uri)
        Toast.makeText(this, "Subtitle loaded", Toast.LENGTH_SHORT).show()
    }

    private fun loadExternalSubtitle(uri: Uri) {
        val requestUri = uri.toString()
        subtitleExecutor.execute {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: throw IllegalStateException("Unable to read subtitle")
                val cues = parseSubtitle(text, subtitleExtension(uri))
                handler.post {
                    if (currentUri != null && historyPrefs.getString("subtitle_${currentUri}", null) == requestUri) {
                        externalSubtitleCues = cues
                        applySubtitleStyle()
                        updateExternalSubtitle()
                    }
                }
            } catch (_: Exception) {
                handler.post { Toast.makeText(this, "Could not read subtitle file", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun parseSubtitle(source: String, extension: String): List<SubtitleCue> {
        val normalized = source.replace("\r\n", "\n").replace('\r', '\n')
        if (extension == "vtt") return parseVtt(normalized)
        return parseSrt(normalized)
    }

    private fun parseSrt(source: String): List<SubtitleCue> {
        return source.split(Regex("\\n\\s*\\n")).mapNotNull { block ->
            val lines = block.lines().filter { it.isNotBlank() }
            if (lines.size < 2) return@mapNotNull null
            val timingIndex = lines.indexOfFirst { it.contains(" --> ") }
            if (timingIndex < 0 || timingIndex + 1 >= lines.size) return@mapNotNull null
            val parts = lines[timingIndex].split(" --> ")
            if (parts.size != 2) return@mapNotNull null
            val start = parseSubtitleTime(parts[0]) ?: return@mapNotNull null
            val end = parseSubtitleTime(parts[1].split(' ').first()) ?: return@mapNotNull null
            val body = lines.drop(timingIndex + 1).joinToString("\n").trim()
            if (body.isBlank()) null else SubtitleCue(start, end, body)
        }.sortedBy { it.startMs }
    }

    private fun parseVtt(source: String): List<SubtitleCue> {
        return source.lines().dropWhile { !it.contains("WEBVTT", ignoreCase = true) }.drop(1)
            .joinToString("\n").split(Regex("\\n\\s*\\n")).mapNotNull { block ->
                val lines = block.lines().filter { it.isNotBlank() }
                val timingIndex = lines.indexOfFirst { it.contains(" --> ") }
                if (timingIndex < 0 || timingIndex + 1 >= lines.size) return@mapNotNull null
                val parts = lines[timingIndex].split(" --> ")
                if (parts.size != 2) return@mapNotNull null
                val start = parseSubtitleTime(parts[0]) ?: return@mapNotNull null
                val end = parseSubtitleTime(parts[1].trim().split(' ').first()) ?: return@mapNotNull null
                val body = lines.drop(timingIndex + 1).joinToString("\n").trim()
                if (body.isBlank()) null else SubtitleCue(start, end, body)
            }.sortedBy { it.startMs }
    }

    private fun parseSubtitleTime(value: String): Long? {
        val cleaned = value.trim().replace(',', '.')
        val parts = cleaned.split(':')
        return try {
            val seconds = when (parts.size) {
                3 -> parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toDouble()
                2 -> parts[0].toLong() * 60 + parts[1].toDouble()
                else -> return null
            }
            (seconds * 1000.0).roundToInt().toLong()
        } catch (_: Exception) { null }
    }

    private fun updateExternalSubtitle() {
        if (!::externalSubtitleView.isInitialized || externalSubtitleCues.isEmpty() || !::player.isInitialized) return
        val adjustedPosition = player.currentPosition - subtitleSyncMs
        var low = 0
        var high = externalSubtitleCues.lastIndex
        var candidate = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (externalSubtitleCues[mid].startMs <= adjustedPosition) {
                candidate = mid
                low = mid + 1
            } else high = mid - 1
        }
        val cue = if (candidate >= 0) externalSubtitleCues[candidate] else null
        if (cue != null && adjustedPosition <= cue.endMs) {
            if (externalSubtitleView.text.toString() != cue.text) externalSubtitleView.text = cue.text
            externalSubtitleView.visibility = View.VISIBLE
        } else {
            externalSubtitleView.visibility = View.GONE
        }
    }

    private fun showSubtitleSyncDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(4)) }
        val valueLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, dp(8)) }
        val bar = SeekBar(this).apply { max = 10000; progress = subtitleSyncMs + 5000 }
        fun updateLabel() {
            subtitleSyncMs = (bar.progress - 5000).coerceIn(-5000, 5000)
            valueLabel.text = if (subtitleSyncMs == 0) "No delay" else if (subtitleSyncMs > 0) "+${subtitleSyncMs} ms" else "${subtitleSyncMs} ms"
            historyPrefs.edit().putInt("subtitle_sync_ms", subtitleSyncMs).apply()
            updateExternalSubtitle()
        }
        box.addView(valueLabel); box.addView(bar)
        updateLabel()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) updateLabel() }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        AlertDialog.Builder(this).setTitle("Subtitle synchronization").setMessage("Positive values delay subtitles; negative values make them appear earlier.")
            .setView(box).setPositiveButton("Done", null).setNeutralButton("Reset") { _, _ -> subtitleSyncMs = 0; historyPrefs.edit().putInt("subtitle_sync_ms", 0).apply(); updateExternalSubtitle() }.show()
    }

    private val previewRunnable = Runnable {
        val uri = currentUri ?: return@Runnable
        val requestId = ++previewRequestId
        val target = pendingPreviewPositionMs
        previewFuture?.cancel(true)
        previewFuture = previewExecutor.submit {
            try {
                if (previewRetrieverUri != uri || previewRetriever == null) {
                    try { previewRetriever?.release() } catch (_: Exception) { }
                    previewRetriever = MediaMetadataRetriever()
                    contentResolver.openFileDescriptor(uri, "r")?.use { previewRetriever!!.setDataSource(it.fileDescriptor) }
                        ?: throw IllegalStateException("Unable to open video")
                    previewRetrieverUri = uri
                }
                val bucket = (target / 250L) * 250L
                val cacheKey = "${uri}#$bucket"
                val cached = previewCache.get(cacheKey)
                val bitmap = cached ?: previewRetriever!!.getFrameAtTime(bucket * 1000L, MediaMetadataRetriever.OPTION_CLOSEST)?.also {
                    previewCache.put(cacheKey, it)
                }
                handler.post {
                    if (requestId == previewRequestId && userSeeking && bitmap != null) {
                        previewImage.setImageBitmap(bitmap)
                        previewImage.visibility = View.VISIBLE
                    }
                }
            } catch (_: Exception) {
                handler.post { if (requestId == previewRequestId && userSeeking) previewImage.visibility = View.GONE }
            }
        }
    }

    private fun showSeekPreview(positionMs: Long) {
        pendingPreviewPositionMs = positionMs.coerceAtLeast(0L)
        handler.removeCallbacks(previewRunnable)
        handler.postDelayed(previewRunnable, 25L)
    }

    private fun showFitOptions() {
        val labels = fitModeNames.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Screen fit")
            .setSingleChoiceItems(labels, fitMode) { dialog, which ->
                fitMode = which
                playerView.resizeMode = fitModes[fitMode]
                zoomScale = 1f; panX = 0f; panY = 0f; applyZoom()
                historyPrefs.edit().putInt("fit_mode", fitMode).apply()
                fitButton.contentDescription = "Screen fit: ${fitModeNames[fitMode]}"
                dialog.dismiss()
                showControlsTemporarily()
            }
            .setNegativeButton("More options", null)
            .show()
    }

    private fun showMoreDialog() {
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        fun section(title: String) {
            val v = TextView(this).apply {
                text = title.uppercase(Locale.getDefault())
                textSize = 12f
                setTextColor(0xFF8AB4F8.toInt())
                setPadding(dp(12), dp(14), dp(12), dp(6))
            }
            content.addView(v)
        }
        fun action(title: String, onClick: () -> Unit) {
            val v = TextView(this).apply {
                text = title
                textSize = 15f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(14), dp(13))
                background = roundedBackground(0xFF252525.toInt(), 12)
                isClickable = true
                setOnClickListener { onClick() }
            }
            content.addView(v, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(6) })
        }

        section("Playback")
        action("Resume current video") {
            val uri = currentUri
            if (uri != null) player.seekTo(historyPrefs.getLong("pos_${uri}", player.currentPosition))
            else Toast.makeText(this, "No current video", Toast.LENGTH_SHORT).show()
        }
        action("Playback history") { showHistoryDialog() }
        action("Seek amount · ${seekSeconds} sec") { showSeekAmountDialog() }
        action("Gesture sensitivity · ${gestureSensitivity}×") { showGestureSensitivityDialog() }
        action("Long-press speed · 2×") { Toast.makeText(this, "Press and hold the video surface for 2× speed. Release to return to your normal speed.", Toast.LENGTH_LONG).show() }
        action("Auto Skip Silence · ${when (autoSkipMode) { 1 -> "Mild"; 2 -> "Strong"; else -> "Off" }}") { showAutoSkipSilenceDialog() }
        action("Fast seeking · ${if (fastSeekEnabled) "On" else "Off"}") { showFastSeekDialog() }
        action("Repeat · ${repeatName()}") { showRepeatDialog() }
        action("Video information") { showVideoInfo() }

        section("Display")
        action("Screen fit · ${fitModeNames[fitMode]}") { showFitOptions() }
        action("Orientation") { showOrientationDialog() }
        action("Pinch zoom · ${(zoomScale * 100).roundToInt()}%") { resetZoom(); Toast.makeText(this, "Zoom reset", Toast.LENGTH_SHORT).show() }
        action("Subtitle appearance") { showSubtitleAppearanceDialog() }
        action("Haptic feedback · ${if (hapticsEnabled) "On" else "Off"}") { showHapticsDialog() }

        section("Decoder")
        action("Decoder · ${decoderName()}") { showDecoderDialog() }

        section("Audio & subtitles")
        action("Volume boost · ${volumePercent}%") { showVolumeDialog() }
        action("Reset volume to 100%") { applyGestureVolume(100); Toast.makeText(this, "Volume reset to 100%", Toast.LENGTH_SHORT).show() }
        action("Voice Clarity · ${if (voiceClarityEnabled) "On" else "Off"}") { showVoiceClarityDialog() }
        action("Audio / subtitle tracks") { showTrackDialog() }
        action("Load subtitle file") { pickSubtitle.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "application/octet-stream")) }
        action("Subtitle synchronization · ${if (subtitleSyncMs > 0) "+" else ""}${subtitleSyncMs} ms") { showSubtitleSyncDialog() }
                action("Picture-in-picture") { enterPip() }
        action("Background play · ${if (isBackgroundPlaybackActive()) "On" else "Off"}") { toggleBackgroundPlayback() }
        action("Automatic picture-in-picture · ${if (autoPictureInPicture) "On" else "Off"}") {
            autoPictureInPicture = !autoPictureInPicture
            historyPrefs.edit().putBoolean("auto_pip", autoPictureInPicture).apply()
            Toast.makeText(this, "Automatic picture-in-picture ${if (autoPictureInPicture) "on" else "off"}", Toast.LENGTH_SHORT).show()
        }

        section("Library")
        action("Delete playback history") { confirmDeleteHistory() }
        action("Clear saved resume positions") { confirmClearResumePositions() }
        action("Choose video folder") { pickFolder.launch(null) }
        action("Videos in saved folder") { showFolderVideos() }

        scroll.addView(content)
        val dialog = AlertDialog.Builder(this).setTitle("Alvi Player").setView(scroll).setNegativeButton("Close", null).create()
        dialog.show()
    }

    private fun buildPlayer() {
        val factory = AlviRenderersFactory(this, decoderMode, autoSkipMode)
        if (::player.isInitialized) {
            try { player.release() } catch (_: Exception) {}
        }
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        player = ExoPlayer.Builder(this, factory)
            .setSkipSilenceEnabled(autoSkipMode > 0)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.repeatMode = repeatMode
        player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
        voiceClarityAppliedSessionId = 0
        playerView.player = player
        playerView.useController = false
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val transitionedUri = mediaItem?.localConfiguration?.uri
                if (transitionedUri != null) {
                    currentUri = transitionedUri
                    lastVideoTitle = displayName(transitionedUri)
                    historyPrefs.edit().putString("last_uri", transitionedUri.toString()).putString("name_$transitionedUri", lastVideoTitle).apply()
                    val saved = historyPrefs.getLong("pos_$transitionedUri", 0L)
                    if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && saved > 0L && player.currentPosition < 1500L) player.seekTo(saved)
                    val savedSubtitle = historyPrefs.getString("subtitle_$transitionedUri", null)?.let(Uri::parse)
                    subtitleUri = savedSubtitle
                    externalSubtitleCues = emptyList()
                    externalSubtitleView.visibility = View.GONE
                    if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
                }
                applySubtitleStyle(); updateUi(); updateTitle()
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                voiceClarityAppliedSessionId = 0
                applyVoiceClarityIfNeeded()
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) { updateScreenAwake(isPlaying); updateUi() }
            override fun onPlaybackStateChanged(playbackState: Int) { updateUi() }
            override fun onPlayerError(error: PlaybackException) {
                if (error is androidx.media3.exoplayer.ExoPlaybackException && error.type == androidx.media3.exoplayer.ExoPlaybackException.TYPE_RENDERER && decoderMode == 1) {
                    try {
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true).build()
                        player.prepare(); player.playWhenReady = true
                        Toast.makeText(this@MainActivity, "Unsupported audio codec; retrying video without audio", Toast.LENGTH_LONG).show()
                        return
                    } catch (_: Exception) {}
                }
                Toast.makeText(this@MainActivity, "Playback error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun switchDecoder(mode: Int) {
        if (decoderMode == mode) return
        saveCurrentProgress()
        val uri = currentUri
        val pos = if (::player.isInitialized) player.currentPosition else 0L
        val playing = ::player.isInitialized && player.playWhenReady
        decoderMode = mode
        historyPrefs.edit().putInt("decoder_mode", mode).apply()
        buildPlayer()
        player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
        handler.postDelayed({ if (::player.isInitialized) applyGestureVolume(volumePercent) }, 350L)
        if (uri != null) {
            val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
            subtitleUri = savedSubtitle
            externalSubtitleCues = emptyList()
            externalSubtitleView.visibility = View.GONE
            player.setMediaItem(if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri))
            player.prepare(); player.seekTo(pos); player.setPlaybackSpeed(selectedSpeed); player.playWhenReady = playing
            if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
        }
        showControlsTemporarily()
    }

    private fun decoderName() = when (decoderMode) { 0 -> "HW"; 1 -> "HW+"; else -> "SW" }

    private fun showDecoderDialog() {
        val labels = arrayOf(
            "HW — hardware decoder only",
            "HW+ — hardware with decoder fallback",
            "SW — software preferred"
        )
        AlertDialog.Builder(this).setTitle("Decoder")
            .setSingleChoiceItems(labels, decoderMode) { dialog, which ->
                switchDecoder(which); dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showOrientationDialog() {
        val labels = arrayOf("Landscape", "Portrait")
        val checked = if (orientationMode == 2) 1 else 0
        AlertDialog.Builder(this).setTitle("Orientation")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                orientationMode = if (which == 1) 2 else 1
                historyPrefs.edit().putInt("orientation_mode", orientationMode).apply()
                applyOrientationMode(); dialog.dismiss()
            }.show()
    }

    private fun toggleOrientation() {
        orientationMode = if (orientationMode == 1) 2 else 1
        historyPrefs.edit().putInt("orientation_mode", orientationMode).apply()
        applyOrientationMode(); haptic()
    }

    private fun applyOrientationMode() {
        requestedOrientation = if (orientationMode == 2) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    private fun showHapticsDialog() {
        hapticsEnabled = !hapticsEnabled
        historyPrefs.edit().putBoolean("haptics", hapticsEnabled).apply()
        Toast.makeText(this, "Haptic feedback ${if (hapticsEnabled) "on" else "off"}", Toast.LENGTH_SHORT).show()
    }

    private fun haptic() {
        if (hapticsEnabled) root.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun resetZoom() { zoomScale = 1f; panX = 0f; panY = 0f; playerView.resizeMode = fitModes[fitMode]; applyZoom() }
    private fun applyZoom() {
        playerView.scaleX = zoomScale
        playerView.scaleY = zoomScale
        playerView.translationX = panX.coerceIn(-root.width * (zoomScale - 1f) / 2f, root.width * (zoomScale - 1f) / 2f)
        playerView.translationY = panY.coerceIn(-root.height * (zoomScale - 1f) / 2f, root.height * (zoomScale - 1f) / 2f)
    }

    private fun applyVoiceClarityIfNeeded() {
        if (!voiceClarityEnabled || !::player.isInitialized || player.audioSessionId == 0) return
        val sessionId = player.audioSessionId
        if (voiceClarityAppliedSessionId == sessionId && voiceClarityEqualizer != null) return
        try {
            voiceClarityEqualizer?.release()
            val eq = Equalizer(0, sessionId)
            eq.enabled = false
            val bandCount = eq.numberOfBands.toInt()
            val range = eq.bandLevelRange
            val minLevel = range[0].toInt()
            val maxLevel = range[1].toInt()
            for (bandIndex in 0 until bandCount) {
                val centerHz = eq.getCenterFreq(bandIndex.toShort()) / 1000
                val gainDb = when {
                    centerHz < 180 -> -2.0
                    centerHz < 500 -> -1.0
                    centerHz < 1200 -> 2.0
                    centerHz < 3500 -> 4.0
                    centerHz < 7000 -> 2.0
                    else -> 0.5
                }
                val level = (gainDb * 100).roundToInt().coerceIn(minLevel, maxLevel).toShort()
                eq.setBandLevel(bandIndex.toShort(), level)
            }
            eq.enabled = true
            voiceClarityEqualizer = eq
            voiceClarityAppliedSessionId = sessionId
        } catch (_: Exception) {
            voiceClarityEqualizer?.release()
            voiceClarityEqualizer = null
            voiceClarityAppliedSessionId = 0
        }
    }

    private fun disableVoiceClarity() {
        try { voiceClarityEqualizer?.enabled = false } catch (_: Exception) {}
        try { voiceClarityEqualizer?.release() } catch (_: Exception) {}
        voiceClarityEqualizer = null
        voiceClarityAppliedSessionId = 0
    }

    private fun autoSkipIcon(): String = when (autoSkipMode) {
        1 -> "≋✓"
        2 -> "≋✓✓"
        else -> "≋"
    }

    private fun decoderShortLabel(): String = when (decoderMode) {
        0 -> "HW"
        1 -> "HW+"
        else -> "SW"
    }

    private fun showAutoSkipSilenceDialog() {
        val labels = arrayOf("Off", "Mild — keep natural pauses", "Strong — tighter podcast-style skipping")
        AlertDialog.Builder(this)
            .setTitle("Auto Skip Silence")
            .setSingleChoiceItems(labels, autoSkipMode) { dialog, which ->
                autoSkipMode = which
                autoSkipSilence = which > 0
                historyPrefs.edit().putInt("auto_skip_mode", autoSkipMode).putBoolean("auto_skip_silence", autoSkipSilence).apply()
                val uri = currentUri
                val pos = if (::player.isInitialized) player.currentPosition else 0L
                val playing = ::player.isInitialized && player.playWhenReady
                val speed = selectedSpeed
                buildPlayer()
                if (uri != null) {
                    val savedSubtitle = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
                    subtitleUri = savedSubtitle
                    player.setMediaItem(if (savedSubtitle != null) buildVideoItem(uri, savedSubtitle) else MediaItem.fromUri(uri))
                    player.prepare(); player.seekTo(pos); player.setPlaybackSpeed(speed); player.playWhenReady = playing
                    if (savedSubtitle != null && isCustomSubtitle(savedSubtitle)) loadExternalSubtitle(savedSubtitle)
                }
                autoSkipButton.text = autoSkipIcon()
                Toast.makeText(this, "Auto Skip Silence: ${labels[which]}", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun showVoiceClarityDialog() {
        if (!::player.isInitialized || player.audioSessionId == 0) {
            Toast.makeText(this, "Play a video first to use Voice Clarity", Toast.LENGTH_SHORT).show()
            return
        }
        voiceClarityEnabled = !voiceClarityEnabled
        historyPrefs.edit().putBoolean("voice_clarity", voiceClarityEnabled).apply()
        if (voiceClarityEnabled) {
            voiceClarityAppliedSessionId = 0
            applyVoiceClarityIfNeeded()
            if (voiceClarityEqualizer != null) {
                clarityButton.text = "✦✓"
                Toast.makeText(this, "Voice Clarity on", Toast.LENGTH_SHORT).show()
            } else {
                voiceClarityEnabled = false
                historyPrefs.edit().putBoolean("voice_clarity", false).apply()
                Toast.makeText(this, "Voice Clarity is not supported on this device", Toast.LENGTH_LONG).show()
            }
        } else {
            disableVoiceClarity()
            clarityButton.text = "✦"
            Toast.makeText(this, "Voice Clarity off", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showVideoInfo() {
        val duration = if (::player.isInitialized) player.duration else C.TIME_UNSET
        val tracks = if (::player.isInitialized) player.currentTracks.groups.size else 0
        val vf = if (::player.isInitialized) player.videoFormat else null
        val af = if (::player.isInitialized) player.audioFormat else null
        val videoLine = vf?.let { "${it.width}×${it.height} · ${it.sampleMimeType ?: "unknown"}${it.frameRate.takeIf { r -> r > 0f }?.let { r -> " · ${String.format(Locale.getDefault(), "%.2f", r)} fps" } ?: ""}" } ?: "—"
        val audioLine = af?.let { "${it.sampleMimeType ?: "unknown"} · ${it.channelCount} ch · ${if (it.sampleRate > 0) "${it.sampleRate} Hz" else "sample rate n/a"}" } ?: "—"
        AlertDialog.Builder(this).setTitle(lastVideoTitle)
            .setMessage("Duration: ${formatMs(duration)}\nSpeed: ${speedLabel(selectedSpeed)}\nDecoder: ${decoderName()}\nVideo: $videoLine\nAudio: $audioLine\nTracks: $tracks\nFast seeking: ${if (fastSeekEnabled) "On" else "Off"}\nAuto skip silence: ${when (autoSkipMode) { 1 -> "Mild"; 2 -> "Strong"; else -> "Off" }}")
            .setPositiveButton("Close", null).show()
    }

    private fun isBackgroundPlaybackActive(): Boolean =
        historyPrefs.getBoolean(BackgroundPlaybackService.KEY_ACTIVE, false)

    private fun toggleBackgroundPlayback() {
        val uri = currentUri
        if (uri == null || !::player.isInitialized || player.mediaItemCount == 0) {
            Toast.makeText(this, "Open a video first", Toast.LENGTH_SHORT).show()
            return
        }
        if (isBackgroundPlaybackActive()) {
            stopService(Intent(this, BackgroundPlaybackService::class.java).apply { action = BackgroundPlaybackService.ACTION_STOP })
            historyPrefs.edit().putBoolean(BackgroundPlaybackService.KEY_ACTIVE, false).apply()
            Toast.makeText(this, "Background playback stopped", Toast.LENGTH_SHORT).show()
            return
        }
        val position = player.currentPosition.coerceAtLeast(0L)
        val intent = Intent(this, BackgroundPlaybackService::class.java).apply {
            putExtra(BackgroundPlaybackService.EXTRA_URI, uri.toString())
            putExtra(BackgroundPlaybackService.EXTRA_POSITION, position)
            putExtra(BackgroundPlaybackService.EXTRA_SPEED, selectedSpeed)
            putExtra(BackgroundPlaybackService.EXTRA_TITLE, displayName(uri))
            putExtra(BackgroundPlaybackService.EXTRA_REPEAT, repeatMode)
            putStringArrayListExtra(BackgroundPlaybackService.EXTRA_PLAYLIST, ArrayList(queuedFolderUris.ifEmpty { listOf(uri) }.map { it.toString() }))
            putExtra(BackgroundPlaybackService.EXTRA_START_INDEX, queuedFolderUris.indexOf(uri).takeIf { it >= 0 } ?: 0)
        }
        try {
            if (notificationStarted) {
                stopService(Intent(this, PlaybackNotificationService::class.java))
                notificationStarted = false
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            player.pause()
            saveCurrentProgress()
            Toast.makeText(this, "Background play started · audio continues with screen off", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Background playback could not be started", Toast.LENGTH_LONG).show()
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !::player.isInitialized || player.mediaItemCount == 0) { Toast.makeText(this, "Picture-in-picture is unavailable", Toast.LENGTH_SHORT).show(); return }
        try { enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()) } catch (_: Exception) { Toast.makeText(this, "Picture-in-picture is unavailable on this device", Toast.LENGTH_SHORT).show() }
    }

    private fun confirmDeleteHistory() {
        AlertDialog.Builder(this).setTitle("Delete playback history?")
            .setMessage("This removes only the playback history list. Saved resume positions and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                val editor = historyPrefs.edit()
                historyPrefs.all.keys.filter { it.startsWith("history_") || it.startsWith("name_") }.forEach { editor.remove(it) }
                editor.apply()
                Toast.makeText(this, "Playback history deleted", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun confirmClearResumePositions() {
        AlertDialog.Builder(this).setTitle("Clear saved resume positions?")
            .setMessage("This removes saved playback positions only. Playback history and the last-video setting will be preserved.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                historyPrefs.edit().apply {
                    historyPrefs.all.keys.filter { it.startsWith("pos_") }.forEach { remove(it) }
                    apply()
                }
                Toast.makeText(this, "Saved resume positions cleared", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showHistoryDialog() {
        val history = historyPrefs.all.entries
            .filter { it.key.startsWith("history_") && it.value is String }
            .sortedByDescending { it.key.removePrefix("history_").toLongOrNull() ?: 0L }
            .map { Uri.parse(it.value.toString()) }
            .distinctBy { it.toString() }
            .take(30)
        if (history.isEmpty()) {
            // Backward compatibility with older builds that stored name_<uri>.
            val legacy = historyPrefs.all.keys.filter { it.startsWith("name_") }.map { Uri.parse(it.removePrefix("name_")) }.distinct().take(30)
            if (legacy.isEmpty()) { Toast.makeText(this, "No playback history yet", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("Playback history").setItems(legacy.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(legacy[index], true) }.setNegativeButton("Close", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Playback history")
            .setItems(history.map { displayName(it) }.toTypedArray()) { _, index -> openVideo(history[index], true) }
            .setNegativeButton("Close", null).show()
    }

    private fun showTrackDialog() {
        if (!::player.isInitialized) return
        val tracks = player.currentTracks.groups
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        for (group in tracks) {
            val type = group.type
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                val typeName = if (type == C.TRACK_TYPE_AUDIO) "Audio" else "Subtitle"
                val language = format.language ?: "und"
                options.add("$typeName · $language${if (format.label != null) " · ${format.label}" else ""}")
                actions.add {
                    val builder = player.trackSelectionParameters.buildUpon()
                    builder.setTrackTypeDisabled(type, false)
                    builder.setOverrideForType(androidx.media3.common.TrackSelectionOverride(group.mediaTrackGroup, listOf(i)))
                    player.trackSelectionParameters = builder.build()
                }
            }
        }
        if (options.isEmpty()) { Toast.makeText(this, "No alternate audio or subtitle tracks in this video", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Available tracks").setItems(options.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNeutralButton("Disable subtitles") { _, _ -> player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build() }
            .setNegativeButton("Close", null).show()
    }

    private fun showAudioDelayDialog() {
        val values = intArrayOf(-500, -250, -100, 0, 100, 250, 500)
        val labels = values.map { if (it > 0) "+${it} ms" else "$it ms" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Audio delay")
            .setSingleChoiceItems(labels, values.indexOf(audioDelayMs).coerceAtLeast(0)) { dialog, which ->
                audioDelayMs = values[which]
                Toast.makeText(this, "Audio delay preference saved. Subtitle synchronization is available separately for external SRT/VTT subtitles.", Toast.LENGTH_LONG).show()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showFolderVideos() {
        val folder = historyPrefs.getString("folder_uri", null)?.let(Uri::parse)
        if (folder == null) { Toast.makeText(this, "Choose a folder first", Toast.LENGTH_SHORT).show(); pickFolder.launch(null); return }
        try {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(folder, DocumentsContract.getTreeDocumentId(folder))
            val found = mutableListOf<Pair<String, Uri>>()
            contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0); val name = c.getString(1) ?: "Video"; val mime = c.getString(2) ?: ""
                    if (mime.startsWith("video/")) found.add(name to DocumentsContract.buildDocumentUriUsingTree(folder, id))
                }
            }
            if (found.isEmpty()) { Toast.makeText(this, "No videos found directly in this folder", Toast.LENGTH_LONG).show(); return }
            val names = found.map { it.first }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Folder videos")
                .setItems(names) { _, index -> playFolder(found.map { it.second }, index) }
                .setNeutralButton("Play all") { _, _ -> playFolder(found.map { it.second }, 0) }
                .setNegativeButton("Close", null).show()
        } catch (_: Exception) { Toast.makeText(this, "Could not read this folder", Toast.LENGTH_SHORT).show() }
    }

    private fun playFolder(uris: List<Uri>, startIndex: Int) {
        if (uris.isEmpty()) return
        saveCurrentProgress()
        queuedFolderUris = uris
        val items = uris.map { uri ->
            val sub = historyPrefs.getString("subtitle_$uri", null)?.let(Uri::parse)
            if (sub != null && !isCustomSubtitle(sub)) buildVideoItem(uri, sub) else MediaItem.fromUri(uri)
        }
        currentUri = uris[startIndex.coerceIn(0, uris.lastIndex)]
        lastVideoTitle = displayName(currentUri!!)
        externalSubtitleCues = emptyList()
        externalSubtitleView.visibility = View.GONE
        player.setMediaItems(items, startIndex.coerceIn(0, items.lastIndex), historyPrefs.getLong("pos_${currentUri}", 0L))
        player.prepare()
        player.setPlaybackSpeed(selectedSpeed)
        player.playWhenReady = true
        player.repeatMode = repeatMode
        historyPrefs.edit().putString("last_uri", currentUri.toString()).apply()
        selectButton.visibility = View.GONE
        setControlsVisible(false)
        updateTitle(); updateUi()
    }

    private fun repeatName(): String = when (repeatMode) {
        Player.REPEAT_MODE_ONE -> "One"
        Player.REPEAT_MODE_ALL -> "All"
        else -> "Off"
    }

    private fun showRepeatDialog() {
        val labels = arrayOf("Off", "Repeat one", "Repeat all")
        val modes = intArrayOf(Player.REPEAT_MODE_OFF, Player.REPEAT_MODE_ONE, Player.REPEAT_MODE_ALL)
        val checked = modes.indexOf(repeatMode).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Repeat")
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                repeatMode = modes[which]
                historyPrefs.edit().putInt("repeat_mode", repeatMode).apply()
                if (::player.isInitialized) player.repeatMode = repeatMode
                haptic(); dialog.dismiss(); showControlsTemporarily()
            }.setNegativeButton("Close", null).show()
    }

    private fun showFastSeekDialog() {
        val labels = arrayOf("On — faster, nearby keyframe", "Off — exact seeking")
        AlertDialog.Builder(this).setTitle("Fast seeking")
            .setSingleChoiceItems(labels, if (fastSeekEnabled) 0 else 1) { dialog, which ->
                fastSeekEnabled = which == 0
                historyPrefs.edit().putBoolean("fast_seek", fastSeekEnabled).apply()
                if (::player.isInitialized) player.setSeekParameters(if (fastSeekEnabled) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)
                Toast.makeText(this, if (fastSeekEnabled) "Fast seeking enabled" else "Exact seeking enabled", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }.setNegativeButton("Close", null).show()
    }

    private fun speedLabel(speed: Float) = if (speed % 1f == 0f) "${speed.toInt()}×" else "${speed}×"


    private fun showSpeedDialog() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        val dialog = AlertDialog.Builder(this).setTitle("Playback speed").setView(scroll).setNegativeButton("Close", null).create()
        speeds.forEach { value ->
            val b = button("${value}×")
            b.setPadding(dp(12), dp(12), dp(12), dp(12))
            if (value == selectedSpeed) b.setBackgroundColor(0xFF1769AA.toInt())
            row.addView(b, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
            b.setOnClickListener {
                selectedSpeed = value
                historyPrefs.edit().putFloat("selected_speed", selectedSpeed).apply()
                if (::player.isInitialized) player.setPlaybackSpeed(selectedSpeed)
                speedButton.text = "◷ ${speedLabel(value)}"
                updateUi(); dialog.dismiss(); showControlsTemporarily()
            }
        }
        dialog.show()
    }

    private fun applyGestureVolume(percent: Int) {
        volumePercent = percent.coerceIn(0, 200)
        historyPrefs.edit().putInt("volume_percent", volumePercent).apply()
        try {
            if (player.audioSessionId != 0) {
                volumeBoostEnhancer?.release()
                volumeBoostEnhancer = null
                if (volumePercent > 100) {
                    volumeBoostEnhancer = LoudnessEnhancer(player.audioSessionId).apply {
                        val gainDb = 20.0 * kotlin.math.log10(volumePercent / 100.0)
                        setTargetGain((gainDb * 100).roundToInt())
                        enabled = true
                    }
                }
                // 0–100% uses player volume; 100–200% uses LoudnessEnhancer gain.
                player.volume = if (volumePercent <= 100) volumePercent / 100f else 1f
            }
        } catch (_: Exception) {
            // Some devices do not expose LoudnessEnhancer. Fall back to the hardware volume range.
            val audio = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            val maxVol = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                (maxVol * volumePercent / 200f).roundToInt().coerceIn(0, maxVol), 0)
        }
    }

    private fun showSeekAmountDialog() {
        val values = intArrayOf(5, 10, 15, 20, 30)
        val labels = values.map { "$it seconds" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Double-tap seek amount")
            .setSingleChoiceItems(labels, values.indexOf(seekSeconds).coerceAtLeast(0)) { dialog, which ->
                seekSeconds = values[which]
                historyPrefs.edit().putInt("seek_seconds", seekSeconds).apply()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showGestureSensitivityDialog() {
        val values = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = values.map { "${it}×" }.toTypedArray()
        val selected = values.indexOfFirst { abs(it - gestureSensitivity) < 0.01f }.coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("Gesture sensitivity")
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                gestureSensitivity = values[which]
                historyPrefs.edit().putFloat("gesture_sensitivity", gestureSensitivity).apply()
                dialog.dismiss()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSubtitleAppearanceDialog() {
        val sizes = floatArrayOf(0.04f, 0.0533f, 0.065f, 0.08f)
        val positions = floatArrayOf(0.03f, 0.08f, 0.14f, 0.22f)
        val labels = sizes.map { "${(it / 0.0533f * 100).roundToInt()}% size" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Subtitle size")
            .setSingleChoiceItems(labels, sizes.indexOfFirst { abs(it - subtitleSize) < 0.005f }.coerceAtLeast(0)) { dialog, which ->
                subtitleSize = sizes[which]
                historyPrefs.edit().putFloat("subtitle_size", subtitleSize).apply()
                applySubtitleStyle(); dialog.dismiss(); showSubtitlePositionDialog()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSubtitlePositionDialog() {
        val positions = floatArrayOf(0.03f, 0.08f, 0.14f, 0.22f)
        val labels = arrayOf("Near bottom", "Default", "Higher", "Much higher")
        AlertDialog.Builder(this).setTitle("Subtitle position")
            .setSingleChoiceItems(labels, positions.indexOfFirst { abs(it - subtitleBottom) < 0.01f }.coerceAtLeast(0)) { dialog, which ->
                subtitleBottom = positions[which]
                historyPrefs.edit().putFloat("subtitle_bottom", subtitleBottom).apply()
                applySubtitleStyle(); dialog.dismiss()
            }.setNegativeButton("Skip", null).show()
    }

    private fun showVolumeDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(8)) }
        val label = TextView(this).apply { text = "Volume: ${volumePercent}%"; setTextColor(Color.WHITE); textSize = 16f }
        val bar = SeekBar(this).apply { max = 200; progress = volumePercent }
        box.addView(label); box.addView(bar)
        val dialog = AlertDialog.Builder(this).setTitle("Amplified volume (up to 200%)").setView(box).setPositiveButton("Done", null).create()
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                applyGestureVolume(progress)
                label.text = "Volume: ${volumePercent}%"
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        dialog.show()
    }

    private fun toggleVoiceClarity() = showVoiceClarityDialog()

    private fun showGestureHint(text: String) {
        gestureHint.text = text
        gestureHint.visibility = View.VISIBLE
    }

    private fun toggleControls() = setControlsVisible(!controlsVisible)

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible && !locked && !isInPictureInPictureMode
        if (player.mediaItemCount == 0) {
            topBar.visibility = View.VISIBLE
            topBar.alpha = 1f
            selectButton.visibility = View.VISIBLE
            speedButton.visibility = View.GONE
            clarityButton.visibility = View.GONE
            decoderButton.visibility = View.GONE
            subtitleButton.visibility = View.GONE
            autoSkipButton.visibility = View.GONE
            previousButton.visibility = View.GONE
            nextButton.visibility = View.GONE
            playPauseButton.visibility = View.GONE
            lockButton.visibility = View.GONE
            bottomBar.visibility = View.GONE
            fitButton.visibility = View.GONE
            orientationButton.visibility = View.GONE
            leftTools.visibility = View.GONE
        } else {
            selectButton.visibility = View.VISIBLE
            if (controlsVisible) {
                topBar.visibility = View.VISIBLE
                bottomBar.visibility = View.VISIBLE
                speedButton.visibility = View.VISIBLE
                clarityButton.visibility = View.VISIBLE
                decoderButton.visibility = View.VISIBLE
                subtitleButton.visibility = View.VISIBLE
                autoSkipButton.visibility = View.VISIBLE
                previousButton.visibility = if (player.mediaItemCount > 1) View.VISIBLE else View.GONE
                nextButton.visibility = if (player.mediaItemCount > 1) View.VISIBLE else View.GONE
                playPauseButton.visibility = View.VISIBLE
                lockButton.visibility = if (!locked) View.VISIBLE else View.GONE
                fitButton.visibility = if (!locked) View.VISIBLE else View.GONE
                orientationButton.visibility = if (!locked) View.VISIBLE else View.GONE
                leftTools.visibility = View.VISIBLE
                topBar.animate().alpha(1f).setDuration(160L).start()
                bottomBar.animate().alpha(1f).setDuration(160L).start()
            } else {
                topBar.animate().alpha(0f).setDuration(150L).withEndAction { if (!controlsVisible) topBar.visibility = View.GONE }.start()
                bottomBar.animate().alpha(0f).setDuration(150L).withEndAction { if (!controlsVisible) bottomBar.visibility = View.GONE }.start()
                speedButton.visibility = View.GONE
                clarityButton.visibility = View.GONE
                decoderButton.visibility = View.GONE
                subtitleButton.visibility = View.GONE
                    autoSkipButton.visibility = View.GONE
                previousButton.visibility = View.GONE
                nextButton.visibility = View.GONE
                playPauseButton.visibility = View.GONE
                lockButton.visibility = View.GONE
                fitButton.visibility = View.GONE
                orientationButton.visibility = View.GONE
                leftTools.visibility = View.GONE
            }
        }
        if (controlsVisible) scheduleAutoHide() else cancelAutoHide()
    }

    private fun showControlsTemporarily() { setControlsVisible(true) }
    private fun scheduleAutoHide() {
        cancelAutoHide()
        handler.postDelayed(autoHideRunnable, 3500)
    }
    private fun cancelAutoHide() { handler.removeCallbacks(autoHideRunnable) }
    private val autoHideRunnable = Runnable { if (!userSeeking && !locked && player.mediaItemCount > 0) setControlsVisible(false) }

    private fun syncPlaybackNotification() {
        if (!::player.isInitialized || player.mediaItemCount == 0) {
            if (notificationStarted) {
                try { stopService(Intent(this, PlaybackNotificationService::class.java)) } catch (_: Exception) {}
                notificationStarted = false
            }
            return
        }
        val playing = player.isPlaying
        val title = lastVideoTitle
        if (notificationStarted && lastNotificationPlaying == playing && lastNotificationTitle == title) return
        val intent = Intent(this, PlaybackNotificationService::class.java).apply {
            action = PlaybackNotificationService.ACTION_UPDATE
            putExtra(PlaybackNotificationService.EXTRA_TITLE, title)
            putExtra(PlaybackNotificationService.EXTRA_PLAYING, playing)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
            notificationStarted = true
            lastNotificationPlaying = playing
            lastNotificationTitle = title
        } catch (_: Exception) {}
    }

    private fun updateTitle() {
        if (::titleView.isInitialized) titleView.text = lastVideoTitle
    }

    private fun updateUi() {
        if (!::player.isInitialized) return
        val duration = player.duration
        val current = max(0L, player.currentPosition)
        val validDuration = duration > 0 && duration != C.TIME_UNSET
        val remaining = if (validDuration) max(0L, duration - current) else C.TIME_UNSET
        val actualRemaining = if (remaining != C.TIME_UNSET) remaining else C.TIME_UNSET
        timeLeftText.text = ""
        // Always show real media elapsed/remaining time; playback speed does not alter these values.
        positionText.text = formatMs(current)
        durationText.text = formatMs(actualRemaining)
        positionText.contentDescription = "Elapsed ${formatMs(current)}"
        durationText.contentDescription = "Remaining ${formatMs(actualRemaining)}"
        if (!userSeeking) seekBar.progress = if (validDuration) (current * 1000L / duration).toInt().coerceIn(0, 1000) else 0
        updateExternalSubtitle()
        applyVoiceClarityIfNeeded()
        playPauseButton.text = if (player.isPlaying) "Ⅱ" else "▶"
        syncPlaybackNotification()
    }

    private val updateRunnable = object : Runnable {
        override fun run() { updateUi(); saveCurrentProgress(); handler.postDelayed(this, 1000) }
    }

    private fun iconButton(textValue: String, sizeSp: Float) = TextView(this).apply {
        text = textValue; textSize = sizeSp; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(6), dp(4), dp(6), dp(4))
        background = GradientDrawable().apply { setColor(0x00000000); cornerRadius = dp(28).toFloat() }
        isClickable = true; isFocusable = true
    }

    private fun button(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 14f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER; setPadding(dp(12), dp(8), dp(12), dp(8))
        background = roundedBackground(0xFF303030.toInt(), 12); isClickable = true; isFocusable = true
    }
    private fun roundedBackground(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue; textSize = 12f; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), 0, dp(6), 0)
    }
    private fun formatMs(ms: Long): String {
        if (ms == C.TIME_UNSET || ms < 0L) return "—"
        val totalSeconds = ms / 1000L
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)
        else String.format(Locale.getDefault(), "%d:%02d", minutes, seconds)
    }
    private fun updateScreenAwake(isPlaying: Boolean) {
        if (isPlaying) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).let { controller ->
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (autoPictureInPicture && Build.VERSION.SDK_INT >= 26 && ::player.isInitialized && player.isPlaying && !isInPictureInPictureMode) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) setControlsVisible(false)
    }

    override fun onStop() {
        saveCurrentProgress()
        super.onStop()
    }

    override fun onPause() {
        endTemporarySpeed()

        saveCurrentProgress()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == PlaybackNotificationService.ACTION_TOGGLE) {
            if (::player.isInitialized && player.mediaItemCount > 0) {
                if (player.isPlaying) player.pause() else player.play()
                updateUi(); showControlsTemporarily()
            }
            intent.action = null
        } else {
            handleIncomingIntent(intent)
        }
    }

    override fun onDestroy() {
        saveCurrentProgress()
        handler.removeCallbacks(updateRunnable)
        cancelAutoHide()
        volumeBoostEnhancer?.release()
        volumeBoostEnhancer = null
        disableVoiceClarity()
        subtitleExecutor.shutdownNow()
        handler.removeCallbacks(previewRunnable)
        previewRequestId++
        previewFuture?.cancel(true)
        try { previewRetriever?.release() } catch (_: Exception) { }
        previewRetriever = null
        previewRetrieverUri = null
        previewCache.evictAll()
        previewExecutor.shutdownNow()
        if (notificationStarted) {
            try { stopService(Intent(this, PlaybackNotificationService::class.java)) } catch (_: Exception) {}
            notificationStarted = false
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}
