package com.example.speedtimeplayer

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.core.content.IntentCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaSession

/**
 * Bluetooth / wired earphone and car button handling, shared by the on-screen session and the background service.
 *
 * Button map (earphone "play/pause" key, also called the headset hook):
 *  - 1 press  : play / pause
 *  - 2 presses: next video
 *  - 3 presses: previous video
 * Dedicated keys:
 *  - Play / Pause / Stop            : play, pause, pause
 *  - Next / Previous (short press)  : next / previous video (if there is none, jump the seek amount instead)
 *  - Next / Previous (long press)   : keep seeking forward / back by the seek amount
 *  - Fast-forward / Rewind          : seek forward / back by the seek amount
 *
 * It drives the real player (not the session's trimmed wrapper), so it works in the app, in PiP,
 * in the background and with the screen off. Everything runs on the main thread.
 */
@UnstableApi
class EarphoneControls(
    private val player: () -> Player?,
    private val seekAmountMs: () -> Long,
    private val enabled: () -> Boolean = { true }
) : MediaSession.Callback {

    private val handler = Handler(Looper.getMainLooper())
    private var tapCount = 0
    private var longPressedSkipKey = false
    private val resolveTaps = Runnable {
        val count = tapCount
        tapCount = 0
        when {
            count <= 1 -> togglePlayPause()
            count == 2 -> next()
            else -> previous()
        }
    }

    override fun onMediaButtonEvent(
        session: MediaSession,
        controllerInfo: MediaSession.ControllerInfo,
        intent: Intent
    ): Boolean {
        // Off in settings: let Media3 handle the buttons its default way.
        if (!enabled()) return false
        val event = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
            ?: return false
        val p = player() ?: return false

        when (event.keyCode) {
            KeyEvent.KEYCODE_HEADSETHOOK, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                // Count presses on key-down and decide after a short gap, so 2 and 3 presses are not read as 1.
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    tapCount++
                    handler.removeCallbacks(resolveTaps)
                    handler.postDelayed(resolveTaps, MULTI_TAP_WINDOW_MS)
                }
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY -> {
                if (event.action == KeyEvent.ACTION_DOWN) play(p)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_MEDIA_STOP -> {
                if (event.action == KeyEvent.ACTION_DOWN) p.pause()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                val forward = event.keyCode == KeyEvent.KEYCODE_MEDIA_NEXT
                when (event.action) {
                    KeyEvent.ACTION_DOWN -> {
                        if (event.repeatCount == 0) longPressedSkipKey = false
                        else {
                            // Held down: scrub through the video instead of skipping it.
                            longPressedSkipKey = true
                            seekBy(p, if (forward) seekAmountMs() else -seekAmountMs())
                        }
                    }
                    KeyEvent.ACTION_UP -> {
                        if (!longPressedSkipKey) {
                            if (forward) next() else previous()
                        }
                        longPressedSkipKey = false
                    }
                }
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (event.action == KeyEvent.ACTION_DOWN) seekBy(p, seekAmountMs())
                return true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (event.action == KeyEvent.ACTION_DOWN) seekBy(p, -seekAmountMs())
                return true
            }
        }
        return false
    }

    /** Stops a pending multi-press decision (call when the session is released). */
    fun release() {
        handler.removeCallbacks(resolveTaps)
        tapCount = 0
    }

    private fun play(p: Player) {
        if (p.playbackState == Player.STATE_ENDED) p.seekToDefaultPosition()
        p.play()
    }

    private fun togglePlayPause() {
        val p = player() ?: return
        // Decide from playWhenReady (what the user sees as "playing"), not isPlaying, which lags while buffering.
        if (p.playWhenReady && p.playbackState != Player.STATE_ENDED) p.pause() else play(p)
    }

    private fun next() {
        val p = player() ?: return
        if (p.hasNextMediaItem()) p.seekToNextMediaItem() else seekBy(p, seekAmountMs())
    }

    private fun previous() {
        val p = player() ?: return
        if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem() else seekBy(p, -seekAmountMs())
    }

    private fun seekBy(p: Player, deltaMs: Long) {
        val duration = p.duration
        var target = p.currentPosition + deltaMs
        if (duration > 0 && duration != androidx.media3.common.C.TIME_UNSET) target = target.coerceAtMost(duration)
        p.seekTo(target.coerceAtLeast(0L))
    }

    private companion object {
        /** Gap that still counts as the same multi-press; short enough that a single press feels instant. */
        const val MULTI_TAP_WINDOW_MS = 350L
    }
}
